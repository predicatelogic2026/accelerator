`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/25/2026 08:38:32 PM
// Design Name: 
// Module Name: or4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module or4(in4, out1);
input[3:0] in4;
output out1;
assign out1 = in4[0]|in4[1]|in4[2]|in4[3];
endmodule
