`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/28/2026 10:37:02 AM
// Design Name: 
// Module Name: myMMU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module MMU_CH17 #(
    parameter mem_data_width = 64,
    parameter mem_addr_width = 18,
    parameter acc_in_width = 84,
    parameter acc_out_width = 65,
    parameter mmu_id = 1
)
(rst, clk,
en0, we0, data0, q0, addr0, 
en1, we1, data1, q1, addr1, 
en2, we2, data2, q2, addr2,
en3, we3, data3, q3, addr3,
en4, we4, data4, q4, addr4,
en5, we5, data5, q5, addr5,
en6, we6, data6, q6, addr6, 
en7, we7, data7, q7, addr7, 
en8, we8, data8, q8, addr8,
en9, we9, data9, q9, addr9,
en10, we10, data10, q10, addr10,
en11, we11, data11, q11, addr11,
en12, we12, data12, q12, addr12, 
en13, we13, data13, q13, addr13, 
en14, we14, data14, q14, addr14,
en15, we15, data15, q15, addr15,
en16, we16, data16, q16, addr16,
mem_en, mem_we, mem_addr, mem_data, mem_q);
input rst, clk;
input en0, we0, en1, we1, en2, we2, en3, we3, en4, we4, en5, we5, 
en6, we6, en7, we7, en8, we8, en9, we9, en10, we10, en11, we11, en12, we12, en13, we13, en14, we14, en15, we15, en16, we16;
input [acc_in_width-1:0] data0, data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, data11, data12, data13, data14, data15, data16;
input [3:0] addr0, addr1, addr2, addr3, addr4, addr5, addr6, addr7, addr8, addr9, addr10, addr11, addr12, addr13, addr14, addr15, addr16;
output reg[acc_out_width-1:0] q0, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16;

output reg mem_en, mem_we;
output reg [mem_addr_width-1:0] mem_addr;
output reg [mem_data_width-1:0] mem_data;
input [mem_data_width-1:0] mem_q;

//a busy bit controlled by both user interface 1 and FSM
reg buf0_msb;
reg clr0_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf0_msb<=0;
	else if(clr0_msb) buf0_msb<=0;
	else if(en0&we0&(addr0==mmu_id)) buf0_msb<=data0[acc_in_width-1];
end
reg [acc_in_width-1:0] buf0;
reg clr0;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf0[acc_in_width-1]<=0;
	else if(clr0) buf0[acc_in_width-1]<=0;
	else if(en0&we0&(addr0==mmu_id)) buf0[acc_in_width-1]<=data0[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf0r;
reg buf0r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf0r<=0;
	else if(buf0r_en) buf0r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf0[acc_in_width-2:0]<=0;
	else if(en0&we0&(addr0==mmu_id)) buf0[acc_in_width-2:0]<=data0[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q0 <= 0;
	else if(en0&!we0&(addr0==mmu_id)) q0<={buf0[acc_in_width-1], buf0r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf1_msb;
reg clr1_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf1_msb<=0;
	else if(clr1_msb) buf1_msb<=0;
	else if(en1&we1&(addr1==mmu_id)) buf1_msb<=data1[acc_in_width-1];
end
reg [acc_in_width-1:0] buf1;
reg clr1;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf1[acc_in_width-1]<=0;
	else if(clr1) buf1[acc_in_width-1]<=0;
	else if(en1&we1&(addr1==mmu_id)) buf1[acc_in_width-1]<=data1[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf1r;
reg buf1r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf1r<=0;
	else if(buf1r_en) buf1r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf1[acc_in_width-2:0]<=0;
	else if(en1&we1&(addr1==mmu_id)) buf1[acc_in_width-2:0]<=data1[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q1 <= 0;
	else if(en1&!we1&(addr1==mmu_id)) q1<={buf1[acc_in_width-1], buf1r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf2_msb;
reg clr2_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf2_msb<=0;
	else if(clr2_msb) buf2_msb<=0;
	else if(en2&we2&(addr2==mmu_id)) buf2_msb<=data2[acc_in_width-1];
end
reg [acc_in_width-1:0] buf2;
reg clr2;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf2[acc_in_width-1]<=0;
	else if(clr2) buf2[acc_in_width-1]<=0;
	else if(en2&we2&(addr2==mmu_id)) buf2[acc_in_width-1]<=data2[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf2r;
reg buf2r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf2r<=0;
	else if(buf2r_en) buf2r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf2[acc_in_width-2:0]<=0;
	else if(en2&we2&(addr2==mmu_id)) buf2[acc_in_width-2:0]<=data2[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q2 <= 0;
	else if(en2&!we2&(addr2==mmu_id)) q2<={buf2[acc_in_width-1], buf2r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf3_msb;
reg clr3_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf3_msb<=0;
	else if(clr3_msb) buf3_msb<=0;
	else if(en3&we3&(addr3==mmu_id)) buf3_msb<=data3[acc_in_width-1];
end
reg [acc_in_width-1:0] buf3;
reg clr3;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf3[acc_in_width-1]<=0;
	else if(clr3) buf3[acc_in_width-1]<=0;
	else if(en3&we3&(addr3==mmu_id)) buf3[acc_in_width-1]<=data3[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf3r;
reg buf3r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf3r<=0;
	else if(buf3r_en) buf3r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf3[acc_in_width-2:0]<=0;
	else if(en3&we3&(addr3==mmu_id)) buf3[acc_in_width-2:0]<=data3[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q3 <= 0;
	else if(en3&!we3&(addr3==mmu_id)) q3<={buf3[acc_in_width-1], buf3r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf4_msb;
reg clr4_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf4_msb<=0;
	else if(clr4_msb) buf4_msb<=0;
	else if(en4&we4&(addr4==mmu_id)) buf4_msb<=data4[acc_in_width-1];
end
reg [acc_in_width-1:0] buf4;
reg clr4;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf4[acc_in_width-1]<=0;
	else if(clr4) buf4[acc_in_width-1]<=0;
	else if(en4&we4&(addr4==mmu_id)) buf4[acc_in_width-1]<=data4[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf4r;
reg buf4r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf4r<=0;
	else if(buf4r_en) buf4r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf4[acc_in_width-2:0]<=0;
	else if(en4&we4&(addr4==mmu_id)) buf4[acc_in_width-2:0]<=data4[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q4 <= 0;
	else if(en4&!we4&(addr4==mmu_id)) q4<={buf4[acc_in_width-1], buf4r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf5_msb;
reg clr5_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf5_msb<=0;
	else if(clr5_msb) buf5_msb<=0;
	else if(en5&we5&(addr5==mmu_id)) buf5_msb<=data5[acc_in_width-1];
end
reg [acc_in_width-1:0] buf5;
reg clr5;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf5[acc_in_width-1]<=0;
	else if(clr5) buf5[acc_in_width-1]<=0;
	else if(en5&we5&(addr5==mmu_id)) buf5[acc_in_width-1]<=data5[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf5r;
reg buf5r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf5r<=0;
	else if(buf5r_en) buf5r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf5[acc_in_width-2:0]<=0;
	else if(en5&we5&(addr5==mmu_id)) buf5[acc_in_width-2:0]<=data5[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q5 <= 0;
	else if(en5&!we5&(addr5==mmu_id)) q5<={buf5[acc_in_width-1], buf5r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf6_msb;
reg clr6_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf6_msb<=0;
	else if(clr6_msb) buf6_msb<=0;
	else if(en6&we6&(addr6==mmu_id)) buf6_msb<=data6[acc_in_width-1];
end
reg [acc_in_width-1:0] buf6;
reg clr6;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf6[acc_in_width-1]<=0;
	else if(clr6) buf6[acc_in_width-1]<=0;
	else if(en6&we6&(addr6==mmu_id)) buf6[acc_in_width-1]<=data6[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf6r;
reg buf6r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf6r<=0;
	else if(buf6r_en) buf6r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf6[acc_in_width-2:0]<=0;
	else if(en6&we6&(addr6==mmu_id)) buf6[acc_in_width-2:0]<=data6[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q6 <= 0;
	else if(en6&!we6&(addr6==mmu_id)) q6<={buf6[acc_in_width-1], buf6r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf7_msb;
reg clr7_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf7_msb<=0;
	else if(clr7_msb) buf7_msb<=0;
	else if(en7&we7&(addr7==mmu_id)) buf7_msb<=data7[acc_in_width-1];
end
reg [acc_in_width-1:0] buf7;
reg clr7;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf7[acc_in_width-1]<=0;
	else if(clr7) buf7[acc_in_width-1]<=0;
	else if(en7&we7&(addr7==mmu_id)) buf7[acc_in_width-1]<=data7[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf7r;
reg buf7r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf7r<=0;
	else if(buf7r_en) buf7r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf7[acc_in_width-2:0]<=0;
	else if(en7&we7&(addr7==mmu_id)) buf7[acc_in_width-2:0]<=data7[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q7 <= 0;
	else if(en7&!we7&(addr7==mmu_id)) q7<={buf7[acc_in_width-1], buf7r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf8_msb;
reg clr8_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf8_msb<=0;
	else if(clr8_msb) buf8_msb<=0;
	else if(en8&we8&(addr8==mmu_id)) buf8_msb<=data8[acc_in_width-1];
end
reg [acc_in_width-1:0] buf8;
reg clr8;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf8[acc_in_width-1]<=0;
	else if(clr8) buf8[acc_in_width-1]<=0;
	else if(en8&we8&(addr8==mmu_id)) buf8[acc_in_width-1]<=data8[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf8r;
reg buf8r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf8r<=0;
	else if(buf8r_en) buf8r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf8[acc_in_width-2:0]<=0;
	else if(en8&we8&(addr8==mmu_id)) buf8[acc_in_width-2:0]<=data8[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q8 <= 0;
	else if(en8&!we8&(addr8==mmu_id)) q8<={buf8[acc_in_width-1], buf8r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf9_msb;
reg clr9_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf9_msb<=0;
	else if(clr9_msb) buf9_msb<=0;
	else if(en9&we9&(addr9==mmu_id)) buf9_msb<=data9[acc_in_width-1];
end
reg [acc_in_width-1:0] buf9;
reg clr9;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf9[acc_in_width-1]<=0;
	else if(clr9) buf9[acc_in_width-1]<=0;
	else if(en9&we9&(addr9==mmu_id)) buf9[acc_in_width-1]<=data9[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf9r;
reg buf9r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf9r<=0;
	else if(buf9r_en) buf9r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf9[acc_in_width-2:0]<=0;
	else if(en9&we9&(addr9==mmu_id)) buf9[acc_in_width-2:0]<=data9[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q9 <= 0;
	else if(en9&!we9&(addr9==mmu_id)) q9<={buf9[acc_in_width-1], buf9r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf10_msb;
reg clr10_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf10_msb<=0;
	else if(clr10_msb) buf10_msb<=0;
	else if(en10&we10&(addr10==mmu_id)) buf10_msb<=data10[acc_in_width-1];
end
reg [acc_in_width-1:0] buf10;
reg clr10;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf10[acc_in_width-1]<=0;
	else if(clr10) buf10[acc_in_width-1]<=0;
	else if(en10&we10&(addr10==mmu_id)) buf10[acc_in_width-1]<=data10[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf10r;
reg buf10r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf10r<=0;
	else if(buf10r_en) buf10r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf10[acc_in_width-2:0]<=0;
	else if(en10&we10&(addr10==mmu_id)) buf10[acc_in_width-2:0]<=data10[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q10 <= 0;
	else if(en10&!we10&(addr10==mmu_id)) q10<={buf10[acc_in_width-1], buf10r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf11_msb;
reg clr11_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf11_msb<=0;
	else if(clr11_msb) buf11_msb<=0;
	else if(en11&we11&(addr11==mmu_id)) buf11_msb<=data11[acc_in_width-1];
end
reg [acc_in_width-1:0] buf11;
reg clr11;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf11[acc_in_width-1]<=0;
	else if(clr11) buf11[acc_in_width-1]<=0;
	else if(en11&we11&(addr11==mmu_id)) buf11[acc_in_width-1]<=data11[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf11r;
reg buf11r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf11r<=0;
	else if(buf11r_en) buf11r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf11[acc_in_width-2:0]<=0;
	else if(en11&we11&(addr11==mmu_id)) buf11[acc_in_width-2:0]<=data11[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q11 <= 0;
	else if(en11&!we11&(addr11==mmu_id)) q11<={buf11[acc_in_width-1], buf11r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf12_msb;
reg clr12_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf12_msb<=0;
	else if(clr12_msb) buf12_msb<=0;
	else if(en12&we12&(addr12==mmu_id)) buf12_msb<=data12[acc_in_width-1];
end
reg [acc_in_width-1:0] buf12;
reg clr12;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf12[acc_in_width-1]<=0;
	else if(clr12) buf12[acc_in_width-1]<=0;
	else if(en12&we12&(addr12==mmu_id)) buf12[acc_in_width-1]<=data12[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf12r;
reg buf12r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf12r<=0;
	else if(buf12r_en) buf12r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf12[acc_in_width-2:0]<=0;
	else if(en12&we12&(addr12==mmu_id)) buf12[acc_in_width-2:0]<=data12[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q12 <= 0;
	else if(en12&!we12&(addr12==mmu_id)) q12<={buf12[acc_in_width-1], buf12r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf13_msb;
reg clr13_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf13_msb<=0;
	else if(clr13_msb) buf13_msb<=0;
	else if(en13&we13&(addr13==mmu_id)) buf13_msb<=data13[acc_in_width-1];
end
reg [acc_in_width-1:0] buf13;
reg clr13;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf13[acc_in_width-1]<=0;
	else if(clr13) buf13[acc_in_width-1]<=0;
	else if(en13&we13&(addr13==mmu_id)) buf13[acc_in_width-1]<=data13[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf13r;
reg buf13r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf13r<=0;
	else if(buf13r_en) buf13r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf13[acc_in_width-2:0]<=0;
	else if(en13&we13&(addr13==mmu_id)) buf13[acc_in_width-2:0]<=data13[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q13 <= 0;
	else if(en13&!we13&(addr13==mmu_id)) q13<={buf13[acc_in_width-1], buf13r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf14_msb;
reg clr14_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf14_msb<=0;
	else if(clr14_msb) buf14_msb<=0;
	else if(en14&we14&(addr14==mmu_id)) buf14_msb<=data14[acc_in_width-1];
end
reg [acc_in_width-1:0] buf14;
reg clr14;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf14[acc_in_width-1]<=0;
	else if(clr14) buf14[acc_in_width-1]<=0;
	else if(en14&we14&(addr14==mmu_id)) buf14[acc_in_width-1]<=data14[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf14r;
reg buf14r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf14r<=0;
	else if(buf14r_en) buf14r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf14[acc_in_width-2:0]<=0;
	else if(en14&we14&(addr14==mmu_id)) buf14[acc_in_width-2:0]<=data14[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q14 <= 0;
	else if(en14&!we14&(addr14==mmu_id)) q14<={buf14[acc_in_width-1], buf14r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf15_msb;
reg clr15_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf15_msb<=0;
	else if(clr15_msb) buf15_msb<=0;
	else if(en15&we15&(addr15==mmu_id)) buf15_msb<=data15[acc_in_width-1];
end
reg [acc_in_width-1:0] buf15;
reg clr15;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf15[acc_in_width-1]<=0;
	else if(clr15) buf15[acc_in_width-1]<=0;
	else if(en15&we15&(addr15==mmu_id)) buf15[acc_in_width-1]<=data15[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf15r;
reg buf15r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf15r<=0;
	else if(buf15r_en) buf15r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf15[acc_in_width-2:0]<=0;
	else if(en15&we15&(addr15==mmu_id)) buf15[acc_in_width-2:0]<=data15[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q15 <= 0;
	else if(en15&!we15&(addr15==mmu_id)) q15<={buf15[acc_in_width-1], buf15r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf16_msb;
reg clr16_msb;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf16_msb<=0;
	else if(clr16_msb) buf16_msb<=0;
	else if(en16&we16&(addr16==mmu_id)) buf16_msb<=data16[acc_in_width-1];
end
reg [acc_in_width-1:0] buf16;
reg clr16;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf16[acc_in_width-1]<=0;
	else if(clr16) buf16[acc_in_width-1]<=0;
	else if(en16&we16&(addr16==mmu_id)) buf16[acc_in_width-1]<=data16[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf16r;
reg buf16r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf16r<=0;
	else if(buf16r_en) buf16r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf16[acc_in_width-2:0]<=0;
	else if(en16&we16&(addr16==mmu_id)) buf16[acc_in_width-2:0]<=data16[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q16 <= 0;
	else if(en16&!we16&(addr16==mmu_id)) q16<={buf16[acc_in_width-1], buf16r};
end

localparam state_init = 0;
localparam state_exec0 = 1;
localparam state_update0 = 2;
localparam state_exec1 = 3;
localparam state_update1 = 4;
localparam state_exec2 = 5;
localparam state_update2 = 6;
localparam state_exec3 = 7;
localparam state_update3 = 8;
localparam state_exec4 = 9;
localparam state_update4 = 10;
localparam state_exec5 = 11;
localparam state_update5 = 12;
localparam state_exec6 = 13;
localparam state_update6 = 14;
localparam state_exec7 = 15;
localparam state_update7 = 16;
localparam state_exec8 = 17;
localparam state_update8 = 18;
localparam state_exec9 = 19;
localparam state_update9 = 20;
localparam state_exec10 = 21;
localparam state_update10 = 22;
localparam state_exec11 = 23;
localparam state_update11 = 24;
localparam state_exec12 = 25;
localparam state_update12 = 26;
localparam state_exec13 = 27;
localparam state_update13 = 28;
localparam state_exec14 = 29;
localparam state_update14 = 30;
localparam state_exec15 = 31;
localparam state_update15 = 32;
localparam state_exec16 = 33;
localparam state_update16 = 34;

reg[7:0] curr_state, next_state;
always @(negedge rst, posedge clk)
begin
	if(!rst) curr_state <= state_init;
	else curr_state <= next_state;
end

//version of round-robin
wire [16:0] bit31s;
assign bit31s = {buf16[acc_in_width-1],buf15[acc_in_width-1],buf14[acc_in_width-1],buf13[acc_in_width-1],buf12[acc_in_width-1],
buf11[acc_in_width-1],buf10[acc_in_width-1],buf9[acc_in_width-1],buf8[acc_in_width-1],buf7[acc_in_width-1], buf6[acc_in_width-1],buf5[acc_in_width-1],buf4[acc_in_width-1],buf3[acc_in_width-1],buf2[acc_in_width-1],buf1[acc_in_width-1],buf0[acc_in_width-1]};

wire [16:0] all_msbs;
assign all_msbs = {buf16_msb,buf15_msb,buf14_msb,buf13_msb,buf12_msb,buf11_msb,buf10_msb,buf9_msb,
buf8_msb,buf7_msb,buf6_msb,buf5_msb,buf4_msb,buf3_msb,buf2_msb,buf1_msb,buf0_msb}; 
/*
reg[4:0] shifter;
always @(negedge rst, posedge clk)
begin
    if(!rst) shifter = 5'b00001;
    else
    begin
        if((bit31s&shifter)==0)
        begin
            if(shifter==5'b10000) shifter <= 5'b00001;
            else shifter <= shifter<<1;
        end
    end
end
*/

/*
reg[7:0] new_state;
always @(shifter, bit31s)
begin
    if(bit31s==0) new_state <= state_init;
    else
    begin
        case(shifter&bit31s)
        5'b00001:
        begin
            new_state <= state_exec1;
        end
        5'b00010:
        begin
            new_state <= state_exec2;
        end
        5'b00100:
        begin
            new_state <= state_exec3;
        end
        5'b01000:
        begin
            new_state <= state_exec4;
        end
        5'b10000:
        begin
            new_state <= state_exec5;
        end        
        default:
        begin
            new_state <= state_init;
        end
        endcase
    end
end
*/

reg[7:0] new_state;
always @(bit31s)
begin
    if(bit31s==0) new_state <= state_init;
    else
    begin
        casez(bit31s)
        17'b????????????????1:
        begin
            new_state <= state_exec0;
        end
        17'b???????????????10:
        begin
            new_state <= state_exec1;
        end
        17'b??????????????100:
        begin
            new_state <= state_exec2;
        end
        17'b?????????????1000:
        begin
            new_state <= state_exec3;
        end
        17'b????????????10000:
        begin
            new_state <= state_exec4;
        end
        17'b???????????100000:
        begin
            new_state <= state_exec5;
        end
        17'b??????????1000000:
        begin
            new_state <= state_exec6;
        end
        17'b?????????10000000:
        begin
            new_state <= state_exec7;
        end
        17'b????????100000000:
        begin
            new_state <= state_exec8;
        end
        17'b???????1000000000:
        begin
            new_state <= state_exec9;
        end
        17'b??????10000000000:
        begin
            new_state <= state_exec10;
        end
        17'b?????100000000000:
        begin
            new_state <= state_exec11;
        end
        17'b????1000000000000:
        begin
            new_state <= state_exec12;
        end
        17'b???10000000000000:
        begin
            new_state <= state_exec13;
        end
        17'b??100000000000000:
        begin
            new_state <= state_exec14;
        end
        17'b?1000000000000000:
        begin
            new_state <= state_exec15;
        end
        17'b10000000000000000:
        begin
            new_state <= state_exec16;
        end        
        default:
        begin
            new_state <= state_init;
        end
        endcase
    end
end

reg[7:0] next_new_state;
always @(all_msbs)
begin
    if(all_msbs==0) next_new_state <= state_init;
    else
    begin
        casez(all_msbs)
        17'b????????????????1:
        begin
            next_new_state <= state_exec0;
        end
        17'b???????????????10:
        begin
            next_new_state <= state_exec1;
        end
        17'b??????????????100:
        begin
            next_new_state <= state_exec2;
        end
        17'b?????????????1000:
        begin
            next_new_state <= state_exec3;
        end
        17'b????????????10000:
        begin
            next_new_state <= state_exec4;
        end
        17'b???????????100000:
        begin
            next_new_state <= state_exec5;
        end
        17'b??????????1000000:
        begin
            next_new_state <= state_exec6;
        end
        17'b?????????10000000:
        begin
            next_new_state <= state_exec7;
        end
        17'b????????100000000:
        begin
            next_new_state <= state_exec8;
        end
        17'b???????1000000000:
        begin
            next_new_state <= state_exec9;
        end
        17'b??????10000000000:
        begin
            next_new_state <= state_exec10;
        end
        17'b?????100000000000:
        begin
            next_new_state <= state_exec11;
        end
        17'b????1000000000000:
        begin
            next_new_state <= state_exec12;
        end
        17'b???10000000000000:
        begin
            next_new_state <= state_exec13;
        end
        17'b??100000000000000:
        begin
            next_new_state <= state_exec14;
        end
        17'b?1000000000000000:
        begin
            next_new_state <= state_exec15;
        end
        17'b10000000000000000:
        begin
            next_new_state <= state_exec16;
        end        
        default:
        begin
            next_new_state <= state_init;
        end
        endcase
    end
end

always @(curr_state)
begin
    if(curr_state==state_exec0) clr0_msb <= 1;
    else clr0_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec1) clr1_msb <= 1;
    else clr1_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec2) clr2_msb <= 1;
    else clr2_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec3) clr3_msb <= 1;
    else clr3_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec4) clr4_msb <= 1;
    else clr4_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec5) clr5_msb <= 1;
    else clr5_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec6) clr6_msb <= 1;
    else clr6_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec7) clr7_msb <= 1;
    else clr7_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec8) clr8_msb <= 1;
    else clr8_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec9) clr9_msb <= 1;
    else clr9_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec10) clr10_msb <= 1;
    else clr10_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec11) clr11_msb <= 1;
    else clr11_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec12) clr12_msb <= 1;
    else clr12_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec13) clr13_msb <= 1;
    else clr13_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec14) clr14_msb <= 1;
    else clr14_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec15) clr15_msb <= 1;
    else clr15_msb <= 0;
end

always @(curr_state)
begin
    if(curr_state==state_exec16) clr16_msb <= 1;
    else clr16_msb <= 0;
end

always @(*)
begin
	case(curr_state)
	state_init:
	begin
		next_state <= new_state;
		clr0 <= 0;
              clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 0;
		mem_we <= 0;
		mem_addr <= 0;
		mem_data <= 64'b0;
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;				
	end
	state_exec0:
	begin
		next_state <= state_update0;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf0[acc_in_width-2];
		mem_addr <= buf0[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf0[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update0:
	begin
		next_state <= next_new_state;
                clr0 <= 1;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf0[acc_in_width-2];
		mem_addr <= buf0[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf0[mem_data_width-1:0];
		buf0r_en <= ~buf0[acc_in_width-2];
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec1:
	begin
		next_state <= state_update1;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf1[acc_in_width-2];
		mem_addr <= buf1[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf1[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update1:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 1;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf1[acc_in_width-2];
		mem_addr <= buf1[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf1[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= ~buf1[acc_in_width-2];
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec2:
	begin
		next_state <= state_update2;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf2[acc_in_width-2];
		mem_addr <= buf2[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf2[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update2:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 1;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf2[acc_in_width-2];
		mem_addr <= buf2[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf2[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= ~buf2[acc_in_width-2];
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec3:
	begin
		next_state <= state_update3;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf3[acc_in_width-2];
		mem_addr <= buf3[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf3[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update3:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 1;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf3[acc_in_width-2];
		mem_addr <= buf3[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf3[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= ~buf3[acc_in_width-2];
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec4:
	begin
		next_state <= state_update4;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf4[acc_in_width-2];
		mem_addr <= buf4[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf4[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update4:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 1;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf4[acc_in_width-2];
		mem_addr <= buf4[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf4[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= ~buf4[acc_in_width-2];
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec5:
	begin
		next_state <= state_update5;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf5[acc_in_width-2];
		mem_addr <= buf5[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf5[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update5:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 1;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf5[acc_in_width-2];
		mem_addr <= buf5[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf5[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= ~buf5[acc_in_width-2];
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec6:
	begin
		next_state <= state_update6;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf6[acc_in_width-2];
		mem_addr <= buf6[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf6[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update6:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 1;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf6[acc_in_width-2];
		mem_addr <= buf6[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf6[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= ~buf6[acc_in_width-2];
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec7:
	begin
		next_state <= state_update7;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf7[acc_in_width-2];
		mem_addr <= buf7[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf7[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update7:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 1;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf7[acc_in_width-2];
		mem_addr <= buf7[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf7[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= ~buf7[acc_in_width-2];
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec8:
	begin
		next_state <= state_update8;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf8[acc_in_width-2];
		mem_addr <= buf8[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf8[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update8:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 1;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf8[acc_in_width-2];
		mem_addr <= buf8[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf8[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= ~buf8[acc_in_width-2];
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec9:
	begin
		next_state <= state_update9;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf9[acc_in_width-2];
		mem_addr <= buf9[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf9[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update9:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 1;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf9[acc_in_width-2];
		mem_addr <= buf9[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf9[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= ~buf9[acc_in_width-2];
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec10:
	begin
		next_state <= state_update10;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf10[acc_in_width-2];
		mem_addr <= buf10[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf10[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update10:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 1;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf10[acc_in_width-2];
		mem_addr <= buf10[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf10[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= ~buf10[acc_in_width-2];
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec11:
	begin
		next_state <= state_update11;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf11[acc_in_width-2];
		mem_addr <= buf11[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf11[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update11:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 1;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf11[acc_in_width-2];
		mem_addr <= buf11[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf11[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= ~buf11[acc_in_width-2];
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec12:
	begin
		next_state <= state_update12;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf12[acc_in_width-2];
		mem_addr <= buf12[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf12[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update12:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 1;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf12[acc_in_width-2];
		mem_addr <= buf12[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf12[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= ~buf12[acc_in_width-2];
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec13:
	begin
		next_state <= state_update13;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf13[acc_in_width-2];
		mem_addr <= buf13[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf13[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update13:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 1;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf13[acc_in_width-2];
		mem_addr <= buf13[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf13[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= ~buf13[acc_in_width-2];
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec14:
	begin
		next_state <= state_update14;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf14[acc_in_width-2];
		mem_addr <= buf14[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf14[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update14:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 1;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf14[acc_in_width-2];
		mem_addr <= buf14[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf14[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= ~buf14[acc_in_width-2];
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_exec15:
	begin
		next_state <= state_update15;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf15[acc_in_width-2];
		mem_addr <= buf15[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf15[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update15:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 1;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf15[acc_in_width-2];
		mem_addr <= buf15[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf15[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= ~buf15[acc_in_width-2];
		buf16r_en <= 0;	
	end
	state_exec16:
	begin
		next_state <= state_update16;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 1;
		mem_we <= buf16[acc_in_width-2];
		mem_addr <= buf16[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf16[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	state_update16:
	begin
		next_state <= next_new_state;
                clr0 <= 0;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 1;
		mem_en <= 1;
		mem_we <= buf16[acc_in_width-2];
		mem_addr <= buf16[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf16[mem_data_width-1:0];
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= ~buf16[acc_in_width-2];	
	end		
	default:
	begin
		next_state <= state_init;
		clr0 <= 0;
                clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		clr6 <= 0;
		clr7 <= 0;
		clr8 <= 0;
		clr9 <= 0;
		clr10 <= 0;
		clr11 <= 0;
		clr12 <= 0;
		clr13 <= 0;
		clr14 <= 0;
		clr15 <= 0;
                clr16 <= 0;
		mem_en <= 0;
		mem_we <= 0;
		mem_addr <= 0;
		mem_data <= 64'b0;
		buf0r_en <= 0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
		buf6r_en <= 0;
		buf7r_en <= 0;
		buf8r_en <= 0;
		buf9r_en <= 0;
		buf10r_en <= 0;
		buf11r_en <= 0;
		buf12r_en <= 0;
		buf13r_en <= 0;
		buf14r_en <= 0;
		buf15r_en <= 0;
		buf16r_en <= 0;	
	end
	endcase
end


endmodule

 
