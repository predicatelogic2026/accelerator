`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/28/2026 10:37:02 AM
// Design Name: 
// Module Name: myMMU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module myMMU4 #(
    parameter mem_data_width = 64,
    parameter mem_addr_width = 18,
    parameter acc_in_width = 2 * mem_data_width + 2,
    parameter acc_out_width = mem_data_width + 1
)
(rst, clk, 
en1, we1, data1, q1, addr1, 
en2, we2, data2, q2, addr2,
en3, we3, data3, q3, addr3,
en4, we4, data4, q4, addr4,
en5, we5, data5, q5, addr5,
mem_en, mem_we, mem_addr, mem_data, mem_q);
input rst, clk;
input en1, we1, en2, we2, en3, we3, en4, we4, en5, we5;
input [acc_in_width-1:0] data1, data2, data3, data4, data5;
input [2:0] addr1, addr2, addr3, addr4, addr5;
output reg[acc_out_width-1:0] q1, q2, q3, q4, q5;

output reg mem_en, mem_we;
output reg [mem_addr_width-1:0] mem_addr;
output reg [mem_data_width-1:0] mem_data;
input [mem_data_width-1:0] mem_q;

//a busy bit controlled by both user interface 1 and FSM
reg [acc_in_width-1:0] buf1;
reg clr1;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf1[acc_in_width-1]<=0;
	else if(clr1) buf1[acc_in_width-1]<=0;
	else if(en1&we1&(addr1==3'b001)) buf1[acc_in_width-1]<=data1[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf1r;
reg buf1r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf1r<=0;
	else if(buf1r_en) buf1r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf1[acc_in_width-2:0]<=0;
	else if(en1&we1&(addr1==3'b001)) buf1[acc_in_width-2:0]<=data1[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q1 <= 0;
	else if(en1&!we1&(addr1==3'b001)) q1<={buf1[acc_in_width-1], buf1r};
end

//a busy bit controlled by both user interface 1 and FSM
reg [acc_in_width-1:0] buf2;
reg clr2;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf2[acc_in_width-1]<=0;
	else if(clr2) buf2[acc_in_width-1]<=0;
	else if(en2&we2&(addr2==3'b001)) buf2[acc_in_width-1]<=data2[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf2r;
reg buf2r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf2r<=0;
	else if(buf2r_en) buf2r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf2[acc_in_width-2:0]<=0;
	else if(en2&we2&(addr2==3'b001)) buf2[acc_in_width-2:0]<=data2[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q2 <= 0;
	else if(en2&!we2&(addr2==3'b001)) q2<={buf2[acc_in_width-1], buf2r};
end

//a busy bit controlled by both user interface 1 and FSM
reg [acc_in_width-1:0] buf3;
reg clr3;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf3[acc_in_width-1]<=0;
	else if(clr3) buf3[acc_in_width-1]<=0;
	else if(en3&we3&(addr3==3'b001)) buf3[acc_in_width-1]<=data3[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf3r;
reg buf3r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf3r<=0;
	else if(buf3r_en) buf3r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf3[acc_in_width-2:0]<=0;
	else if(en3&we3&(addr3==3'b001)) buf3[acc_in_width-2:0]<=data3[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q3 <= 0;
	else if(en3&!we3&(addr3==3'b001)) q3<={buf3[acc_in_width-1], buf3r};
end

//a busy bit controlled by both user interface 1 and FSM
reg [acc_in_width-1:0] buf4;
reg clr4;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf4[acc_in_width-1]<=0;
	else if(clr4) buf4[acc_in_width-1]<=0;
	else if(en4&we4&(addr4==3'b001)) buf4[acc_in_width-1]<=data4[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf4r;
reg buf4r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf4r<=0;
	else if(buf4r_en) buf4r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf4[acc_in_width-2:0]<=0;
	else if(en4&we4&(addr4==3'b001)) buf4[acc_in_width-2:0]<=data4[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q4 <= 0;
	else if(en4&!we4&(addr4==3'b001)) q4<={buf4[acc_in_width-1], buf4r};
end

//a busy bit controlled by both user interface 1 and FSM
reg [acc_in_width-1:0] buf5;
reg clr5;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf5[acc_in_width-1]<=0;
	else if(clr5) buf5[acc_in_width-1]<=0;
	else if(en5&we5&(addr5==3'b001)) buf5[acc_in_width-1]<=data5[acc_in_width-1];
end
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf5r;
reg buf5r_en;
always @(negedge rst, posedge clk)
begin
	if(!rst) buf5r<=0;
	else if(buf5r_en) buf5r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf5[acc_in_width-2:0]<=0;
	else if(en5&we5&(addr5==3'b001)) buf5[acc_in_width-2:0]<=data5[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q5 <= 0;
	else if(en5&!we5&(addr5==3'b001)) q5<={buf5[acc_in_width-1], buf5r};
end

localparam state_init = 0;
localparam state_exec = 1;
localparam state_update = 2;
localparam state_exec2 = 3;
localparam state_update2 = 4;
localparam state_exec3 = 5;
localparam state_update3 = 6;
localparam state_exec4 = 7;
localparam state_update4 = 8;
localparam state_exec5 = 9;
localparam state_update5 = 10;

reg[4:0] curr_state, next_state;
always @(negedge rst, posedge clk)
begin
	if(!rst) curr_state <= state_init;
	else curr_state <= next_state;
end

//version of round-robin
wire [4:0] bit31s;
assign bit31s = {buf5[acc_in_width-1],buf4[acc_in_width-1],buf3[acc_in_width-1],buf2[acc_in_width-1], buf1[acc_in_width-1]};

reg[4:0] shifter;
always @(negedge rst, posedge clk)
begin
    if(!rst) shifter = 5'b00001;
    else
    begin
        if((bit31s&shifter)==0)
        begin
            if(shifter==5'b10000) shifter <= 5'b00001;
            else shifter <= shifter<<1;
        end
    end
end

reg[4:0] new_state;
always @(shifter, bit31s)
begin
    if(bit31s==0) new_state <= state_init;
    else
    begin
        case(shifter&bit31s)
        5'b00001:
        begin
            new_state <= state_exec;
        end
        5'b00010:
        begin
            new_state <= state_exec2;
        end
        5'b00100:
        begin
            new_state <= state_exec3;
        end
        5'b01000:
        begin
            new_state <= state_exec4;
        end
        5'b10000:
        begin
            new_state <= state_exec5;
        end        
        default:
        begin
            new_state <= state_init;
        end
        endcase
    end
end

//version of priority
/*
reg[4:0] new_state;
always @(*)
begin
	if(buf1[31]) new_state <= state_exec;
	else if(buf2[31]) new_state <= state_exec2;
	else new_state <= state_init;
end
*/



always @(*)
begin
	case(curr_state)
	state_init:
	begin
		next_state <= new_state;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		mem_en <= 0;
		mem_we <= 0;
		mem_addr <= 18'b0;
		mem_data <= 64'b0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;				
	end
	state_exec:
	begin
		next_state <= state_update;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		mem_en <= 1;
		mem_we <= buf1[acc_in_width-2];
		mem_addr <= buf1[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf1[mem_data_width-1:0];
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
	end
	state_update:
	begin
		next_state <= state_init;
		clr1 <= 1;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		mem_en <= 0;
		mem_we <= 0;
		mem_addr <= 18'b0;
		mem_data <= 64'b0;
		buf1r_en <= ~buf1[acc_in_width-2];
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
	end
	state_exec2:
	begin
		next_state <= state_update2;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		mem_en <= 1;
		mem_we <= buf2[acc_in_width-2];
		mem_addr <= buf2[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf2[mem_data_width-1:0];
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
	end
	state_update2:
	begin
		next_state <= state_init;
		clr1 <= 0;
		clr2 <= 1;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		mem_en <= 0;
		mem_we <= 0;
		mem_addr <= 18'b0; //buf2[mem_data_width+mem_addr_width-1:mem_data_width]; //18'b0;
		mem_data <= 64'b0;
		buf1r_en <= 0;
		buf2r_en <= ~buf2[acc_in_width-2];
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
	end
	state_exec3:
	begin
		next_state <= state_update3;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		mem_en <= 1;
		mem_we <= buf3[acc_in_width-2];
		mem_addr <= buf3[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf3[mem_data_width-1:0];
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
	end
	state_update3:
	begin
		next_state <= state_init;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 1;
		clr4 <= 0;
		clr5 <= 0;
		mem_en <= 0;
		mem_we <= 0;
		mem_addr <= 18'b0;
		mem_data <= 64'b0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= ~buf3[acc_in_width-2];
		buf4r_en <= 0;
		buf5r_en <= 0;
	end
	state_exec4:
	begin
		next_state <= state_update4;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		mem_en <= 1;
		mem_we <= buf4[acc_in_width-2];
		mem_addr <= buf4[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf4[mem_data_width-1:0];
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
	end
	state_update4:
	begin
		next_state <= state_init;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 1;
		clr5 <= 0;
		mem_en <= 0;
		mem_we <= 0;
		mem_addr <= 18'b0;
		mem_data <= 64'b0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= ~buf4[acc_in_width-2];
		buf5r_en <= 0;
	end
	state_exec5:
	begin
		next_state <= state_update5;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		mem_en <= 1;
		mem_we <= buf5[acc_in_width-2];
		mem_addr <= buf5[mem_data_width+mem_addr_width-1:mem_data_width];
		mem_data <= buf5[mem_data_width-1:0];
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
	end
	state_update5:
	begin
		next_state <= state_init;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 1;
		mem_en <= 0;
		mem_we <= 0;
		mem_addr <= 18'b0;
		mem_data <= 64'b0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= ~buf5[acc_in_width-2];
	end	
		
	default:
	begin
		next_state <= state_init;
		clr1 <= 0;
		clr2 <= 0;
		clr3 <= 0;
		clr4 <= 0;
		clr5 <= 0;
		mem_en <= 0;
		mem_we <= 0;
		mem_addr <= 18'b0;
		mem_data <= 64'b0;
		buf1r_en <= 0;
		buf2r_en <= 0;
		buf3r_en <= 0;
		buf4r_en <= 0;
		buf5r_en <= 0;
	end
	endcase
end

endmodule
















 

















 
