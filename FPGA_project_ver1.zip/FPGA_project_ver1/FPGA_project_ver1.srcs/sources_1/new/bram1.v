module bram1 #(
    parameter AWIDTH = 12,
    parameter DWIDTH = 64
)(
    input clk,

    // Port A
    input                  en_a,
    input                  we_a,
    input  [DWIDTH-1:0]    din_a,
    input  [AWIDTH-1:0]    addr_a,
    output reg [DWIDTH-1:0] dout_a,

    // Port B
    input                  en_b,
    input                  we_b,
    input  [DWIDTH-1:0]    din_b,
    input  [AWIDTH-1:0]    addr_b,
    output reg [DWIDTH-1:0] dout_b
);

(* ram_style = "block" *)
reg [DWIDTH-1:0] mem[(1<<AWIDTH)-1:0];

always @(posedge clk) begin

    // Port A

    if (en_a) begin
        if (we_a) begin
            mem[addr_a] <= din_a;
            dout_a <= din_a;   // write-first
        end
        else begin
            dout_a <= mem[addr_a];
        end
    end
end

always @(posedge clk) begin
    // Port B

    if (en_b) begin
        if (we_b) begin
            mem[addr_b] <= din_b;
            dout_b <= din_b;   // write-first
        end
        else begin
            dout_b <= mem[addr_b];
        end
    end

end

endmodule