`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/28/2026 10:37:02 AM
// Design Name: 
// Module Name: myMMU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
/////////////////////////////////////////////////////////////////////////////////


module MMU_CH17_new #(
    parameter mem_data_width = 64,
    parameter mem_addr_width = 18,
    parameter acc_in_width = 84,
    parameter acc_out_width = 65,
    parameter mmu_id = 1
)
(rst, clk,
en0, we0, data0, q0, addr0, 
en1, we1, data1, q1, addr1, 
en2, we2, data2, q2, addr2,
en3, we3, data3, q3, addr3,
en4, we4, data4, q4, addr4,
en5, we5, data5, q5, addr5,
en6, we6, data6, q6, addr6, 
en7, we7, data7, q7, addr7, 
en8, we8, data8, q8, addr8,
en9, we9, data9, q9, addr9,
en10, we10, data10, q10, addr10,
en11, we11, data11, q11, addr11,
en12, we12, data12, q12, addr12, 
en13, we13, data13, q13, addr13, 
en14, we14, data14, q14, addr14,
en15, we15, data15, q15, addr15,
en16, we16, data16, q16, addr16,
en17, we17, data17, q17, addr17, 
en18, we18, data18, q18, addr18,
en19, we19, data19, q19, addr19,
en20, we20, data20, q20, addr20,
en21, we21, data21, q21, addr21,
en22, we22, data22, q22, addr22, 
en23, we23, data23, q23, addr23, 
en24, we24, data24, q24, addr24,
en25, we25, data25, q25, addr25,
en26, we26, data26, q26, addr26,
en27, we27, data27, q27, addr27,
en28, we28, data28, q28, addr28,
en29, we29, data29, q29, addr29,
en30, we30, data30, q30, addr30,
en31, we31, data31, q31, addr31,
en32, we32, data32, q32, addr32,
mem_en, mem_we, mem_addr, mem_data, mem_q);
input rst, clk;
input en0, we0, en1, we1, en2, we2, en3, we3, en4, we4, en5, we5, 
en6, we6, en7, we7, en8, we8, en9, we9, en10, we10, en11, we11, en12, we12, en13, we13, en14, we14, en15, we15, en16, we16,
en17, we17, en18, we18, en19, we19, en20, we20, en21, we21, en22, we22, en23, we23, en24, we24,
en25, we25, en26, we26, en27, we27, en28, we28, en29, we29, en30, we30, en31, we31, en32, we32;
input [acc_in_width-1:0] data0, data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, data11, data12, data13, data14, data15, data16,
data17, data18, data19, data20, data21, data22, data23, data24, data25, data26, data27, data28, data29, data30, data31, data32;
input [3:0] addr0, addr1, addr2, addr3, addr4, addr5, addr6, addr7, addr8, addr9, addr10, addr11, addr12, addr13, addr14, addr15, addr16,
addr17, addr18, addr19, addr20, addr21, addr22, addr23, addr24, addr25, addr26, addr27, addr28, addr29, addr30, addr31, addr32;
output reg[acc_out_width-1:0] q0, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16,
q17, q18, q19, q20, q21, q22, q23, q24, q25, q26, q27, q28, q29, q30, q31, q32;

output reg mem_en, mem_we;
output reg [mem_addr_width-1:0] mem_addr;
output reg [mem_data_width-1:0] mem_data;
input [mem_data_width-1:0] mem_q;

reg [32:0] clr_msbs;
reg [32:0] buf_ens;

//a busy bit controlled by both user interface 1 and FSM
reg buf0_msb;
wire clr0_msb;
assign clr0_msb = clr_msbs[0];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf0_msb<=0;
	else if(clr0_msb) buf0_msb<=0;
	else if(en0&we0&(addr0==mmu_id)) buf0_msb<=data0[acc_in_width-1];
end
reg [acc_in_width-1:0] buf0;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf0r;
wire buf0r_en;
assign buf0r_en = buf_ens[0];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf0r<=0;
	else if(buf0r_en) buf0r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf0[acc_in_width-2:0]<=0;
	else if(en0&we0&(addr0==mmu_id)) buf0[acc_in_width-2:0]<=data0[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q0 <= 0;
	else if(en0&!we0&(addr0==mmu_id)) q0<={buf0_msb, (buf0r_en)?mem_q:buf0r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf1_msb;
wire clr1_msb;
assign clr1_msb = clr_msbs[1];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf1_msb<=0;
	else if(clr1_msb) buf1_msb<=0;
	else if(en1&we1&(addr1==mmu_id)) buf1_msb<=data1[acc_in_width-1];
end
reg [acc_in_width-1:0] buf1;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf1r;
wire buf1r_en;
assign buf1r_en = buf_ens[1];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf1r<=0;
	else if(buf1r_en) buf1r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf1[acc_in_width-2:0]<=0;
	else if(en1&we1&(addr1==mmu_id)) buf1[acc_in_width-2:0]<=data1[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q1 <= 0;
	else if(en1&!we1&(addr1==mmu_id)) q1<={buf1_msb, (buf1r_en)?mem_q:buf1r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf2_msb;
wire clr2_msb;
assign clr2_msb = clr_msbs[2];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf2_msb<=0;
	else if(clr2_msb) buf2_msb<=0;
	else if(en2&we2&(addr2==mmu_id)) buf2_msb<=data2[acc_in_width-1];
end
reg [acc_in_width-1:0] buf2;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf2r;
wire buf2r_en;
assign buf2r_en = buf_ens[2];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf2r<=0;
	else if(buf2r_en) buf2r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf2[acc_in_width-2:0]<=0;
	else if(en2&we2&(addr2==mmu_id)) buf2[acc_in_width-2:0]<=data2[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q2 <= 0;
	else if(en2&!we2&(addr2==mmu_id)) q2<={buf2_msb, (buf2r_en)?mem_q:buf2r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf3_msb;
wire clr3_msb;
assign clr3_msb = clr_msbs[3];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf3_msb<=0;
	else if(clr3_msb) buf3_msb<=0;
	else if(en3&we3&(addr3==mmu_id)) buf3_msb<=data3[acc_in_width-1];
end
reg [acc_in_width-1:0] buf3;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf3r;
wire buf3r_en;
assign buf3r_en = buf_ens[3];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf3r<=0;
	else if(buf3r_en) buf3r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf3[acc_in_width-2:0]<=0;
	else if(en3&we3&(addr3==mmu_id)) buf3[acc_in_width-2:0]<=data3[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q3 <= 0;
	else if(en3&!we3&(addr3==mmu_id)) q3<={buf3_msb, (buf3r_en)?mem_q:buf3r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf4_msb;
wire clr4_msb;
assign clr4_msb = clr_msbs[4];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf4_msb<=0;
	else if(clr4_msb) buf4_msb<=0;
	else if(en4&we4&(addr4==mmu_id)) buf4_msb<=data4[acc_in_width-1];
end
reg [acc_in_width-1:0] buf4;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf4r;
wire buf4r_en;
assign buf4r_en = buf_ens[4];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf4r<=0;
	else if(buf4r_en) buf4r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf4[acc_in_width-2:0]<=0;
	else if(en4&we4&(addr4==mmu_id)) buf4[acc_in_width-2:0]<=data4[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q4 <= 0;
	else if(en4&!we4&(addr4==mmu_id)) q4<={buf4_msb, (buf4r_en)?mem_q:buf4r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf5_msb;
wire clr5_msb;
assign clr5_msb = clr_msbs[5];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf5_msb<=0;
	else if(clr5_msb) buf5_msb<=0;
	else if(en5&we5&(addr5==mmu_id)) buf5_msb<=data5[acc_in_width-1];
end
reg [acc_in_width-1:0] buf5;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf5r;
wire buf5r_en;
assign buf5r_en = buf_ens[5];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf5r<=0;
	else if(buf5r_en) buf5r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf5[acc_in_width-2:0]<=0;
	else if(en5&we5&(addr5==mmu_id)) buf5[acc_in_width-2:0]<=data5[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q5 <= 0;
	else if(en5&!we5&(addr5==mmu_id)) q5<={buf5_msb, (buf5r_en)?mem_q:buf5r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf6_msb;
wire clr6_msb;
assign clr6_msb = clr_msbs[6];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf6_msb<=0;
	else if(clr6_msb) buf6_msb<=0;
	else if(en6&we6&(addr6==mmu_id)) buf6_msb<=data6[acc_in_width-1];
end
reg [acc_in_width-1:0] buf6;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf6r;
wire buf6r_en;
assign buf6r_en = buf_ens[6];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf6r<=0;
	else if(buf6r_en) buf6r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf6[acc_in_width-2:0]<=0;
	else if(en6&we6&(addr6==mmu_id)) buf6[acc_in_width-2:0]<=data6[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q6 <= 0;
	else if(en6&!we6&(addr6==mmu_id)) q6<={buf6_msb, (buf6r_en)?mem_q:buf6r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf7_msb;
wire clr7_msb;
assign clr7_msb = clr_msbs[7];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf7_msb<=0;
	else if(clr7_msb) buf7_msb<=0;
	else if(en7&we7&(addr7==mmu_id)) buf7_msb<=data7[acc_in_width-1];
end
reg [acc_in_width-1:0] buf7;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf7r;
wire buf7r_en;
assign buf7r_en = buf_ens[7];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf7r<=0;
	else if(buf7r_en) buf7r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf7[acc_in_width-2:0]<=0;
	else if(en7&we7&(addr7==mmu_id)) buf7[acc_in_width-2:0]<=data7[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q7 <= 0;
	else if(en7&!we7&(addr7==mmu_id)) q7<={buf7_msb, (buf7r_en)?mem_q:buf7r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf8_msb;
wire clr8_msb;
assign clr8_msb = clr_msbs[8];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf8_msb<=0;
	else if(clr8_msb) buf8_msb<=0;
	else if(en8&we8&(addr8==mmu_id)) buf8_msb<=data8[acc_in_width-1];
end
reg [acc_in_width-1:0] buf8;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf8r;
wire buf8r_en;
assign buf8r_en = buf_ens[8];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf8r<=0;
	else if(buf8r_en) buf8r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf8[acc_in_width-2:0]<=0;
	else if(en8&we8&(addr8==mmu_id)) buf8[acc_in_width-2:0]<=data8[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q8 <= 0;
	else if(en8&!we8&(addr8==mmu_id)) q8<={buf8_msb, (buf8r_en)?mem_q:buf8r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf9_msb;
wire clr9_msb;
assign clr9_msb = clr_msbs[9];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf9_msb<=0;
	else if(clr9_msb) buf9_msb<=0;
	else if(en9&we9&(addr9==mmu_id)) buf9_msb<=data9[acc_in_width-1];
end
reg [acc_in_width-1:0] buf9;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf9r;
wire buf9r_en;
assign buf9r_en = buf_ens[9];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf9r<=0;
	else if(buf9r_en) buf9r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf9[acc_in_width-2:0]<=0;
	else if(en9&we9&(addr9==mmu_id)) buf9[acc_in_width-2:0]<=data9[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q9 <= 0;
	else if(en9&!we9&(addr9==mmu_id)) q9<={buf9_msb, (buf9r_en)?mem_q:buf9r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf10_msb;
wire clr10_msb;
assign clr10_msb = clr_msbs[10];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf10_msb<=0;
	else if(clr10_msb) buf10_msb<=0;
	else if(en10&we10&(addr10==mmu_id)) buf10_msb<=data10[acc_in_width-1];
end
reg [acc_in_width-1:0] buf10;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf10r;
wire buf10r_en;
assign buf10r_en = buf_ens[10];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf10r<=0;
	else if(buf10r_en) buf10r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf10[acc_in_width-2:0]<=0;
	else if(en10&we10&(addr10==mmu_id)) buf10[acc_in_width-2:0]<=data10[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q10 <= 0;
	else if(en10&!we10&(addr10==mmu_id)) q10<={buf10_msb, (buf10r_en)?mem_q:buf10r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf11_msb;
wire clr11_msb;
assign clr11_msb = clr_msbs[11];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf11_msb<=0;
	else if(clr11_msb) buf11_msb<=0;
	else if(en11&we11&(addr11==mmu_id)) buf11_msb<=data11[acc_in_width-1];
end
reg [acc_in_width-1:0] buf11;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf11r;
wire buf11r_en;
assign buf11r_en = buf_ens[11];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf11r<=0;
	else if(buf11r_en) buf11r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf11[acc_in_width-2:0]<=0;
	else if(en11&we11&(addr11==mmu_id)) buf11[acc_in_width-2:0]<=data11[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q11 <= 0;
	else if(en11&!we11&(addr11==mmu_id)) q11<={buf11_msb, (buf11r_en)?mem_q:buf11r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf12_msb;
wire clr12_msb;
assign clr12_msb = clr_msbs[12];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf12_msb<=0;
	else if(clr12_msb) buf12_msb<=0;
	else if(en12&we12&(addr12==mmu_id)) buf12_msb<=data12[acc_in_width-1];
end
reg [acc_in_width-1:0] buf12;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf12r;
wire buf12r_en;
assign buf12r_en = buf_ens[12];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf12r<=0;
	else if(buf12r_en) buf12r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf12[acc_in_width-2:0]<=0;
	else if(en12&we12&(addr12==mmu_id)) buf12[acc_in_width-2:0]<=data12[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q12 <= 0;
	else if(en12&!we12&(addr12==mmu_id)) q12<={buf12_msb, (buf12r_en)?mem_q:buf12r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf13_msb;
wire clr13_msb;
assign clr13_msb = clr_msbs[13];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf13_msb<=0;
	else if(clr13_msb) buf13_msb<=0;
	else if(en13&we13&(addr13==mmu_id)) buf13_msb<=data13[acc_in_width-1];
end
reg [acc_in_width-1:0] buf13;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf13r;
wire buf13r_en;
assign buf13r_en = buf_ens[13];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf13r<=0;
	else if(buf13r_en) buf13r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf13[acc_in_width-2:0]<=0;
	else if(en13&we13&(addr13==mmu_id)) buf13[acc_in_width-2:0]<=data13[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q13 <= 0;
	else if(en13&!we13&(addr13==mmu_id)) q13<={buf13_msb, (buf13r_en)?mem_q:buf13r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf14_msb;
wire clr14_msb;
assign clr14_msb = clr_msbs[14];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf14_msb<=0;
	else if(clr14_msb) buf14_msb<=0;
	else if(en14&we14&(addr14==mmu_id)) buf14_msb<=data14[acc_in_width-1];
end
reg [acc_in_width-1:0] buf14;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf14r;
wire buf14r_en;
assign buf14r_en = buf_ens[14];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf14r<=0;
	else if(buf14r_en) buf14r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf14[acc_in_width-2:0]<=0;
	else if(en14&we14&(addr14==mmu_id)) buf14[acc_in_width-2:0]<=data14[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q14 <= 0;
	else if(en14&!we14&(addr14==mmu_id)) q14<={buf14_msb, (buf14r_en)?mem_q:buf14r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf15_msb;
wire clr15_msb;
assign clr15_msb = clr_msbs[15];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf15_msb<=0;
	else if(clr15_msb) buf15_msb<=0;
	else if(en15&we15&(addr15==mmu_id)) buf15_msb<=data15[acc_in_width-1];
end
reg [acc_in_width-1:0] buf15;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf15r;
wire buf15r_en;
assign buf15r_en = buf_ens[15];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf15r<=0;
	else if(buf15r_en) buf15r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf15[acc_in_width-2:0]<=0;
	else if(en15&we15&(addr15==mmu_id)) buf15[acc_in_width-2:0]<=data15[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q15 <= 0;
	else if(en15&!we15&(addr15==mmu_id)) q15<={buf15_msb, (buf15r_en)?mem_q:buf15r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf16_msb;
wire clr16_msb;
assign clr16_msb = clr_msbs[16];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf16_msb<=0;
	else if(clr16_msb) buf16_msb<=0;
	else if(en16&we16&(addr16==mmu_id)) buf16_msb<=data16[acc_in_width-1];
end
reg [acc_in_width-1:0] buf16;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf16r;
wire buf16r_en;
assign buf16r_en = buf_ens[16];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf16r<=0;
	else if(buf16r_en) buf16r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf16[acc_in_width-2:0]<=0;
	else if(en16&we16&(addr16==mmu_id)) buf16[acc_in_width-2:0]<=data16[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q16 <= 0;
	else if(en16&!we16&(addr16==mmu_id)) q16<={buf16_msb, (buf16r_en)?mem_q:buf16r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf17_msb;
wire clr17_msb;
assign clr17_msb = clr_msbs[17];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf17_msb<=0;
	else if(clr17_msb) buf17_msb<=0;
	else if(en17&we17&(addr17==mmu_id)) buf17_msb<=data17[acc_in_width-1];
end
reg [acc_in_width-1:0] buf17;
//allow the lock of memory output into a register
reg [mem_data_width-1:0] buf17r;
wire buf17r_en;
assign buf17r_en = buf_ens[17];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf17r<=0;
	else if(buf17r_en) buf17r<=mem_q;
end
//lower bits of the command are latched into command buffer
always @(negedge rst, posedge clk)
begin
	if(!rst) buf17[acc_in_width-2:0]<=0;
	else if(en17&we17&(addr17==mmu_id)) buf17[acc_in_width-2:0]<=data17[acc_in_width-2:0];
end
//read results
always @(negedge rst, posedge clk)
begin
	if(!rst) q17 <= 0;
	else if(en17&!we17&(addr17==mmu_id)) q17<={buf17_msb, (buf17r_en)?mem_q:buf17r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf18_msb;
wire clr18_msb;
assign clr18_msb = clr_msbs[18];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf18_msb<=0;
	else if(clr18_msb) buf18_msb<=0;
	else if(en18&we18&(addr18==mmu_id)) buf18_msb<=data18[acc_in_width-1];
end
reg [acc_in_width-1:0] buf18;
reg [mem_data_width-1:0] buf18r;
wire buf18r_en;
assign buf18r_en = buf_ens[18];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf18r<=0;
	else if(buf18r_en) buf18r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf18[acc_in_width-2:0]<=0;
	else if(en18&we18&(addr18==mmu_id)) buf18[acc_in_width-2:0]<=data18[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q18 <= 0;
	else if(en18&!we18&(addr18==mmu_id)) q18<={buf18_msb, (buf18r_en)?mem_q:buf18r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf19_msb;
wire clr19_msb;
assign clr19_msb = clr_msbs[19];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf19_msb<=0;
	else if(clr19_msb) buf19_msb<=0;
	else if(en19&we19&(addr19==mmu_id)) buf19_msb<=data19[acc_in_width-1];
end
reg [acc_in_width-1:0] buf19;
reg [mem_data_width-1:0] buf19r;
wire buf19r_en;
assign buf19r_en = buf_ens[19];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf19r<=0;
	else if(buf19r_en) buf19r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf19[acc_in_width-2:0]<=0;
	else if(en19&we19&(addr19==mmu_id)) buf19[acc_in_width-2:0]<=data19[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q19 <= 0;
	else if(en19&!we19&(addr19==mmu_id)) q19<={buf19_msb, (buf19r_en)?mem_q:buf19r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf20_msb;
wire clr20_msb;
assign clr20_msb = clr_msbs[20];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf20_msb<=0;
	else if(clr20_msb) buf20_msb<=0;
	else if(en20&we20&(addr20==mmu_id)) buf20_msb<=data20[acc_in_width-1];
end
reg [acc_in_width-1:0] buf20;
reg [mem_data_width-1:0] buf20r;
wire buf20r_en;
assign buf20r_en = buf_ens[20];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf20r<=0;
	else if(buf20r_en) buf20r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf20[acc_in_width-2:0]<=0;
	else if(en20&we20&(addr20==mmu_id)) buf20[acc_in_width-2:0]<=data20[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q20 <= 0;
	else if(en20&!we20&(addr20==mmu_id)) q20<={buf20_msb, (buf20r_en)?mem_q:buf20r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf21_msb;
wire clr21_msb;
assign clr21_msb = clr_msbs[21];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf21_msb<=0;
	else if(clr21_msb) buf21_msb<=0;
	else if(en21&we21&(addr21==mmu_id)) buf21_msb<=data21[acc_in_width-1];
end
reg [acc_in_width-1:0] buf21;
reg [mem_data_width-1:0] buf21r;
wire buf21r_en;
assign buf21r_en = buf_ens[21];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf21r<=0;
	else if(buf21r_en) buf21r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf21[acc_in_width-2:0]<=0;
	else if(en21&we21&(addr21==mmu_id)) buf21[acc_in_width-2:0]<=data21[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q21 <= 0;
	else if(en21&!we21&(addr21==mmu_id)) q21<={buf21_msb, (buf21r_en)?mem_q:buf21r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf22_msb;
wire clr22_msb;
assign clr22_msb = clr_msbs[22];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf22_msb<=0;
	else if(clr22_msb) buf22_msb<=0;
	else if(en22&we22&(addr22==mmu_id)) buf22_msb<=data22[acc_in_width-1];
end
reg [acc_in_width-1:0] buf22;
reg [mem_data_width-1:0] buf22r;
wire buf22r_en;
assign buf22r_en = buf_ens[22];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf22r<=0;
	else if(buf22r_en) buf22r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf22[acc_in_width-2:0]<=0;
	else if(en22&we22&(addr22==mmu_id)) buf22[acc_in_width-2:0]<=data22[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q22 <= 0;
	else if(en22&!we22&(addr22==mmu_id)) q22<={buf22_msb, (buf22r_en)?mem_q:buf22r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf23_msb;
wire clr23_msb;
assign clr23_msb = clr_msbs[23];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf23_msb<=0;
	else if(clr23_msb) buf23_msb<=0;
	else if(en23&we23&(addr23==mmu_id)) buf23_msb<=data23[acc_in_width-1];
end
reg [acc_in_width-1:0] buf23;
reg [mem_data_width-1:0] buf23r;
wire buf23r_en;
assign buf23r_en = buf_ens[23];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf23r<=0;
	else if(buf23r_en) buf23r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf23[acc_in_width-2:0]<=0;
	else if(en23&we23&(addr23==mmu_id)) buf23[acc_in_width-2:0]<=data23[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q23 <= 0;
	else if(en23&!we23&(addr23==mmu_id)) q23<={buf23_msb, (buf23r_en)?mem_q:buf23r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf24_msb;
wire clr24_msb;
assign clr24_msb = clr_msbs[24];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf24_msb<=0;
	else if(clr24_msb) buf24_msb<=0;
	else if(en24&we24&(addr24==mmu_id)) buf24_msb<=data24[acc_in_width-1];
end
reg [acc_in_width-1:0] buf24;
reg [mem_data_width-1:0] buf24r;
wire buf24r_en;
assign buf24r_en = buf_ens[24];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf24r<=0;
	else if(buf24r_en) buf24r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf24[acc_in_width-2:0]<=0;
	else if(en24&we24&(addr24==mmu_id)) buf24[acc_in_width-2:0]<=data24[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q24 <= 0;
	else if(en24&!we24&(addr24==mmu_id)) q24<={buf24_msb, (buf24r_en)?mem_q:buf24r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf25_msb;
wire clr25_msb;
assign clr25_msb = clr_msbs[25];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf25_msb<=0;
	else if(clr25_msb) buf25_msb<=0;
	else if(en25&we25&(addr25==mmu_id)) buf25_msb<=data25[acc_in_width-1];
end
reg [acc_in_width-1:0] buf25;
reg [mem_data_width-1:0] buf25r;
wire buf25r_en;
assign buf25r_en = buf_ens[25];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf25r<=0;
	else if(buf25r_en) buf25r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf25[acc_in_width-2:0]<=0;
	else if(en25&we25&(addr25==mmu_id)) buf25[acc_in_width-2:0]<=data25[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q25 <= 0;
	else if(en25&!we25&(addr25==mmu_id)) q25<={buf25_msb, (buf25r_en)?mem_q:buf25r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf26_msb;
wire clr26_msb;
assign clr26_msb = clr_msbs[26];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf26_msb<=0;
	else if(clr26_msb) buf26_msb<=0;
	else if(en26&we26&(addr26==mmu_id)) buf26_msb<=data26[acc_in_width-1];
end
reg [acc_in_width-1:0] buf26;
reg [mem_data_width-1:0] buf26r;
wire buf26r_en;
assign buf26r_en = buf_ens[26];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf26r<=0;
	else if(buf26r_en) buf26r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf26[acc_in_width-2:0]<=0;
	else if(en26&we26&(addr26==mmu_id)) buf26[acc_in_width-2:0]<=data26[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q26 <= 0;
	else if(en26&!we26&(addr26==mmu_id)) q26<={buf26_msb, (buf26r_en)?mem_q:buf26r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf27_msb;
wire clr27_msb;
assign clr27_msb = clr_msbs[27];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf27_msb<=0;
	else if(clr27_msb) buf27_msb<=0;
	else if(en27&we27&(addr27==mmu_id)) buf27_msb<=data27[acc_in_width-1];
end
reg [acc_in_width-1:0] buf27;
reg [mem_data_width-1:0] buf27r;
wire buf27r_en;
assign buf27r_en = buf_ens[27];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf27r<=0;
	else if(buf27r_en) buf27r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf27[acc_in_width-2:0]<=0;
	else if(en27&we27&(addr27==mmu_id)) buf27[acc_in_width-2:0]<=data27[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q27 <= 0;
	else if(en27&!we27&(addr27==mmu_id)) q27<={buf27_msb, (buf27r_en)?mem_q:buf27r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf28_msb;
wire clr28_msb;
assign clr28_msb = clr_msbs[28];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf28_msb<=0;
	else if(clr28_msb) buf28_msb<=0;
	else if(en28&we28&(addr28==mmu_id)) buf28_msb<=data28[acc_in_width-1];
end
reg [acc_in_width-1:0] buf28;
reg [mem_data_width-1:0] buf28r;
wire buf28r_en;
assign buf28r_en = buf_ens[28];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf28r<=0;
	else if(buf28r_en) buf28r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf28[acc_in_width-2:0]<=0;
	else if(en28&we28&(addr28==mmu_id)) buf28[acc_in_width-2:0]<=data28[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q28 <= 0;
	else if(en28&!we28&(addr28==mmu_id)) q28<={buf28_msb, (buf28r_en)?mem_q:buf28r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf29_msb;
wire clr29_msb;
assign clr29_msb = clr_msbs[29];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf29_msb<=0;
	else if(clr29_msb) buf29_msb<=0;
	else if(en29&we29&(addr29==mmu_id)) buf29_msb<=data29[acc_in_width-1];
end
reg [acc_in_width-1:0] buf29;
reg [mem_data_width-1:0] buf29r;
wire buf29r_en;
assign buf29r_en = buf_ens[29];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf29r<=0;
	else if(buf29r_en) buf29r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf29[acc_in_width-2:0]<=0;
	else if(en29&we29&(addr29==mmu_id)) buf29[acc_in_width-2:0]<=data29[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q29 <= 0;
	else if(en29&!we29&(addr29==mmu_id)) q29<={buf29_msb, (buf29r_en)?mem_q:buf29r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf30_msb;
wire clr30_msb;
assign clr30_msb = clr_msbs[30];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf30_msb<=0;
	else if(clr30_msb) buf30_msb<=0;
	else if(en30&we30&(addr30==mmu_id)) buf30_msb<=data30[acc_in_width-1];
end
reg [acc_in_width-1:0] buf30;
reg [mem_data_width-1:0] buf30r;
wire buf30r_en;
assign buf30r_en = buf_ens[30];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf30r<=0;
	else if(buf30r_en) buf30r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf30[acc_in_width-2:0]<=0;
	else if(en30&we30&(addr30==mmu_id)) buf30[acc_in_width-2:0]<=data30[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q30 <= 0;
	else if(en30&!we30&(addr30==mmu_id)) q30<={buf30_msb, (buf30r_en)?mem_q:buf30r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf31_msb;
wire clr31_msb;
assign clr31_msb = clr_msbs[31];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf31_msb<=0;
	else if(clr31_msb) buf31_msb<=0;
	else if(en31&we31&(addr31==mmu_id)) buf31_msb<=data31[acc_in_width-1];
end
reg [acc_in_width-1:0] buf31;
reg [mem_data_width-1:0] buf31r;
wire buf31r_en;
assign buf31r_en = buf_ens[31];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf31r<=0;
	else if(buf31r_en) buf31r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf31[acc_in_width-2:0]<=0;
	else if(en31&we31&(addr31==mmu_id)) buf31[acc_in_width-2:0]<=data31[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q31 <= 0;
	else if(en31&!we31&(addr31==mmu_id)) q31<={buf31_msb, (buf31r_en)?mem_q:buf31r};
end

//a busy bit controlled by both user interface 1 and FSM
reg buf32_msb;
wire clr32_msb;
assign clr32_msb = clr_msbs[32];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf32_msb<=0;
	else if(clr32_msb) buf32_msb<=0;
	else if(en32&we32&(addr32==mmu_id)) buf32_msb<=data32[acc_in_width-1];
end
reg [acc_in_width-1:0] buf32;
reg [mem_data_width-1:0] buf32r;
wire buf32r_en;
assign buf32r_en = buf_ens[32];
always @(negedge rst, posedge clk)
begin
	if(!rst) buf32r<=0;
	else if(buf32r_en) buf32r<=mem_q;
end
always @(negedge rst, posedge clk)
begin
	if(!rst) buf32[acc_in_width-2:0]<=0;
	else if(en32&we32&(addr32==mmu_id)) buf32[acc_in_width-2:0]<=data32[acc_in_width-2:0];
end
always @(negedge rst, posedge clk)
begin
	if(!rst) q32 <= 0;
	else if(en32&!we32&(addr32==mmu_id)) q32<={buf32_msb, (buf32r_en)?mem_q:buf32r};
end

wire [acc_in_width-1:0] buf_arr [32:0];
assign buf_arr[0]=buf0;   assign buf_arr[1]=buf1;   assign buf_arr[2]=buf2;
assign buf_arr[3]=buf3;   assign buf_arr[4]=buf4;   assign buf_arr[5]=buf5;
assign buf_arr[6]=buf6;   assign buf_arr[7]=buf7;   assign buf_arr[8]=buf8;
assign buf_arr[9]=buf9;   assign buf_arr[10]=buf10; assign buf_arr[11]=buf11;
assign buf_arr[12]=buf12; assign buf_arr[13]=buf13; assign buf_arr[14]=buf14;
assign buf_arr[15]=buf15; assign buf_arr[16]=buf16; assign buf_arr[17]=buf17;
assign buf_arr[18]=buf18; assign buf_arr[19]=buf19; assign buf_arr[20]=buf20;
assign buf_arr[21]=buf21; assign buf_arr[22]=buf22; assign buf_arr[23]=buf23;
assign buf_arr[24]=buf24; assign buf_arr[25]=buf25; assign buf_arr[26]=buf26; 
assign buf_arr[27]=buf27; assign buf_arr[28]=buf28; assign buf_arr[29]=buf29; 
assign buf_arr[30]=buf30; assign buf_arr[31]=buf31; assign buf_arr[32]=buf32;

wire [32:0] all_msbs;
assign all_msbs = {buf32_msb,buf31_msb,buf30_msb,buf29_msb,buf28_msb,buf27_msb,buf26_msb,buf25_msb,buf24_msb,buf23_msb,buf22_msb,buf21_msb,buf20_msb,buf19_msb,
buf18_msb,buf17_msb,buf16_msb,buf15_msb,buf14_msb,buf13_msb,buf12_msb,buf11_msb,buf10_msb,buf9_msb,
buf8_msb,buf7_msb,buf6_msb,buf5_msb,buf4_msb,buf3_msb,buf2_msb,buf1_msb,buf0_msb};

reg[4:0] last_winner;

wire [4:0] last_winners [31:0]; //define these nodes just to make it safe for the additions to be 5-bit

assign last_winners[0]  = last_winner;
assign last_winners[1]  = last_winner + 5'd1;
assign last_winners[2]  = last_winner + 5'd2;
assign last_winners[3]  = last_winner + 5'd3;
assign last_winners[4]  = last_winner + 5'd4;
assign last_winners[5]  = last_winner + 5'd5;
assign last_winners[6]  = last_winner + 5'd6;
assign last_winners[7]  = last_winner + 5'd7;
assign last_winners[8]  = last_winner + 5'd8;
assign last_winners[9]  = last_winner + 5'd9;
assign last_winners[10] = last_winner + 5'd10;
assign last_winners[11] = last_winner + 5'd11;
assign last_winners[12] = last_winner + 5'd12;
assign last_winners[13] = last_winner + 5'd13;
assign last_winners[14] = last_winner + 5'd14;
assign last_winners[15] = last_winner + 5'd15;
assign last_winners[16] = last_winner + 5'd16;
assign last_winners[17] = last_winner + 5'd17;
assign last_winners[18] = last_winner + 5'd18;
assign last_winners[19] = last_winner + 5'd19;
assign last_winners[20] = last_winner + 5'd20;
assign last_winners[21] = last_winner + 5'd21;
assign last_winners[22] = last_winner + 5'd22;
assign last_winners[23] = last_winner + 5'd23;
assign last_winners[24] = last_winner + 5'd24;
assign last_winners[25] = last_winner + 5'd25;
assign last_winners[26] = last_winner + 5'd26;
assign last_winners[27] = last_winner + 5'd27;
assign last_winners[28] = last_winner + 5'd28;
assign last_winners[29] = last_winner + 5'd29;
assign last_winners[30] = last_winner + 5'd30;
assign last_winners[31] = last_winner + 5'd31;

reg [5:0] winner; 
//pipeline stage 1
//combinational logic
always @(*)
begin	
        if (all_msbs[32]) winner <= 32; //highest priority to PL master
        else
        begin	        
            if (all_msbs[last_winners[1]])  winner <= last_winners[1];
            else if (all_msbs[last_winners[2]])  winner <= last_winners[2];
            else if (all_msbs[last_winners[3]])  winner <= last_winners[3];
            else if (all_msbs[last_winners[4]])  winner <= last_winners[4];
            else if (all_msbs[last_winners[5]])  winner <= last_winners[5];
            else if (all_msbs[last_winners[6]])  winner <= last_winners[6];
            else if (all_msbs[last_winners[7]])  winner <= last_winners[7];
            else if (all_msbs[last_winners[8]])  winner <= last_winners[8];
            else if (all_msbs[last_winners[9]])  winner <= last_winners[9];
            else if (all_msbs[last_winners[10]]) winner <= last_winners[10];
            else if (all_msbs[last_winners[11]]) winner <= last_winners[11];
            else if (all_msbs[last_winners[12]]) winner <= last_winners[12];
            else if (all_msbs[last_winners[13]]) winner <= last_winners[13];
            else if (all_msbs[last_winners[14]]) winner <= last_winners[14];
            else if (all_msbs[last_winners[15]]) winner <= last_winners[15];
            else if (all_msbs[last_winners[16]]) winner <= last_winners[16];
            else if (all_msbs[last_winners[17]]) winner <= last_winners[17];
            else if (all_msbs[last_winners[18]]) winner <= last_winners[18];
            else if (all_msbs[last_winners[19]]) winner <= last_winners[19];
            else if (all_msbs[last_winners[20]]) winner <= last_winners[20];
            else if (all_msbs[last_winners[21]]) winner <= last_winners[21];
            else if (all_msbs[last_winners[22]]) winner <= last_winners[22];
            else if (all_msbs[last_winners[23]]) winner <= last_winners[23];
            else if (all_msbs[last_winners[24]]) winner <= last_winners[24];
            else if (all_msbs[last_winners[25]]) winner <= last_winners[25];
            else if (all_msbs[last_winners[26]]) winner <= last_winners[26];
            else if (all_msbs[last_winners[27]]) winner <= last_winners[27];
            else if (all_msbs[last_winners[28]]) winner <= last_winners[28];
            else if (all_msbs[last_winners[29]]) winner <= last_winners[29];
            else if (all_msbs[last_winners[30]]) winner <= last_winners[30];
            else if (all_msbs[last_winners[31]]) winner <= last_winners[31];
            else if (all_msbs[last_winners[0]])  winner <= last_winners[0];       
            else winner <= 63;
        end

        clr_msbs <= 33'b0;        
		mem_en <= 0;
		mem_we <= 0;
		mem_addr <= 0;
		mem_data <= 64'b0;
        
        if(winner<33)
        begin
           clr_msbs[winner] <= 1;
           mem_en <= 1;
           mem_we <= buf_arr[winner][acc_in_width-2];
           mem_addr <= buf_arr[winner][mem_data_width+mem_addr_width-1:mem_data_width];
           mem_data <= buf_arr[winner][mem_data_width-1:0]; 
        end                
end

//pipeline stage 1 sequential logic - output
reg [5:0] winner2;
always @(negedge rst, posedge clk)
begin
    if(!rst)
    begin 
        winner2 <= 63;
        last_winner <= 5'd31;
    end
    else
    begin 
        winner2 <= winner; //winner2 always faithfully record the winner
        last_winner <= (winner<32)?winner:last_winner;
    end
end 

//pipeline stage 2
//combinational logic
//note: stage 1's output also includes mem_q, it is automatically locked into a certain bufXr at the end of this stage. 
always @(*)
begin
		buf_ens <= 33'b0;
		if(winner2<33)
		begin
		  buf_ens[winner2] <= ~buf_arr[winner2][acc_in_width-2];
		end
end

endmodule 

