`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/18/2026 10:00:14 AM
// Design Name: 
// Module Name: dma_tester1
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module dma_tester1(rst, clk, tdata, tkeep, tlast, tready, tvalid, curr_state, next_state, writeCnt, base, dma_go);
input rst, clk, tready, dma_go;
output reg [31:0] tdata;
output [3:0] tkeep;
output reg tlast;
output reg tvalid;
output [4:0] curr_state, next_state;
output [10:0] writeCnt;
output [31:0] base;

assign tkeep = 4'b1111;

localparam state_init = 0;
localparam state_prep = 1;
localparam state_check = 2;
localparam state_write = 3;
localparam state_update = 4;

reg[4:0] curr_state, next_state;

always @(negedge rst, posedge clk)
begin
    if(!rst) curr_state <= state_init;
    else curr_state <= next_state;
end

reg[31:0] timer;
always @(negedge rst, posedge clk)
begin
    if(!rst) timer <= 0;
    else
    begin
        if(timer<32'd2700000000) timer <= timer + 1;
        else timer <= timer;
    end
end

reg writeCtrl, writeClr;
reg bclk;
always @(*)
begin
    case(curr_state)
    state_init:
    begin
        next_state <= state_prep; //(timer<32'd2690000000)?state_init:state_prep;
        writeCtrl <= 0;
        writeClr <= 1;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 1;
        tdata <= 32'b0;
    end
    state_prep:
    begin
        next_state <= (dma_go)?state_check:state_prep;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0; //every round should have a different base
        tdata <= 32'b0;
    end
    state_check:
    begin
        next_state <= state_write;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= writeCnt + base;
    end
    state_write:
    begin
        next_state <= (tready)?state_update:state_write;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= (writeCnt==1023)?1:0;
        tvalid <= 1;
        bclk <= 0;
        tdata <= writeCnt + base;
    end
    state_update:
    begin    
        next_state <= (writeCnt<1023)?state_check:state_init;
        writeCtrl <= 1;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= writeCnt + base;
    end
    default:
    begin
        next_state <= state_init;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 32'b0;    
    end
    endcase
end

localparam maxCnt = 1050;
reg[10:0] writeCnt;
always @(negedge rst, posedge clk)
begin
    if(!rst) writeCnt <= 0;
    else if(writeClr) writeCnt <= 0;
    else if(writeCtrl)
    begin
        if(writeCnt<maxCnt) writeCnt <= writeCnt + 1;
        else writeCnt <= writeCnt;
    end
    else writeCnt <= writeCnt;
end

reg[31:0] base;
always @(negedge rst, posedge bclk)
begin
    if(!rst) base <= 0;
    else base <= base + 1;
end

endmodule
