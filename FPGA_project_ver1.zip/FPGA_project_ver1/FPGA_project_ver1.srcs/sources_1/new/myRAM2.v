`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/22/2026 01:37:31 PM
// Design Name: 
// Module Name: myRAM2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
module myRAM2(clk_a, en_a, wr_a, addr_a, data_a, q_a);
input clk_a, en_a;
input [3:0] wr_a;
input [18:0] addr_a;
input [31:0] data_a;
output reg [31:0] q_a;

reg [31:0] mem [524287:0]; //512K Words, 2M Bytes

always @(posedge clk_a)
begin
    if(en_a)
    begin
        if(|wr_a)
        begin    
            mem[addr_a] <= data_a;
            q_a <= data_a;
        end
        else
        begin
            q_a <= mem[addr_a];
        end
    end
end

endmodule