`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06/08/2026 06:35:57 PM
// Design Name: 
// Module Name: mutex
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
/*
module mutex (
    input  wire clk,
    input  wire rst,
    input  wire req0, rel0, output reg grant0,
    input  wire req1, rel1, output reg grant1,
    input  wire req2, rel2, output reg grant2,
    input  wire req3, rel3, output reg grant3,
    input  wire req4, rel4, output reg grant4
);
    reg        locked;
    reg [2:0]  owner;
    reg [2:0]  next_priority;   // which master gets first look next time

    wire [4:0] req = {req4, req3, req2, req1, req0};
    wire [4:0] rel = {rel4, rel3, rel2, rel1, rel0};

    // Rotate the request vector so next_priority lands at bit 0,
    // then find the lowest set bit - that master wins.
    // We do this combinatorially so the always block stays clean.
    wire [9:0] req_doubled  = {req, req};               // duplicate for rotation
    wire [9:0] rot          = req_doubled >> next_priority; // rotate right
    wire [4:0] req_rotated  = rot[4:0];

    // Priority-encode the rotated requests (lowest bit wins)
    reg  [2:0] winner_rotated;
    always @(*) begin
        casez (req_rotated)
            5'b????1: winner_rotated = 3'd0;
            5'b???10: winner_rotated = 3'd1;
            5'b??100: winner_rotated = 3'd2;
            5'b?1000: winner_rotated = 3'd3;
            5'b10000: winner_rotated = 3'd4;
            default:  winner_rotated = 3'd0;
        endcase
    end

    // Un-rotate to get the real master index
    wire [2:0] winner = (winner_rotated + next_priority) % 5;

    always @(negedge rst, posedge clk) begin
        if (!rst) begin
            locked        <= 1'b0;
            owner         <= 3'b000;
            next_priority <= 3'b000;
            grant0 <= 0; grant1 <= 0; grant2 <= 0; grant3 <= 0; grant4 <= 0;
        end
        else begin
            //--------------------------------------------------
            // Release
            //--------------------------------------------------
            if (locked && rel[owner]) begin
                locked     <= 1'b0;
                // Next round starts from the master AFTER the current owner
                next_priority <= (owner == 3'd4) ? 3'd0 : owner + 3'd1;
                case (owner)
                    3'd0: grant0 <= 0;
                    3'd1: grant1 <= 0;
                    3'd2: grant2 <= 0;
                    3'd3: grant3 <= 0;
                    3'd4: grant4 <= 0;
                endcase
            end
            //--------------------------------------------------
            // Acquire
            //--------------------------------------------------
            else if (!locked && (req != 5'b0)) begin
                locked <= 1'b1;
                owner  <= winner;
                case (winner)
                    3'd0: grant0 <= 1;
                    3'd1: grant1 <= 1;
                    3'd2: grant2 <= 1;
                    3'd3: grant3 <= 1;
                    3'd4: grant4 <= 1;
                endcase
            end
        end
    end
endmodule
*/


module mutex (
    input  wire clk,
    input  wire rst,

    // 0 interface
    input  wire req0,
    input  wire rel0,
    output reg  grant0,

    // 1 interface
    input  wire req1,
    input  wire rel1,
    output reg  grant1,
    
    // 2 interface
    input  wire req2,
    input  wire rel2,
    output reg  grant2,

    // Master 3 interface
    input  wire req3,
    input  wire rel3,
    output reg  grant3,
    
    // Master 4 interface
    input  wire req4,
    input  wire rel4,
    output reg  grant4,

    // Master 0 interface
    input  wire req5,
    input  wire rel5,
    output reg  grant5,

    // Master 1 interface
    input  wire req6,
    input  wire rel6,
    output reg  grant6,
    
    // Master 2 interface
    input  wire req7,
    input  wire rel7,
    output reg  grant7,

    // Master 3 interface
    input  wire req8,
    input  wire rel8,
    output reg  grant8,
    
    // Master 4 interface
    input  wire req9,
    input  wire rel9,
    output reg  grant9, 
    
    // Master 0 interface
    input  wire req10,
    input  wire rel10,
    output reg  grant10,

    // Master 1 interface
    input  wire req11,
    input  wire rel11,
    output reg  grant11,
    
    // Master 2 interface
    input  wire req12,
    input  wire rel12,
    output reg  grant12,

    // Master 3 interface
    input  wire req13,
    input  wire rel13,
    output reg  grant13,
    
    // Master 4 interface
    input  wire req14,
    input  wire rel14,
    output reg  grant14, 
    
    // Master 0 interface
    input  wire req15,
    input  wire rel15,
    output reg  grant15                  
);

    reg locked;
    reg [3:0] owner;

    always @(negedge rst, posedge clk) begin
        if (!rst) begin
            locked <= 1'b0;
            owner  <= 4'b0000;
            grant0 <= 1'b0;
            grant1 <= 1'b0;
            grant2 <= 1'b0;
            grant3 <= 1'b0;
            grant4 <= 1'b0;
            grant5 <= 1'b0;
            grant6 <= 1'b0;
            grant7 <= 1'b0;
            grant8 <= 1'b0;
            grant9 <= 1'b0;
            grant10 <= 1'b0;
            grant11 <= 1'b0;
            grant12 <= 1'b0;
            grant13 <= 1'b0;
            grant14 <= 1'b0;
            grant15 <= 1'b0;                        
        end
        else begin

            //--------------------------------------------------
            // Release
            //--------------------------------------------------
            if (locked) begin
                if ((owner == 4'b0000) && rel0) begin
                    locked <= 1'b0;
                    grant0 <= 1'b0;
                end

                if ((owner == 4'b0001) && rel1) begin
                    locked <= 1'b0;
                    grant1 <= 1'b0;
                end

                if ((owner == 4'b0010) && rel2) begin
                    locked <= 1'b0;
                    grant2 <= 1'b0;
                end

                if ((owner == 4'b0011) && rel3) begin
                    locked <= 1'b0;
                    grant3 <= 1'b0;
                end                

                if ((owner == 4'b0100) && rel4) begin
                    locked <= 1'b0;
                    grant4 <= 1'b0;
                end
                
                if ((owner == 4'b0101) && rel5) begin
                    locked <= 1'b0;
                    grant5 <= 1'b0;
                end

                if ((owner == 4'b0110) && rel6) begin
                    locked <= 1'b0;
                    grant6 <= 1'b0;
                end

                if ((owner == 4'b0111) && rel7) begin
                    locked <= 1'b0;
                    grant7 <= 1'b0;
                end

                if ((owner == 4'b1000) && rel8) begin
                    locked <= 1'b0;
                    grant8 <= 1'b0;
                end                

                if ((owner == 4'b1001) && rel9) begin
                    locked <= 1'b0;
                    grant9 <= 1'b0;
                end
                
                if ((owner == 4'b1010) && rel0) begin
                    locked <= 1'b0;
                    grant10 <= 1'b0;
                end

                if ((owner == 4'b1011) && rel11) begin
                    locked <= 1'b0;
                    grant11 <= 1'b0;
                end

                if ((owner == 4'b1100) && rel12) begin
                    locked <= 1'b0;
                    grant12 <= 1'b0;
                end

                if ((owner == 4'b1101) && rel13) begin
                    locked <= 1'b0;
                    grant13 <= 1'b0;
                end                

                if ((owner == 4'b1110) && rel14) begin
                    locked <= 1'b0;
                    grant14 <= 1'b0;
                end
                
                if ((owner == 4'b1111) && rel15) begin
                    locked <= 1'b0;
                    grant15 <= 1'b0;
                end                               
            end

            //--------------------------------------------------
            // Acquire
            //--------------------------------------------------
            else begin
                // fixed priority
                if (req0) begin
                    locked <= 1'b1;
                    owner  <= 4'b0000;
                    grant0 <= 1'b1;
                end
                else if (req1) begin
                    locked <= 1'b1;
                    owner  <= 4'b0001;
                    grant1 <= 1'b1;
                end
                else if (req2) begin
                    locked <= 1'b1;
                    owner  <= 4'b0010;
                    grant2 <= 1'b1;
                end
                else if (req3) begin
                    locked <= 1'b1;
                    owner  <= 4'b0011;
                    grant3 <= 1'b1;
                end
                else if (req4) begin
                    locked <= 1'b1;
                    owner  <= 4'b0100;
                    grant4 <= 1'b1;
                end
                else if (req5) begin
                    locked <= 1'b1;
                    owner  <= 4'b0101;
                    grant5 <= 1'b1;
                end
                else if (req6) begin
                    locked <= 1'b1;
                    owner  <= 4'b0110;
                    grant6 <= 1'b1;
                end
                else if (req7) begin
                    locked <= 1'b1;
                    owner  <= 4'b0111;
                    grant7 <= 1'b1;
                end
                else if (req8) begin
                    locked <= 1'b1;
                    owner  <= 4'b1000;
                    grant8 <= 1'b1;
                end
                else if (req9) begin
                    locked <= 1'b1;
                    owner  <= 4'b1001;
                    grant9 <= 1'b1;
                end
                else if (req10) begin
                    locked <= 1'b1;
                    owner  <= 4'b1010;
                    grant10 <= 1'b1;
                end
                else if (req11) begin
                    locked <= 1'b1;
                    owner  <= 4'b1011;
                    grant11 <= 1'b1;
                end
                else if (req12) begin
                    locked <= 1'b1;
                    owner  <= 4'b1100;
                    grant12 <= 1'b1;
                end
                else if (req13) begin
                    locked <= 1'b1;
                    owner  <= 4'b1101;
                    grant13 <= 1'b1;
                end
                else if (req14) begin
                    locked <= 1'b1;
                    owner  <= 4'b1110;
                    grant14 <= 1'b1;
                end
                else if (req15) begin
                    locked <= 1'b1;
                    owner  <= 4'b1111;
                    grant15 <= 1'b1;
                end                                                                                 
            end
        end
    end
endmodule

/*
module mutex (
    input  wire clk,
    input  wire rst,

    input  wire req0,
    input  wire rel0,
    output wire grant0,

    input  wire req1,
    input  wire rel1,
    output wire grant1,

    input  wire req2,
    input  wire rel2,
    output wire grant2,

    input  wire req3,
    input  wire rel3,
    output wire grant3,

    input  wire req4,
    input  wire rel4,
    output wire grant4
);

    //------------------------------------------------------------
    // State
    //------------------------------------------------------------
    reg        locked;
    reg [2:0]  owner;
    reg [2:0]  next_priority;

    wire [4:0] req = {req4, req3, req2, req1, req0};
    wire [4:0] rel = {rel4, rel3, rel2, rel1, rel0};

    //------------------------------------------------------------
    // Combinational winner selection (round robin)
    //------------------------------------------------------------
    reg [2:0] winner;
    reg       winner_valid;

    always @(*) begin
        winner       = 3'd0;
        winner_valid = 1'b0;

        case (next_priority)

            // Start searching from 0
            3'd0: begin
                if      (req0) begin winner=0; winner_valid=1; end
                else if (req1) begin winner=1; winner_valid=1; end
                else if (req2) begin winner=2; winner_valid=1; end
                else if (req3) begin winner=3; winner_valid=1; end
                else if (req4) begin winner=4; winner_valid=1; end
            end

            // Start searching from 1
            3'd1: begin
                if      (req1) begin winner=1; winner_valid=1; end
                else if (req2) begin winner=2; winner_valid=1; end
                else if (req3) begin winner=3; winner_valid=1; end
                else if (req4) begin winner=4; winner_valid=1; end
                else if (req0) begin winner=0; winner_valid=1; end
            end

            // Start searching from 2
            3'd2: begin
                if      (req2) begin winner=2; winner_valid=1; end
                else if (req3) begin winner=3; winner_valid=1; end
                else if (req4) begin winner=4; winner_valid=1; end
                else if (req0) begin winner=0; winner_valid=1; end
                else if (req1) begin winner=1; winner_valid=1; end
            end

            // Start searching from 3
            3'd3: begin
                if      (req3) begin winner=3; winner_valid=1; end
                else if (req4) begin winner=4; winner_valid=1; end
                else if (req0) begin winner=0; winner_valid=1; end
                else if (req1) begin winner=1; winner_valid=1; end
                else if (req2) begin winner=2; winner_valid=1; end
            end

            // Start searching from 4
            3'd4: begin
                if      (req4) begin winner=4; winner_valid=1; end
                else if (req0) begin winner=0; winner_valid=1; end
                else if (req1) begin winner=1; winner_valid=1; end
                else if (req2) begin winner=2; winner_valid=1; end
                else if (req3) begin winner=3; winner_valid=1; end
            end

            default: begin
                winner       = 3'd0;
                winner_valid = 1'b0;
            end
        endcase
    end

    //------------------------------------------------------------
    // Sequential state update
    //------------------------------------------------------------
    always @(posedge clk or negedge rst) begin
        if (!rst) begin
            locked        <= 1'b0;
            owner         <= 3'd0;
            next_priority <= 3'd0;
        end
        else begin

            //----------------------------------------
            // Release
            //----------------------------------------
            if (locked && rel[owner]) begin

                // If another request pending, hand off immediately
                if (winner_valid) begin
                    owner  <= winner;
                    locked <= 1'b1;

                    // next priority = winner+1 (wrap)
                    if (winner == 3'd4)
                        next_priority <= 3'd0;
                    else
                        next_priority <= winner + 3'd1;
                end
                else begin
                    locked <= 1'b0;

                    if (owner == 3'd4)
                        next_priority <= 3'd0;
                    else
                        next_priority <= owner + 3'd1;
                end
            end

            //----------------------------------------
            // Acquire
            //----------------------------------------
            else if (!locked && winner_valid) begin
                locked <= 1'b1;
                owner  <= winner;
            end
        end
    end

    //------------------------------------------------------------
    // Grants derived from state
    //------------------------------------------------------------
    assign grant0 = locked && (owner == 3'd0);
    assign grant1 = locked && (owner == 3'd1);
    assign grant2 = locked && (owner == 3'd2);
    assign grant3 = locked && (owner == 3'd3);
    assign grant4 = locked && (owner == 3'd4);

endmodule*/


