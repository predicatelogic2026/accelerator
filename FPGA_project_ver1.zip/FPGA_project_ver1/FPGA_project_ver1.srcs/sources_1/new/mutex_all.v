`timescale 1ns / 1ps

module mutex_all (
    input  wire clk,
    input  wire rst,

    input  wire req0,   input wire rel0,   output reg grant0,
    input  wire req1,   input wire rel1,   output reg grant1,
    input  wire req2,   input wire rel2,   output reg grant2,
    input  wire req3,   input wire rel3,   output reg grant3,
    input  wire req4,   input wire rel4,   output reg grant4,
    input  wire req5,   input wire rel5,   output reg grant5,
    input  wire req6,   input wire rel6,   output reg grant6,
    input  wire req7,   input wire rel7,   output reg grant7,
    input  wire req8,   input wire rel8,   output reg grant8,
    input  wire req9,   input wire rel9,   output reg grant9,
    input  wire req10,  input wire rel10,  output reg grant10,
    input  wire req11,  input wire rel11,  output reg grant11,
    input  wire req12,  input wire rel12,  output reg grant12,
    input  wire req13,  input wire rel13,  output reg grant13,
    input  wire req14,  input wire rel14,  output reg grant14,
    input  wire req15,  input wire rel15,  output reg grant15,
    input  wire req16,  input wire rel16,  output reg grant16,
    input  wire req17,  input wire rel17,  output reg grant17,
    input  wire req18,  input wire rel18,  output reg grant18,
    input  wire req19,  input wire rel19,  output reg grant19,
    input  wire req20,  input wire rel20,  output reg grant20,
    input  wire req21,  input wire rel21,  output reg grant21,
    input  wire req22,  input wire rel22,  output reg grant22,
    input  wire req23,  input wire rel23,  output reg grant23,
    input  wire req24,  input wire rel24,  output reg grant24,
    input  wire req25,  input wire rel25,  output reg grant25,
    input  wire req26,  input wire rel26,  output reg grant26,
    input  wire req27,  input wire rel27,  output reg grant27,
    input  wire req28,  input wire rel28,  output reg grant28,
    input  wire req29,  input wire rel29,  output reg grant29,
    input  wire req30,  input wire rel30,  output reg grant30,
    input  wire req31,  input wire rel31,  output reg grant31
);

    reg locked;
    reg [4:0] owner;

    always @(posedge clk or negedge rst)
    begin
        if (!rst)
        begin
            locked  <= 1'b0;
            owner   <= 5'b00000;
            grant0  <= 1'b0;
            grant1  <= 1'b0;
            grant2  <= 1'b0;
            grant3  <= 1'b0;
            grant4  <= 1'b0;
            grant5  <= 1'b0;
            grant6  <= 1'b0;
            grant7  <= 1'b0;
            grant8  <= 1'b0;
            grant9  <= 1'b0;
            grant10 <= 1'b0;
            grant11 <= 1'b0;
            grant12 <= 1'b0;
            grant13 <= 1'b0;
            grant14 <= 1'b0;
            grant15 <= 1'b0;
            grant16 <= 1'b0;
            grant17 <= 1'b0;
            grant18 <= 1'b0;
            grant19 <= 1'b0;
            grant20 <= 1'b0;
            grant21 <= 1'b0;
            grant22 <= 1'b0;
            grant23 <= 1'b0;
            grant24 <= 1'b0;
            grant25 <= 1'b0;
            grant26 <= 1'b0;
            grant27 <= 1'b0;
            grant28 <= 1'b0;
            grant29 <= 1'b0;
            grant30 <= 1'b0;
            grant31 <= 1'b0;            
        end
        else
        begin

            //--------------------------------------------------
            // LOCKED : wait for release
            //--------------------------------------------------
            if (locked)
            begin
                case(owner)

                    5'b00000: if (rel0)  begin locked <= 1'b0; owner <= 5'b00000; grant0  <= 1'b0; end
                    5'b00001: if (rel1)  begin locked <= 1'b0; owner <= 5'b00000; grant1  <= 1'b0; end
                    5'b00010: if (rel2)  begin locked <= 1'b0; owner <= 5'b00000; grant2  <= 1'b0; end
                    5'b00011: if (rel3)  begin locked <= 1'b0; owner <= 5'b00000; grant3  <= 1'b0; end
                    5'b00100: if (rel4)  begin locked <= 1'b0; owner <= 5'b00000; grant4  <= 1'b0; end
                    5'b00101: if (rel5)  begin locked <= 1'b0; owner <= 5'b00000; grant5  <= 1'b0; end
                    5'b00110: if (rel6)  begin locked <= 1'b0; owner <= 5'b00000; grant6  <= 1'b0; end
                    5'b00111: if (rel7)  begin locked <= 1'b0; owner <= 5'b00000; grant7  <= 1'b0; end
                    5'b01000: if (rel8)  begin locked <= 1'b0; owner <= 5'b00000; grant8  <= 1'b0; end
                    5'b01001: if (rel9)  begin locked <= 1'b0; owner <= 5'b00000; grant9  <= 1'b0; end
                    5'b01010: if (rel10) begin locked <= 1'b0; owner <= 5'b00000; grant10 <= 1'b0; end
                    5'b01011: if (rel11) begin locked <= 1'b0; owner <= 5'b00000; grant11 <= 1'b0; end
                    5'b01100: if (rel12) begin locked <= 1'b0; owner <= 5'b00000; grant12 <= 1'b0; end
                    5'b01101: if (rel13) begin locked <= 1'b0; owner <= 5'b00000; grant13 <= 1'b0; end
                    5'b01110: if (rel14) begin locked <= 1'b0; owner <= 5'b00000; grant14 <= 1'b0; end
                    5'b01111: if (rel15) begin locked <= 1'b0; owner <= 5'b00000; grant15 <= 1'b0; end
                    5'b10000: if (rel16) begin locked <= 1'b0; owner <= 5'b00000; grant16 <= 1'b0; end
                    5'b10001: if (rel17) begin locked <= 1'b0; owner <= 5'b00000; grant17 <= 1'b0; end
                    5'b10010: if (rel18) begin locked <= 1'b0; owner <= 5'b00000; grant18 <= 1'b0; end
                    5'b10011: if (rel19) begin locked <= 1'b0; owner <= 5'b00000; grant19 <= 1'b0; end
                    5'b10100: if (rel20) begin locked <= 1'b0; owner <= 5'b00000; grant20 <= 1'b0; end
                    5'b10101: if (rel21) begin locked <= 1'b0; owner <= 5'b00000; grant21 <= 1'b0; end
                    5'b10110: if (rel22) begin locked <= 1'b0; owner <= 5'b00000; grant22 <= 1'b0; end
                    5'b10111: if (rel23) begin locked <= 1'b0; owner <= 5'b00000; grant23 <= 1'b0; end
                    5'b11000: if (rel24) begin locked <= 1'b0; owner <= 5'b00000; grant24 <= 1'b0; end
                    5'b11001: if (rel25) begin locked <= 1'b0; owner <= 5'b00000; grant25 <= 1'b0; end
                    5'b11010: if (rel26) begin locked <= 1'b0; owner <= 5'b00000; grant26 <= 1'b0; end
                    5'b11011: if (rel27) begin locked <= 1'b0; owner <= 5'b00000; grant27 <= 1'b0; end
                    5'b11100: if (rel28) begin locked <= 1'b0; owner <= 5'b00000; grant28 <= 1'b0; end
                    5'b11101: if (rel29) begin locked <= 1'b0; owner <= 5'b00000; grant29 <= 1'b0; end
                    5'b11110: if (rel30) begin locked <= 1'b0; owner <= 5'b00000; grant30 <= 1'b0; end
                    5'b11111: if (rel31) begin locked <= 1'b0; owner <= 5'b00000; grant31 <= 1'b0; end
                    default:
                    begin
                        locked <= 1'b0;
                    end

                endcase
            end

            //--------------------------------------------------
            // UNLOCKED : acquire
            //--------------------------------------------------
            else
            begin
                grant0  <= 1'b0;
                grant1  <= 1'b0;
                grant2  <= 1'b0;
                grant3  <= 1'b0;
                grant4  <= 1'b0;
                grant5  <= 1'b0;
                grant6  <= 1'b0;
                grant7  <= 1'b0;
                grant8  <= 1'b0;
                grant9  <= 1'b0;
                grant10 <= 1'b0;
                grant11 <= 1'b0;
                grant12 <= 1'b0;
                grant13 <= 1'b0;
                grant14 <= 1'b0;
                grant15 <= 1'b0;
                grant16 <= 1'b0;
                grant17 <= 1'b0;
                grant18 <= 1'b0;
                grant19 <= 1'b0;
                grant20 <= 1'b0;
                grant21 <= 1'b0;
                grant22 <= 1'b0;
                grant23 <= 1'b0;
                grant24 <= 1'b0;
                grant25 <= 1'b0;
                grant26 <= 1'b0;
                grant27 <= 1'b0;
                grant28 <= 1'b0;
                grant29 <= 1'b0;
                grant30 <= 1'b0;
                grant31 <= 1'b0;                

                if (req0)       begin locked <= 1'b1; owner <= 5'b00000; grant0  <= 1'b1; end
                else if (req1)  begin locked <= 1'b1; owner <= 5'b00001; grant1  <= 1'b1; end
                else if (req2)  begin locked <= 1'b1; owner <= 5'b00010; grant2  <= 1'b1; end
                else if (req3)  begin locked <= 1'b1; owner <= 5'b00011; grant3  <= 1'b1; end
                else if (req4)  begin locked <= 1'b1; owner <= 5'b00100; grant4  <= 1'b1; end
                else if (req5)  begin locked <= 1'b1; owner <= 5'b00101; grant5  <= 1'b1; end
                else if (req6)  begin locked <= 1'b1; owner <= 5'b00110; grant6  <= 1'b1; end
                else if (req7)  begin locked <= 1'b1; owner <= 5'b00111; grant7  <= 1'b1; end
                else if (req8)  begin locked <= 1'b1; owner <= 5'b01000; grant8  <= 1'b1; end
                else if (req9)  begin locked <= 1'b1; owner <= 5'b01001; grant9  <= 1'b1; end
                else if (req10) begin locked <= 1'b1; owner <= 5'b01010; grant10 <= 1'b1; end
                else if (req11) begin locked <= 1'b1; owner <= 5'b01011; grant11 <= 1'b1; end
                else if (req12) begin locked <= 1'b1; owner <= 5'b01100; grant12 <= 1'b1; end
                else if (req13) begin locked <= 1'b1; owner <= 5'b01101; grant13 <= 1'b1; end
                else if (req14) begin locked <= 1'b1; owner <= 5'b01110; grant14 <= 1'b1; end
                else if (req15) begin locked <= 1'b1; owner <= 5'b01111; grant15 <= 1'b1; end
                else if (req16) begin locked <= 1'b1; owner <= 5'b10000; grant16 <= 1'b1; end
                else if (req17) begin locked <= 1'b1; owner <= 5'b10001; grant17 <= 1'b1; end
                else if (req18) begin locked <= 1'b1; owner <= 5'b10010; grant18 <= 1'b1; end
                else if (req19) begin locked <= 1'b1; owner <= 5'b10011; grant19 <= 1'b1; end
                else if (req20) begin locked <= 1'b1; owner <= 5'b10100; grant20 <= 1'b1; end
                else if (req21) begin locked <= 1'b1; owner <= 5'b10101; grant21 <= 1'b1; end
                else if (req22) begin locked <= 1'b1; owner <= 5'b10110; grant22 <= 1'b1; end
                else if (req23) begin locked <= 1'b1; owner <= 5'b10111; grant23 <= 1'b1; end
                else if (req24) begin locked <= 1'b1; owner <= 5'b11000; grant24 <= 1'b1; end
                else if (req25) begin locked <= 1'b1; owner <= 5'b11001; grant25 <= 1'b1; end
                else if (req26) begin locked <= 1'b1; owner <= 5'b11010; grant26 <= 1'b1; end
                else if (req27) begin locked <= 1'b1; owner <= 5'b11011; grant27 <= 1'b1; end
                else if (req28) begin locked <= 1'b1; owner <= 5'b11100; grant28 <= 1'b1; end
                else if (req29) begin locked <= 1'b1; owner <= 5'b11101; grant29 <= 1'b1; end
                else if (req30) begin locked <= 1'b1; owner <= 5'b11110; grant30 <= 1'b1; end
                else if (req31) begin locked <= 1'b1; owner <= 5'b11111; grant31 <= 1'b1; end                
            end
        end
    end

endmodule