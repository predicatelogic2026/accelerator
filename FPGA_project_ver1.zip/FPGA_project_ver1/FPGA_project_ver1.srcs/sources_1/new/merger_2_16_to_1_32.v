`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/12/2026 08:26:11 PM
// Design Name: 
// Module Name: merger_2_16_to_1_32
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module merger_2_16_to_1_32(in1, in2, res);
input [15:0] in1, in2;
output [31:0] res;

assign res = {in2, in1};

endmodule
