`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06/13/2026 10:31:33 AM
// Design Name: 
// Module Name: bytes_to_word
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module bytes_to_word(in0, in1, in2, in3, out_all);
input[7:0] in0, in1, in2, in3;
output [31:0] out_all;
assign out_all = {in3, in2, in1, in0};
endmodule
