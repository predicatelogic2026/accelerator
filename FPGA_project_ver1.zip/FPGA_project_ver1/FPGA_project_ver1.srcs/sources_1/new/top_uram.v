//  Xilinx UltraRAM Single Port Write First Mode (No Pipeline Registers)
//  This code implements a parameterizable UltraRAM block in write first mode.
//  When data is written, the new memory contents at the write address are
//  presented on the output port in the SAME clock cycle.
//
module top_uram #(
  parameter AWIDTH = 12,  // Address Width (max 12 for single URAM)
  parameter DWIDTH = 32   // Data Width (max 72 for single URAM)
 ) ( 
    input clk,                    // Clock 
    input we,                     // Write Enable
    input mem_en,                 // Memory Enable
    input [DWIDTH-1:0] din,       // Data Input  
    input [AWIDTH-1:0] addr,      // Address Input
    output reg [DWIDTH-1:0] dout  // Data Output (direct, no register)
   );

(* ram_style = "ultra" *)
reg [DWIDTH-1:0] mem[(1<<AWIDTH)-1:0];  // Memory Declaration

// RAM: Both READ and WRITE have one clock cycle latency
// Output appears in same cycle as read operation
always @ (posedge clk)
begin
  if(mem_en) 
  begin
    if(we)
    begin
      mem[addr] <= din;
      // Write First Mode: Output gets the newly written data
      dout <= din;
    end
    else
    begin
      // Read operation: Output gets data from memory
      dout <= mem[addr];
    end
  end
end

endmodule
