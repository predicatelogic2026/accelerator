`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06/03/2026 09:10:36 AM
// Design Name: 
// Module Name: q_mplex
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module q_mplex(clk, we, en, addr, r0, r1, r2, r3, r4, r5, r6, r7, r8, q_out);
input clk, we, en;
input [3:0] addr;
input [64:0] r0, r1, r2, r3, r4, r5, r6, r7, r8;
output reg [64:0] q_out;

wire [64:0] r[8:0];
assign r[0] = r0;
assign r[1] = r1;
assign r[2] = r2;
assign r[3] = r3;
assign r[4] = r4;
assign r[5] = r5;
assign r[6] = r6;
assign r[7] = r7;
assign r[8] = r8;

reg[3:0] addr_buf;
//this module is the cost of using explicit multiplexing
//multiplexing takes effect after read address is locked
always @(posedge clk)
begin
    if(en&~we) addr_buf <= addr;
end

always @(addr_buf, r0, r1, r2, r3, r4, r5, r6, r7, r8)
begin
    q_out <= (addr_buf<9)?r[addr_buf]:0;
end

endmodule
