`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06/09/2026 04:20:57 PM
// Design Name: 
// Module Name: brancher4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module brancher4(in0, in1, in2, in3, out_all);
input in0, in1, in2, in3;
output [3:0] out_all;
assign out_all = {in3, in2, in1, in0};
endmodule
