module bram_sp #(
    parameter AWIDTH = 12,
    parameter DWIDTH = 64
)(
    input clk,

    input                  en,
    input                  we,
    input  [DWIDTH-1:0]    din,
    input  [AWIDTH-1:0]    addr,
    output reg [DWIDTH-1:0] dout
);

(* ram_style = "block" *)
reg [DWIDTH-1:0] mem[(1<<AWIDTH)-1:0];

always @(posedge clk) begin

    if (en) begin
        if (we) begin
            mem[addr] <= din;
            dout <= din;   // write-first
        end
        else begin
            dout <= mem[addr];
        end
    end
end

endmodule