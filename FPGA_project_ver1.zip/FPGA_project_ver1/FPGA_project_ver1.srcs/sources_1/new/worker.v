`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06/05/2026 08:04:21 PM
// Design Name: 
// Module Name: worker
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module worker #(
parameter sel_facts = 0,
parameter sel_facts_b = 1,
parameter sel_used = 2,
parameter sel_used_b = 3,
parameter sel_new_facts = 4, 
parameter sel_new_used = 5,
parameter sel_rules = 6,
parameter sel_rule_nargs = 7,
parameter sel_active = 8,
parameter vb = 32768,
parameter worker_id = 0,
parameter total_workers = 1
)
(rst, clk, data_ready, zero, nc, na, 
mmu_en, mmu_we, mmu_sel, mmu_data, mmu_q, done, req, rel, grant,
req_a, rel_a, grant_a, debug);

input rst, clk, data_ready, zero;
input [31:0] nc, na;
output reg mmu_en, mmu_we;
output reg [3:0] mmu_sel;
output reg [83:0] mmu_data;
input [64:0] mmu_q;
output reg done;
output reg req, rel; //for acquiring and releasing lock
input grant;

output reg req_a, rel_a;
input grant_a;

input [7:0] debug;

//careful: some states are numbers must be related as they are to guarantee correctness
//do NOT change without checking

localparam state_idle = 0;
localparam state_prep = 1;
localparam state_init = 2;
localparam state_main = 3;
localparam state_read_rule_index = 4;
localparam state_rule_index_lock = 5;
localparam state_read_rule = 6;
localparam state_rule_lock = 7;
localparam state_read_nargs = 8;
localparam state_nargs_lock = 9;
localparam state_check_pc = 10;
localparam state_counter_reset = 11;
localparam state_assign_args = 12;
localparam state_check_premises = 13;
localparam state_read_used = 14;
localparam state_used_lock = 15;
localparam state_check_used = 16;
localparam state_read_fact = 17;
localparam state_fact_lock = 18;
localparam state_check_fact = 19;
localparam state_check_conclusions = 20;
localparam state_read_used_again = 21;
localparam state_used_lock_again = 22;
localparam state_check_used_again = 23;
localparam state_read_fact_again = 24;
localparam state_fact_lock_again = 25;
localparam state_check_fact_again = 26;
localparam state_insert_prep = 27;
localparam state_read_new_used = 28;
localparam state_new_used_lock = 29;
localparam state_check_new_used = 30;
localparam state_read_new_fact = 31;
localparam state_new_fact_lock = 32;
localparam state_check_new_fact = 33;
localparam state_write_new_fact = 34;
localparam state_write_new_used = 35;
localparam state_read_new_count = 36;
localparam state_new_count_lock = 37;
localparam state_write_new_count = 38;
localparam state_release_lock = 39;
localparam state_insert_done = 40;
localparam state_pc_update = 41;
localparam state_ai_inc = 42;
localparam state_acquire_active_lock = 43;
localparam state_release_active_lock = 44;
localparam state_check_rule_index = 45;
localparam state_write_rule_index = 46;
localparam state_early_release_active_lock = 47;
localparam state_try_next = 48;
localparam state_rule_index_lock_again = 49;
localparam state_fix_hash_pos = 50;
localparam state_fix_new_hash_pos = 51;
localparam state_read_prep = 52;
localparam state_read_check = 53;
localparam state_read_return = 54;
localparam state_write_prep = 55;
localparam state_write_check = 56;
localparam state_write_return = 57;
localparam state_done = 58;

reg [5:0] curr_state, next_state, return_state;

reg [17:0] target_address;
reg [3:0] mmu_sel_buffer;
reg [63:0] target_data_write;
//used to store the current value of new fact count read from URAM 
//reg [31:0] new_fact_cnt; 

reg ai_clr, ai_inc;
reg[31:0] ai; //loop variable for the worker to iterate over its assigned active rules

reg pc_clr, pc_inc;
reg[47:0] pc; //permutation counter, 3-digit. Each digit is 16-bit. nc is the bound for each digit
reg[47:0] pc_ub; //permutation counter's upper bound: to be used as loop bound
wire [15:0] pc_buffer [2:0]; //for convenient access to each field of the pc register
assign pc_buffer[0] = pc[15:0];
assign pc_buffer[1] = pc[31:16];
assign pc_buffer[2] = pc[47:32];

reg [15:0] r; //rule index
reg [63:0] full_r;

//a (current) rule consists of 10 64-bit words
//First 5 are premises:
// rule[0]~rule[3] 4 spots for premise predicates
// rule[4]: information of the premise predicates: arities and # of predicates
//Next 5 are conclusions:
// rule[5]~rule[8] 4 spots for conclusion predicates
// rule[5]: information of the conclusion predicates: arities and # of predicates
reg [63:0] rule [9:0];
reg [63:0] rule_inst; //instantiated rule (with all variables assigned with constants from a permutation
reg new_pred_bit;
reg [7:0] hash_sel;
//wire [31:0] hashed_premise;
//wire [31:0] hashed_conclusion;
wire [31:0] hashed_value;
reg [15:0] hash_pos; //pointers to fact/used hash tables
wire [15:0] hash_check;
assign hash_check = (new_pred_bit)?hashed_value[15:0]:hash_pos;
reg [15:0] new_hash_pos; //pointers to new fact/new used hash tables
wire [7:0] np3, nc3;
assign np3 = rule[4][7:0]; //number of predicates in the premise
assign nc3 = rule[9][7:0]; //number of predicates in the conclusion
reg [7:0] cnt_p [3:0]; //arity of premise predicates
reg [7:0] cnt_c [3:0]; //arity of conclusion predicates
reg [7:0] curr_prem, curr_conc; //pointers to premise and conclusion predicates during inference
reg [7:0] curr_used; //buffer for read used
reg [63:0] curr_fact; //buffer for read fact
reg [7:0] curr_new_used; //buffer for read new used
//buffer for read full used: as each new used element is 8-bit, they are packed as group of 8 to be stored.
//when we write one element, we have to write the other 7 unchanged elments together
//so buffer the entire 64-bit into this full_new_used first
reg [63:0] full_new_used;
reg [63:0] curr_new_fact; //buffer for read new fact
reg matched, matched_again, new_matched; //to indicate if fact/used and newfact/newused hash table search is a match

//used by the reading process
reg [3:0] rule_offset; //specify one of the 10 64-bit word
reg rule_offset_clr;
reg rule_offset_inc;

reg [7:0] nargs; //the current rule has how many variables?


//acquire the lock to access new used/fact tables and new_count variable exclusively
//release the lock
always @(negedge rst, posedge clk)
begin
    if(!rst) req <= 0;
    else
    begin
        if(curr_state==state_insert_prep) req <= 1; //to request the lock to access the new fact/used tables
        else req <= 0;
    end
    
    if(!rst) rel <= 0;
    else
    begin
        if(curr_state==state_release_lock) rel <= 1; //release the lock on the new fact/used tables
        //else if((curr_state==state_check_new_fact)&&(new_matched==1)) rel <= 1; //release the lock also
        else rel <= 0;
    end
end

always @(negedge rst, posedge clk)
begin
    if(!rst) req_a <= 0;
    else
    begin
        if(curr_state==state_acquire_active_lock) req_a <= 1; //to request the lock to access the new fact/used tables      
        else req_a <= 0;
    end
    
    if(!rst) rel_a <= 0;
    else
    begin
        if(curr_state==state_release_active_lock) rel_a <= 1; //release the lock on the new fact/used tables
        else if(curr_state==state_early_release_active_lock) rel_a <= 1;         
        //else if((curr_state==state_check_new_fact)&&(new_matched==1)) rel <= 1; //release the lock also
        else rel_a <= 0;
    end
end

//set up URAM Read target address and target segment (mmu_sel_buffer)
//The target address is a relative address in the targeted segment
//The two buffers are written in before the FSM stages to perform actual URAM write begins
//They will be used to make the 130-bit read-request command word 
always @(posedge clk)
begin
    if(curr_state==state_read_rule_index)//not all rules are active, we read the next active rule's index
    begin 
        target_address <= ai[19:2]; //every four indices are packed as one 64-bit word in URAM's active seg
        mmu_sel_buffer <= sel_active;         
    end
    else if(curr_state==state_read_rule)
    begin
        //every rule needs 10 64-bit in the URAM's rules segment
        //we multiply rule index r with (8+2) first, then add the offset within the rule
        target_address <= {r[14:0], 3'b000}+{1'b0, r[15:0], 1'b0} + {14'b0, rule_offset};
        mmu_sel_buffer <= sel_rules;
    end
    else if(curr_state==state_read_nargs)
    begin
        target_address <= {5'b0, r[15:3]};//every 8 args grouped as a 64-bit word, so lower 3 bits of r are offset
        mmu_sel_buffer <= sel_rule_nargs;
    end
    else if((curr_state==state_read_used)||(curr_state==state_read_used_again))
    begin
        //every used is 8-bit, so 8 of them are packed as a 64-bit word in URAM used segment
        if(hash_check>=32768) 
        begin
            target_address <= {5'b0, hash_check[15:3]-13'd4096};
            mmu_sel_buffer <= sel_used_b;
        end
        else
        begin 
            target_address <= {5'b0, hash_check[15:3]};
            mmu_sel_buffer <= sel_used;
        end 
    end
    else if((curr_state==state_read_fact)||(curr_state==state_read_fact_again))
    begin
        //every fact is exactly one 64-bit word in URAM facts segment
        if(hash_pos[15:0]>=32768) 
        begin
            target_address <= {2'b0, hash_pos[15:0]-16'd32768};
            mmu_sel_buffer <= sel_facts_b;
        end
        else 
        begin
            target_address <= {2'b0, hash_pos[15:0]};
            mmu_sel_buffer <= sel_facts;
        end         
    end    
    else if(curr_state==state_read_new_used)
    begin
        target_address <= {5'b0, new_hash_pos[15:3]};
        mmu_sel_buffer <= sel_new_used;    
    end
    else if(curr_state==state_read_new_fact)
    begin
        target_address <= {2'b0, new_hash_pos[15:0]};
        mmu_sel_buffer <= sel_new_facts;    
    end
    else if(curr_state==state_write_rule_index)
    begin
        target_address <= ai[19:2]; //every four indices are packed as one 64-bit word in URAM's active seg
        mmu_sel_buffer <= sel_active;
        if(ai[1:0]==2'b00) target_data_write <= {full_r[63:16], 16'd65535};
        else if(ai[1:0]==2'b01) target_data_write <= {full_r[63:32], 16'd65535, full_r[15:0]};
        else if(ai[1:0]==2'b10) target_data_write <= {full_r[63:48], 16'd65535, full_r[31:0]};
        else target_data_write <= {16'd65535, full_r[47:0]};
    end
    else if(curr_state==state_write_new_fact)
    begin
        target_address <= {2'b0, new_hash_pos[15:0]};
        mmu_sel_buffer <= sel_new_facts;        
        target_data_write <= rule_inst[63:0];    
    end
    else if(curr_state==state_write_new_used)
    begin
        target_address <= {5'b0, new_hash_pos[15:3]};
        mmu_sel_buffer <= sel_new_used;        
        if(new_hash_pos[2:0]==0) target_data_write <= {full_new_used[63:8], cnt_c[curr_conc]};
        else if(new_hash_pos[2:0]==1) target_data_write <= {full_new_used[63:16], cnt_c[curr_conc], full_new_used[7:0]};
        else if(new_hash_pos[2:0]==2) target_data_write <= {full_new_used[63:24], cnt_c[curr_conc], full_new_used[15:0]};  
        else if(new_hash_pos[2:0]==3) target_data_write <= {full_new_used[63:32], cnt_c[curr_conc], full_new_used[23:0]};  
        else if(new_hash_pos[2:0]==4) target_data_write <= {full_new_used[63:40], cnt_c[curr_conc], full_new_used[31:0]};  
        else if(new_hash_pos[2:0]==5) target_data_write <= {full_new_used[63:48], cnt_c[curr_conc], full_new_used[39:0]};  
        else if(new_hash_pos[2:0]==6) target_data_write <= {full_new_used[63:56], cnt_c[curr_conc], full_new_used[47:0]};
        else target_data_write <= {cnt_c[curr_conc], full_new_used[55:0]};  
    end    
end

always @(posedge clk)
begin
    if(curr_state==state_read_rule_index) return_state <= state_rule_index_lock;
    else if(curr_state==state_read_rule) return_state <= state_rule_lock;
    else if(curr_state==state_read_nargs) return_state <= state_nargs_lock;
    else if(curr_state==state_read_used) return_state <= state_check_used;
    else if(curr_state==state_read_fact) return_state <= state_check_fact;
    else if(curr_state==state_read_used_again) return_state <= state_check_used_again;
    else if(curr_state==state_read_fact_again) return_state <= state_check_fact_again;    
    else if(curr_state==state_read_new_used) return_state <= state_new_used_lock;
    else if(curr_state==state_read_new_fact) return_state <= state_check_new_fact;
    else if(curr_state==state_write_rule_index) return_state <= state_release_active_lock;
    else if(curr_state==state_write_new_fact) return_state <= state_write_new_used;
    else if(curr_state==state_write_new_used) return_state <= state_release_lock;       
end

//set up the permutation of constants to plug into rule predicates containing variables
always @(negedge rst, posedge clk)
begin
    if(!rst) pc <= 0;
    else
    begin
        if(pc_clr) pc<=0;
        else if(pc_inc)
        begin
            pc[15:0] <= (pc[15:0]==nc[15:0]-1)?16'b0:(pc[15:0]+16'd1);
            pc[31:16] <= (pc[15:0]==nc[15:0]-1)?((pc[31:16]==nc[15:0]-1)?16'b0:(pc[31:16]+16'd1)):pc[31:16];
            //pc[47:32] <= ((pc[15:0]==nc[15:0]-1)&&(pc[31:16]==nc[15:0]-1))?((pc[47:32]==nc[15:0]-1)?16'b0:(pc[47:32]+16'd1)):pc[47:32];
            pc[47:32] <= ((pc[15:0]==nc[15:0]-1)&&(pc[31:16]==nc[15:0]-1))?(pc[47:32]+16'd1):pc[47:32]; //might be problematic here!
        end
    end
end

always @(nargs, nc)
begin
    if(nargs==0) pc_ub <= 1; // rules with zero arguments just need 1 nominal permutation!
    else if(nargs==1) pc_ub <= {32'b0, nc[15:0]};
    else if(nargs==2) pc_ub <= {16'b0, nc[15:0], 16'b0};
    else if(nargs==3) pc_ub <= {nc[15:0], 32'b0};
    else pc_ub <= 0; 
end 


//set up the active (rule) loop index
always @(negedge rst, posedge clk)
begin
    if(!rst) ai <= (worker_id>=debug)?20000:worker_id;
    else
    begin
        if(ai_clr) ai <= (worker_id>=debug)?20000:worker_id;
        else if(ai_inc) ai <= ai + 1; //total_workers[31:0];
        else if(curr_state==state_try_next)
        begin
            if((ai[1:0]!=2'b11)&&(ai<na-1)) ai <= ai + 1;
        end
    end
end

//lock the rule index read from URAM
//convenient for subsequent use!
//watch out for Endian scheme!
//every 4 indices make a 64-bit word
always @(posedge clk)
begin
    if(curr_state==state_rule_index_lock) 
    begin
        full_r <= mmu_q[63:0];
        if(ai[1:0]==2'b00) r <= mmu_q[15:0];
        else if(ai[1:0]==2'b01) r <= mmu_q[31:16];
        else if(ai[1:0]==2'b10) r <= mmu_q[47:32];
        else r <= mmu_q[63:48];
    end
    else if(curr_state==state_rule_index_lock_again)
    begin
        if(ai[1:0]==2'b00) r <= full_r[15:0];
        else if(ai[1:0]==2'b01) r <= full_r[31:16];
        else if(ai[1:0]==2'b10) r <= full_r[47:32];
        else r <= full_r[63:48];        
    end
end

//update the offset (index) in a rule
always @(negedge rst, posedge clk)
begin
    if(!rst) rule_offset <= 0;
    else
    begin
        if(rule_offset_clr) rule_offset <= 0;
        else if(rule_offset_inc) rule_offset <= rule_offset + 1;
    end
end

//lock a 64-bit into the current rule's 64-bit array
always @(posedge clk)
begin
    if(curr_state==state_rule_lock)
    begin
        if(rule_offset<10) rule[rule_offset] <= mmu_q[63:0];
    end
end

//instantiate a rule if the rule has variables (arguments)
always @(posedge clk)
begin
    if(curr_state==state_check_premises)
    begin
        //at least one predicate in the rule premise is guaranteed
        rule_inst[15:0] <= rule[curr_prem][15:0]; //predicate name copied
        rule_inst[31:16] <= (cnt_p[curr_prem]>1)?((rule[curr_prem][31:16]<vb)?(rule[curr_prem][31:16]):pc_buffer[rule[curr_prem][31:16]-vb[15:0]]):0;
        rule_inst[47:32] <= (cnt_p[curr_prem]>2)?((rule[curr_prem][47:32]<vb)?(rule[curr_prem][47:32]):pc_buffer[rule[curr_prem][47:32]-vb[15:0]]):0;
        rule_inst[63:48] <= (cnt_p[curr_prem]>3)?((rule[curr_prem][63:48]<vb)?(rule[curr_prem][63:48]):pc_buffer[rule[curr_prem][63:48]-vb[15:0]]):0;
        hash_sel <= cnt_p[curr_prem];
    end
    else if(curr_state==state_check_conclusions)    
    begin
        //at least one predicate in the rule conclusion is guaranteed
        rule_inst[15:0] <= rule[5+curr_conc][15:0]; //predicate name copied
        rule_inst[31:16] <= (cnt_c[curr_conc]>1)?((rule[5+curr_conc][31:16]<vb)?(rule[5+curr_conc][31:16]):pc_buffer[rule[5+curr_conc][31:16]-vb[15:0]]):0;
        rule_inst[47:32] <= (cnt_c[curr_conc]>2)?((rule[5+curr_conc][47:32]<vb)?(rule[5+curr_conc][47:32]):pc_buffer[rule[5+curr_conc][47:32]-vb[15:0]]):0;
        rule_inst[63:48] <= (cnt_c[curr_conc]>3)?((rule[5+curr_conc][63:48]<vb)?(rule[5+curr_conc][63:48]):pc_buffer[rule[5+curr_conc][63:48]-vb[15:0]]):0;
        hash_sel <= cnt_c[curr_conc];
    end
end

hash_calculator premise_pred(.tuple(rule_inst), .sel(hash_sel), .res(hashed_value));
//hash_calculator conclusion_pred(.tuple(rule_inst), .sel(cnt_c[curr_conc]), .res(hashed_conclusion));

always @(posedge clk)
begin
    if((curr_state==state_check_premises)||(curr_state==state_check_conclusions)) new_pred_bit <= 1;
    else if((curr_state==state_read_used)||(curr_state==state_read_used_again)) new_pred_bit<=0;
end

always @(posedge clk)
begin
    if(curr_state==state_read_used) hash_pos <= (new_pred_bit)?hashed_value[15:0]:hash_pos;
    else if(curr_state==state_check_used) hash_pos <= ((curr_used!=0)&&(curr_used!=cnt_p[curr_prem]))?(hash_pos + 1):hash_pos; //problematic here
    else if(curr_state==state_check_fact) hash_pos <= (matched)?hash_pos:(hash_pos+1);//increment hash index to be consistent with linear probing
    else if(curr_state==state_read_used_again) hash_pos <= (new_pred_bit)?hashed_value[15:0]:hash_pos;
    else if(curr_state==state_check_used_again) hash_pos <= ((curr_used!=0)&&(curr_used!=cnt_c[curr_conc]))?(hash_pos + 1):hash_pos; //problematic here
    else if(curr_state==state_check_fact_again) hash_pos <= (matched_again)?hash_pos:(hash_pos+1);//increment hash index to be consistent with linear probing    
end

always @(posedge clk)
begin
    if(curr_state==state_read_used_again) new_hash_pos <= (new_pred_bit)?hashed_value[15:0]:new_hash_pos;
    else if(curr_state==state_check_new_used) new_hash_pos <= ((curr_new_used!=0)&&(curr_new_used!=cnt_c[curr_conc]))?(new_hash_pos + 1):new_hash_pos; //problematic here
    else if(curr_state==state_check_new_fact) new_hash_pos <= (new_matched)?new_hash_pos:(new_hash_pos+1);//increment hash index to be consistent with linear probing
end


always @(posedge clk)
begin
    if(curr_state==state_counter_reset) curr_prem <= 0;
    else if(curr_state==state_check_fact) curr_prem <= (matched)?(curr_prem + 1):curr_prem;//if not matched, keep checking following hash units for the current pred
end

always @(posedge clk)
begin
    if(curr_state==state_counter_reset) curr_conc <= 0;
    else if(curr_state==state_check_fact_again) curr_conc <= (matched_again)?(curr_conc + 1):curr_conc;
    else if(curr_state==state_check_new_fact) curr_conc <= (new_matched)?(curr_conc + 1):curr_conc;
    else if(curr_state==state_write_new_used) curr_conc <= curr_conc + 1; //double check, just in case
    //else if(curr_state==state_write_new_count) curr_conc <= curr_conc + 1; //double check, probably issue here
end

always @(*)
begin
    //if((curr_state==state_used_lock)||(curr_state==state_used_lock_again))
    //begin  
        case(hash_pos[2:0])
        0:
        begin
            curr_used <= mmu_q[7:0];
        end
        1:
        begin
            curr_used <= mmu_q[15:8];
        end
        2:
        begin
            curr_used <= mmu_q[23:16];
        end
        3:
        begin
            curr_used <= mmu_q[31:24];
        end
        4:
        begin
            curr_used <= mmu_q[39:32];
        end
        5:
        begin
            curr_used <= mmu_q[47:40];
        end
        6:
        begin
            curr_used <= mmu_q[55:48];
        end
        7:
        begin
            curr_used <= mmu_q[63:56];
        end                                                        
        endcase
    //end   
end

always @(*)
begin
    //if((curr_state==state_fact_lock)||(curr_state==state_fact_lock_again))
    //begin
        curr_fact <= mmu_q[63:0];
    //end
end

always @(posedge clk)
begin
    if(curr_state==state_new_used_lock)
    begin
        full_new_used <= mmu_q[63:0]; //used to later write the full used (8 elements) back 
    
        case(new_hash_pos[2:0])
        0:
        begin
            curr_new_used <= mmu_q[7:0];
        end
        1:
        begin
            curr_new_used <= mmu_q[15:8];
        end
        2:
        begin
            curr_new_used <= mmu_q[23:16];
        end
        3:
        begin
            curr_new_used <= mmu_q[31:24];
        end
        4:
        begin
            curr_new_used <= mmu_q[39:32];
        end
        5:
        begin
            curr_new_used <= mmu_q[47:40];
        end
        6:
        begin
            curr_new_used <= mmu_q[55:48];
        end
        7:
        begin
            curr_new_used <= mmu_q[63:56];
        end                                                        
        endcase
    end
end

always @(*)
begin
    //if(curr_state==state_new_fact_lock)
    //begin
        curr_new_fact <= mmu_q[63:0];
    //end
end

//always @(posedge clk)
//begin
//    if(curr_state==state_new_count_lock)
//    begin
//        new_fact_cnt <= mmu_q[31:0];
//    end
//end


always @(*)
begin
    if(cnt_c[curr_conc]==1) matched_again <= (curr_fact[15:0]==rule_inst[15:0])?1:0;
    else if(cnt_c[curr_conc]==2) matched_again <= (curr_fact[31:0]==rule_inst[31:0])?1:0;
    else if(cnt_c[curr_conc]==3) matched_again <= (curr_fact[47:0]==rule_inst[47:0])?1:0;
    else if(cnt_c[curr_conc]==4) matched_again <= (curr_fact[63:0]==rule_inst[63:0])?1:0;
    else matched_again <= 0;
end

always @(*)
begin
    if(cnt_p[curr_prem]==1) matched <= (curr_fact[15:0]==rule_inst[15:0])?1:0;
    else if(cnt_p[curr_prem]==2) matched <= (curr_fact[31:0]==rule_inst[31:0])?1:0;
    else if(cnt_p[curr_prem]==3) matched <= (curr_fact[47:0]==rule_inst[47:0])?1:0;
    else if(cnt_p[curr_prem]==4) matched <= (curr_fact[63:0]==rule_inst[63:0])?1:0;
    else matched <= 0;
end

always @(*)
begin
    if(cnt_c[curr_conc]==1) new_matched <= (curr_new_fact[15:0]==rule_inst[15:0])?1:0;
    else if(cnt_c[curr_conc]==2) new_matched <= (curr_new_fact[31:0]==rule_inst[31:0])?1:0;
    else if(cnt_c[curr_conc]==3) new_matched <= (curr_new_fact[47:0]==rule_inst[47:0])?1:0;
    else if(cnt_c[curr_conc]==4) new_matched <= (curr_new_fact[63:0]==rule_inst[63:0])?1:0;
    else new_matched <= 0;
end


/*
always @(*)
begin
    matched <= (curr_fact==rule_inst[curr_prem])?1:0;
end

always @(*)
begin
    new_matched <= (curr_new_fact==rule_inst[curr_conc+5])?1:0;
end
*/

//lock the rule nargs read from URAM
//rule nargs is an 8-bit variable, so just extract one byte from the lower 64-bit mmu_q
//convenient for subsequent use!
//watch out for Endian scheme!
always @(posedge clk)
begin
    if(curr_state==state_nargs_lock) 
    begin
        case(r[2:0])
        0:
        begin
            nargs <= mmu_q[7:0];
        end
        1:
        begin
            nargs <= mmu_q[15:8];
        end
        2:
        begin
            nargs <= mmu_q[23:16];
        end
        3:
        begin
            nargs <= mmu_q[31:24];
        end
        4:
        begin
            nargs <= mmu_q[39:32];
        end
        5:
        begin
            nargs <= mmu_q[47:40];
        end
        6:
        begin
            nargs <= mmu_q[55:48];
        end
        7:
        begin
            nargs <= mmu_q[63:56];
        end                                                        
        endcase
    end
end

//extract arity of each premise predicate using rule[4]
//np3 is actually rule[4][7:0], indicating the number of predicates in the premise
always @(np3, rule[4])
begin
    if(np3==1)
    begin
        cnt_p[0] <= rule[4][15:8];
        cnt_p[1] <= 0;
        cnt_p[2] <= 0;
        cnt_p[3] <= 0;
    end
    else if(np3==2)
    begin
        cnt_p[0] <= rule[4][23:16];
        cnt_p[1] <= rule[4][15:8];
        cnt_p[2] <= 0;
        cnt_p[3] <= 0;    
    end
    else if(np3==3)
    begin
        cnt_p[0] <= rule[4][31:24];
        cnt_p[1] <= rule[4][23:16];
        cnt_p[2] <= rule[4][15:8];
        cnt_p[3] <= 0;    
    end
    else if(np3==4)
    begin
        cnt_p[0] <= rule[4][39:32];
        cnt_p[1] <= rule[4][31:24];
        cnt_p[2] <= rule[4][23:16];
        cnt_p[3] <= rule[4][15:8];    
    end
    else
    begin
        cnt_p[0] <= 0;
        cnt_p[1] <= 0;
        cnt_p[2] <= 0;
        cnt_p[3] <= 0;      
    end
end

//extract arity of each conclusion predicate using rule[9]
//nc3 is actually rule[9][7:0], indicating the number of predicates in the conclusion
always @(nc3, rule[9])
begin
    if(nc3==1)
    begin
        cnt_c[0] <= rule[9][15:8];
        cnt_c[1] <= 0;
        cnt_c[2] <= 0;
        cnt_c[3] <= 0;
    end
    else if(nc3==2)
    begin
        cnt_c[0] <= rule[9][23:16];
        cnt_c[1] <= rule[9][15:8];
        cnt_c[2] <= 0;
        cnt_c[3] <= 0;    
    end
    else if(nc3==3)
    begin
        cnt_c[0] <= rule[9][31:24];
        cnt_c[1] <= rule[9][23:16];
        cnt_c[2] <= rule[9][15:8];
        cnt_c[3] <= 0;    
    end
    else if(nc3==4)
    begin
        cnt_c[0] <= rule[9][39:32];
        cnt_c[1] <= rule[9][31:24];
        cnt_c[2] <= rule[9][23:16];
        cnt_c[3] <= rule[9][15:8];    
    end
    else
    begin
        cnt_c[0] <= 0;
        cnt_c[1] <= 0;
        cnt_c[2] <= 0;
        cnt_c[3] <= 0;      
    end
end 

always @(negedge rst, posedge clk)
begin
    if(!rst) done <= 0;
    else
    begin
        if(curr_state==state_done) done <= 1; //assert output done for the master to read
        else done<=0;
    end
end

always @(negedge rst, posedge clk)
begin
    if(!rst) curr_state <= state_idle;
    else curr_state <= next_state;
end

always @(*)
begin
    next_state <= state_idle;
    ai_clr <= 0;
    pc_clr <= 0;
    ai_inc <= 0;
    pc_inc <= 0;
    rule_offset_clr <= 0;
    rule_offset_inc <= 0;         
    mmu_en <= 0;
    mmu_we <= 0;
    mmu_data <= 0;
    mmu_sel <= 4'b0000;
    case(curr_state)
    state_idle:
    begin
        next_state <= state_prep;         
    end
    state_prep:
    begin
        next_state <= (data_ready)?state_init:state_prep; //wait until the master asserts data_ready
        ai_clr <= 1;
        pc_clr <= 1;
        rule_offset_clr <= 1;               
    end
    state_init:
    begin
        next_state <= state_main;                
    end
    state_main:
    begin
        next_state <= (ai<na)?state_acquire_active_lock:state_done; //check if all active rules assigned to this worker have been checked
        pc_clr <= 1; //reset the permutation counter            
    end
    state_acquire_active_lock:
    begin
        next_state <= (grant_a)?state_read_rule_index:state_acquire_active_lock;
    end      
    state_read_rule_index:
    begin
        next_state <= state_read_prep;               
    end
    state_rule_index_lock:
    begin
        next_state <= state_check_rule_index;     
    end
    state_check_rule_index:
    begin
        next_state <= (r==16'd65535)?state_try_next:state_write_rule_index;         
    end
    state_try_next:
    begin
        next_state <= ((ai[1:0]!=2'b11)&&(ai<na-1))?state_rule_index_lock_again:state_early_release_active_lock;    
    end
    state_rule_index_lock_again:
    begin
        next_state <= state_check_rule_index;    
    end    
    state_early_release_active_lock:
    begin
        next_state <= (grant_a)?state_early_release_active_lock:state_ai_inc;
    end    
    state_write_rule_index:
    begin
        next_state <= state_write_prep;         
    end
    state_release_active_lock:
    begin
        next_state <= (grant_a)?state_release_active_lock:state_read_rule;
        rule_offset_clr <= 1; //prepare for next step         
    end
    state_read_rule: //read 10 64-bit words to make the current rule. Can be potentially a long process, which can be improved in future.
    begin
        next_state <= state_read_prep;     
    end
    state_rule_lock:
    begin
        next_state <= (rule_offset<9)?state_read_rule:state_read_nargs;
        rule_offset_inc <= 1;   
    end
    state_read_nargs:
    begin
        next_state <= state_read_prep;    
    end
    state_nargs_lock:
    begin
        next_state <= state_check_pc; //state_nargs_test;   
    end
    state_check_pc: //after having rule locked, assign each permutation to the rule's arguments. Rule instantiation also happens during this tate
    begin
        next_state <= (pc<pc_ub)?state_counter_reset:state_ai_inc; //no-arg rule has pc_ub=1 and will be checked just once         
    end    
    state_counter_reset: //to get a stable hashing result, may need to be extended to more cycles
    begin
        next_state <= state_check_premises;    
    end
    
    state_check_premises: //check each predicate in the premise
    begin
        next_state <= (curr_prem<np3)?state_read_used:state_check_conclusions;    
    end 
    state_read_used:
    begin
        next_state <= state_read_prep;       
    end
    state_used_lock:
    begin
        next_state <= state_check_used;        
    end
    state_check_used:
    begin
        next_state <= (curr_used==0)?state_pc_update:((curr_used!=cnt_p[curr_prem])?state_read_used:state_read_fact);        
    end
    state_read_fact:
    begin
        next_state <= state_read_prep;         
    end
    state_fact_lock:
    begin
        next_state <= state_check_fact;        
    end
    state_check_fact:
    begin
        next_state <= matched?state_check_premises:state_read_used;//unmatched read fact requires checking the next position according to linear probing    
    end

    state_check_conclusions: //check each predicate in the conclusion
    begin
        next_state <= (curr_conc<nc3)?state_read_used_again:state_insert_done;         
    end
    state_read_used_again:
    begin
        next_state <= state_read_prep;        
    end
    state_used_lock_again:
    begin
        next_state <= state_check_used_again;      
    end
    state_check_used_again:
    begin
        next_state <= (curr_used==0)?state_insert_prep:((curr_used!=cnt_c[curr_conc])?state_read_used_again:state_read_fact_again);         
    end
    state_read_fact_again:
    begin
        next_state <= state_read_prep;        
    end
    state_fact_lock_again:
    begin
        next_state <= state_check_fact_again;        
    end
    state_check_fact_again:
    begin
        next_state <= matched_again?state_check_conclusions:state_read_used_again;//unmatched read fact requires checking the next position according to linear probing     
    end
    state_insert_prep: //First, this worker needs to acquire the lock for exclusive access of new fact/new used tables and new count variable
    begin
        next_state <= grant?state_read_new_used:state_insert_prep;        
    end    
    state_read_new_used:
    begin
        next_state <= state_read_prep;        
    end
    state_new_used_lock:
    begin
        next_state <= state_check_new_used;   
    end
    state_check_new_used:
    begin
        next_state <= (curr_new_used==0)?state_write_new_fact:((curr_new_used!=cnt_c[curr_conc])?state_read_new_used:state_read_new_fact);     
    end
    state_read_new_fact:
    begin
        next_state <= state_read_prep;   
    end
    //state_new_fact_lock:
    //begin
    //    next_state <= state_check_new_fact;     
    //end
    state_check_new_fact:
    begin
        next_state <= new_matched?state_release_lock:state_read_new_used;//unmatched read fact requires checking the next position according to linear probing    
    end
    state_write_new_fact:
    begin
        next_state <= state_write_prep;       
    end
    state_write_new_used:       
    begin
        next_state <= state_write_prep;       
    end
    //state_read_new_count:
    //begin
    //    next_state <= state_read_prep;  
    //end
    //state_new_count_lock:
    //begin
    //    next_state <= state_write_new_count;    
    //end
    //state_write_new_count:
    //begin
    //    next_state <= state_write_prep;       
    //end
    state_release_lock:
    begin
        next_state <= (grant)?state_release_lock:state_check_conclusions;    
    end
    
    state_insert_done: //to release the lock on access to new fact/used tables
    begin
        next_state <= state_pc_update;        
    end
    state_pc_update:
    begin
        next_state <=state_check_pc;
        pc_inc <= 1; //prepare to check the next permutation       
    end
    state_ai_inc:
    begin
        next_state <= state_main;
        ai_inc <= 1; //increment ai to work on the next rule  
    end
    state_done:
    begin
        next_state <= (zero)?state_idle:state_done; //keep asserting done until the master sends a zero signal  
    end
    
    
    //The following three states is equivalent to a C function that reads URAM at a specified address
    state_read_prep:
    begin
        next_state <= state_read_check;        
        mmu_en <= 1;
        mmu_we <= 1; //this is to write a command (read request) to mmu
        mmu_data <= {2'b10, target_address, 64'b0}; //make a command word for read request
        mmu_sel <= mmu_sel_buffer;
    end
    state_read_check:
    begin
        next_state <= state_read_return;       
        mmu_en <= 1;
        mmu_we <= 0; //this is to read the status of mmu
        mmu_data <= 0;
        mmu_sel <= mmu_sel_buffer;            
    end
    state_read_return:
    begin
        next_state <= (mmu_q[64])?state_read_check:return_state;        
        mmu_en <= 0;
        mmu_we <= 0; //this is to read the status of mmu
        mmu_data <= 0;
        mmu_sel <= mmu_sel_buffer;                   
    end
    
    state_write_prep:
    begin
        next_state <= state_write_check;       
        mmu_en <= 1;
        mmu_we <= 1; //this is to write a command (write request) to mmu
        mmu_data <= {2'b11, target_address, target_data_write}; //make a command word for write request
        mmu_sel <= mmu_sel_buffer;
    end
    state_write_check:
    begin
        next_state <= state_write_return;        
        mmu_en <= 1;
        mmu_we <= 0; //this is to read the status of mmu
        mmu_data <= 0;
        mmu_sel <= mmu_sel_buffer;            
    end
    state_write_return:
    begin
        next_state <= (mmu_q[64])?state_write_check:return_state;         
        mmu_en <= 0;
        mmu_we <= 0; //this is to read the status of mmu
        mmu_data <= 0;
        mmu_sel <= mmu_sel_buffer;                   
    end
    
    default:
    begin
        next_state <= state_idle;         
    end
    endcase
end




endmodule
