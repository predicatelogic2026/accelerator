`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/25/2026 09:16:29 PM
// Design Name: 
// Module Name: xpm_ram
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module xpm_ram #(
    parameter ADDR_WIDTH = 19,
    parameter DATA_WIDTH = 32
)(
    input  wire                     clk,

    input  wire                     en,
    input  wire                     we,
    input  wire [ADDR_WIDTH-1:0]    addr,
    input  wire [DATA_WIDTH-1:0]    din,
    output wire [DATA_WIDTH-1:0]    dout
);

    xpm_memory_spram #(
        .ADDR_WIDTH_A(ADDR_WIDTH),
        .AUTO_SLEEP_TIME(0),
        .BYTE_WRITE_WIDTH_A(DATA_WIDTH),
        .ECC_MODE("no_ecc"),
        .MEMORY_INIT_FILE("none"),
        .MEMORY_INIT_PARAM("0"),
        .MEMORY_OPTIMIZATION("true"),
        .MEMORY_PRIMITIVE("URAM"),   // BRAM or URAM depending on size
        .MEMORY_SIZE( (1 << ADDR_WIDTH) * DATA_WIDTH ),
        .MESSAGE_CONTROL(0),
        .READ_DATA_WIDTH_A(DATA_WIDTH),
        .READ_LATENCY_A(1),
        .WRITE_DATA_WIDTH_A(DATA_WIDTH),
        .USE_MEM_INIT(0),
        .WAKEUP_TIME("disable_sleep")
    ) xpm_ram_inst (

        .clka   (clk),

        .ena    (en),
        .wea    (we),
        .addra  (addr),
        .dina   (din),
        .douta  (dout),

        .rsta   (1'b0),
        .regcea (1'b1),

        .sleep   (1'b0)
    );

endmodule
