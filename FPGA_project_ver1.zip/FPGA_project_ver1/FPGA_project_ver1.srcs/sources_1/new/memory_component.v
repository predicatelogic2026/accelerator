`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06/12/2026 08:00:46 PM
// Design Name: 
// Module Name: memory_componen
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
////////////////////////////////////////////////////////////////////////////////


module memory_component #(
    parameter mem_data_width = 64,
    parameter acc_in_width = 84,
    parameter acc_out_width = 65
)
(
//all input and output signals in this higher level memory component are wires!
rst, clk,
en0, we0, data0, q0, addr0, 
en1, we1, data1, q1, addr1, 
en2, we2, data2, q2, addr2,
en3, we3, data3, q3, addr3,
en4, we4, data4, q4, addr4,
en5, we5, data5, q5, addr5,
en6, we6, data6, q6, addr6, 
en7, we7, data7, q7, addr7, 
en8, we8, data8, q8, addr8,
en9, we9, data9, q9, addr9,
en10, we10, data10, q10, addr10,
en11, we11, data11, q11, addr11,
en12, we12, data12, q12, addr12, 
en13, we13, data13, q13, addr13, 
en14, we14, data14, q14, addr14,
en15, we15, data15, q15, addr15,
en16, we16, data16, q16, addr16,
en17, we17, data17, q17, addr17, 
en18, we18, data18, q18, addr18,
en19, we19, data19, q19, addr19,
en20, we20, data20, q20, addr20,
en21, we21, data21, q21, addr21,
en22, we22, data22, q22, addr22, 
en23, we23, data23, q23, addr23, 
en24, we24, data24, q24, addr24,
en25, we25, data25, q25, addr25,
en26, we26, data26, q26, addr26,
en27, we27, data27, q27, addr27,
en28, we28, data28, q28, addr28,
en29, we29, data29, q29, addr29,
en30, we30, data30, q30, addr30,
en31, we31, data31, q31, addr31,
en32, we32, data32, q32, addr32
);

input rst, clk; //used as input to any inner component needing them
input en0, we0, en1, we1, en2, we2, en3, we3, en4, we4, en5, we5,
en6, we6, en7, we7, en8, we8, en9, we9, en10, we10, en11, we11, en12, we12, en13, we13, en14, we14, en15, we15, en16, we16,
en17, we17, en18, we18, en19, we19, en20, we20, en21, we21, en22, we22, en23, we23, en24, we24,
en25, we25, en26, we26, en27, we27, en28, we28, en29, we29, en30, we30, en31, we31, en32, we32;

input [acc_in_width-1:0] data0, data1, data2, data3, data4, data5, data6, data7, data8, data9, data10, data11, data12, data13, data14, data15, data16,
data17, data18, data19, data20, data21, data22, data23, data24,
data25, data26, data27, data28, data29, data30, data31, data32;

//select one of the 8 mmu/uram
input [3:0] addr0, addr1, addr2, addr3, addr4, addr5, addr6, addr7, addr8, addr9, addr10, addr11, addr12, addr13, addr14, addr15, addr16,
addr17, addr18, addr19, addr20, addr21, addr22, addr23, addr24,
addr25, addr26, addr27, addr28, addr29, addr30, addr31, addr32;

//these are output from the 16 q_multiplexors, directly connecting each worker's mmu_q bus
output [acc_out_width-1:0] q0, q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18, q19, q20, q21, q22, q23, q24,
q25, q26, q27, q28, q29, q30, q31, q32;

/*signals that connect to the q_mplex*/
wire[acc_out_width-1:0] mmu0_q0, mmu0_q1, mmu0_q2, mmu0_q3, mmu0_q4, mmu0_q5, mmu0_q6, mmu0_q7, mmu0_q8, mmu0_q9, mmu0_q10, mmu0_q11, mmu0_q12, mmu0_q13, mmu0_q14, mmu0_q15, mmu0_q16, mmu0_q17, mmu0_q18, mmu0_q19, mmu0_q20, mmu0_q21, mmu0_q22, mmu0_q23, mmu0_q24, mmu0_q25, mmu0_q26, mmu0_q27, mmu0_q28, mmu0_q29, mmu0_q30, mmu0_q31, mmu0_q32;
wire[acc_out_width-1:0] mmu1_q0, mmu1_q1, mmu1_q2, mmu1_q3, mmu1_q4, mmu1_q5, mmu1_q6, mmu1_q7, mmu1_q8, mmu1_q9, mmu1_q10, mmu1_q11, mmu1_q12, mmu1_q13, mmu1_q14, mmu1_q15, mmu1_q16, mmu1_q17, mmu1_q18, mmu1_q19, mmu1_q20, mmu1_q21, mmu1_q22, mmu1_q23, mmu1_q24, mmu1_q25, mmu1_q26, mmu1_q27, mmu1_q28, mmu1_q29, mmu1_q30, mmu1_q31, mmu1_q32;
wire[acc_out_width-1:0] mmu2_q0, mmu2_q1, mmu2_q2, mmu2_q3, mmu2_q4, mmu2_q5, mmu2_q6, mmu2_q7, mmu2_q8, mmu2_q9, mmu2_q10, mmu2_q11, mmu2_q12, mmu2_q13, mmu2_q14, mmu2_q15, mmu2_q16, mmu2_q17, mmu2_q18, mmu2_q19, mmu2_q20, mmu2_q21, mmu2_q22, mmu2_q23, mmu2_q24, mmu2_q25, mmu2_q26, mmu2_q27, mmu2_q28, mmu2_q29, mmu2_q30, mmu2_q31, mmu2_q32;
wire[acc_out_width-1:0] mmu3_q0, mmu3_q1, mmu3_q2, mmu3_q3, mmu3_q4, mmu3_q5, mmu3_q6, mmu3_q7, mmu3_q8, mmu3_q9, mmu3_q10, mmu3_q11, mmu3_q12, mmu3_q13, mmu3_q14, mmu3_q15, mmu3_q16, mmu3_q17, mmu3_q18, mmu3_q19, mmu3_q20, mmu3_q21, mmu3_q22, mmu3_q23, mmu3_q24, mmu3_q25, mmu3_q26, mmu3_q27, mmu3_q28, mmu3_q29, mmu3_q30, mmu3_q31, mmu3_q32;
wire[acc_out_width-1:0] mmu4_q0, mmu4_q1, mmu4_q2, mmu4_q3, mmu4_q4, mmu4_q5, mmu4_q6, mmu4_q7, mmu4_q8, mmu4_q9, mmu4_q10, mmu4_q11, mmu4_q12, mmu4_q13, mmu4_q14, mmu4_q15, mmu4_q16, mmu4_q17, mmu4_q18, mmu4_q19, mmu4_q20, mmu4_q21, mmu4_q22, mmu4_q23, mmu4_q24, mmu4_q25, mmu4_q26, mmu4_q27, mmu4_q28, mmu4_q29, mmu4_q30, mmu4_q31, mmu4_q32;
wire[acc_out_width-1:0] mmu5_q0, mmu5_q1, mmu5_q2, mmu5_q3, mmu5_q4, mmu5_q5, mmu5_q6, mmu5_q7, mmu5_q8, mmu5_q9, mmu5_q10, mmu5_q11, mmu5_q12, mmu5_q13, mmu5_q14, mmu5_q15, mmu5_q16, mmu5_q17, mmu5_q18, mmu5_q19, mmu5_q20, mmu5_q21, mmu5_q22, mmu5_q23, mmu5_q24, mmu5_q25, mmu5_q26, mmu5_q27, mmu5_q28, mmu5_q29, mmu5_q30, mmu5_q31, mmu5_q32;
wire[acc_out_width-1:0] mmu6_q0, mmu6_q1, mmu6_q2, mmu6_q3, mmu6_q4, mmu6_q5, mmu6_q6, mmu6_q7, mmu6_q8, mmu6_q9, mmu6_q10, mmu6_q11, mmu6_q12, mmu6_q13, mmu6_q14, mmu6_q15, mmu6_q16, mmu6_q17, mmu6_q18, mmu6_q19, mmu6_q20, mmu6_q21, mmu6_q22, mmu6_q23, mmu6_q24, mmu6_q25, mmu6_q26, mmu6_q27, mmu6_q28, mmu6_q29, mmu6_q30, mmu6_q31, mmu6_q32;
wire[acc_out_width-1:0] mmu7_q0, mmu7_q1, mmu7_q2, mmu7_q3, mmu7_q4, mmu7_q5, mmu7_q6, mmu7_q7, mmu7_q8, mmu7_q9, mmu7_q10, mmu7_q11, mmu7_q12, mmu7_q13, mmu7_q14, mmu7_q15, mmu7_q16, mmu7_q17, mmu7_q18, mmu7_q19, mmu7_q20, mmu7_q21, mmu7_q22, mmu7_q23, mmu7_q24, mmu7_q25, mmu7_q26, mmu7_q27, mmu7_q28, mmu7_q29, mmu7_q30, mmu7_q31, mmu7_q32;
wire[acc_out_width-1:0] mmu8_q0, mmu8_q1, mmu8_q2, mmu8_q3, mmu8_q4, mmu8_q5, mmu8_q6, mmu8_q7, mmu8_q8, mmu8_q9, mmu8_q10, mmu8_q11, mmu8_q12, mmu8_q13, mmu8_q14, mmu8_q15, mmu8_q16, mmu8_q17, mmu8_q18, mmu8_q19, mmu8_q20, mmu8_q21, mmu8_q22, mmu8_q23, mmu8_q24, mmu8_q25, mmu8_q26, mmu8_q27, mmu8_q28, mmu8_q29, mmu8_q30, mmu8_q31, mmu8_q32;

/*signals that connect to the URAMs*/
wire[mem_data_width-1:0] mem0_dout, mem1_dout, mem2_dout, mem3_dout, mem4_dout, mem5_dout, mem6_dout, mem7_dout, mem8_dout;
wire[mem_data_width-1:0] mem2_dout2, mem3_dout2;
wire[mem_data_width-1:0] mem0_din, mem1_din, mem2_din, mem3_din, mem4_din, mem5_din, mem6_din, mem7_din, mem8_din;
wire[mem_data_width-1:0] mem2_din2, mem3_din2;
wire mem0_we, mem0_en, mem1_we, mem1_en, mem2_we, mem2_en, mem3_we, mem3_en, mem4_we, mem4_en, mem5_we, mem5_en, mem6_we, mem6_en, mem7_we, mem7_en;
wire mem8_we, mem8_en;// mem11_we, mem11_en;
wire mem2_we2, mem2_en2, mem3_we2, mem3_en2;
wire[14:0] mem0_addr; //1st half of facts table
wire[14:0] mem1_addr; //2nd half of facts table
wire[11:0] mem2_addr; //1st half of used table
wire[11:0] mem3_addr; //2nd half of used table
wire[15:0] mem4_addr; //new facts table
wire[12:0] mem5_addr; //new used table
wire[14:0] mem6_addr; //rule table
wire[11:0] mem7_addr; //nargs table
wire[11:0] mem8_addr; //active table

wire[11:0] mem2_addr2; //1st half of used table
wire[11:0] mem3_addr2; //2nd half of used table


/*9 MMUs, each manages one memory segment*/
MMU_CH17_new #(.mem_data_width(mem_data_width), .mem_addr_width(15), .acc_in_width(acc_in_width), .acc_out_width(acc_out_width), .mmu_id(0)) mmu0
(
.rst(rst), .clk(clk),
.en0(en0), .we0(we0), .data0(data0), .q0(mmu0_q0), .addr0(addr0), 
.en1(en1), .we1(we1), .data1(data1), .q1(mmu0_q1), .addr1(addr1), 
.en2(en2), .we2(we2), .data2(data2), .q2(mmu0_q2), .addr2(addr2), 
.en3(en3), .we3(we3), .data3(data3), .q3(mmu0_q3), .addr3(addr3), 
.en4(en4), .we4(we4), .data4(data4), .q4(mmu0_q4), .addr4(addr4), 
.en5(en5), .we5(we5), .data5(data5), .q5(mmu0_q5), .addr5(addr5), 
.en6(en6), .we6(we6), .data6(data6), .q6(mmu0_q6), .addr6(addr6), 
.en7(en7), .we7(we7), .data7(data7), .q7(mmu0_q7), .addr7(addr7), 
.en8(en8), .we8(we8), .data8(data8), .q8(mmu0_q8), .addr8(addr8), 
.en9(en9), .we9(we9), .data9(data9), .q9(mmu0_q9), .addr9(addr9), 
.en10(en10), .we10(we10), .data10(data10), .q10(mmu0_q10), .addr10(addr10), 
.en11(en11), .we11(we11), .data11(data11), .q11(mmu0_q11), .addr11(addr11), 
.en12(en12), .we12(we12), .data12(data12), .q12(mmu0_q12), .addr12(addr12), 
.en13(en13), .we13(we13), .data13(data13), .q13(mmu0_q13), .addr13(addr13), 
.en14(en14), .we14(we14), .data14(data14), .q14(mmu0_q14), .addr14(addr14), 
.en15(en15), .we15(we15), .data15(data15), .q15(mmu0_q15), .addr15(addr15), 
.en16(en16), .we16(we16), .data16(data16), .q16(mmu0_q16), .addr16(addr16),
.en17(en17), .we17(we17), .data17(data17), .q17(mmu0_q17), .addr17(addr17), 
.en18(en18), .we18(we18), .data18(data18), .q18(mmu0_q18), .addr18(addr18), 
.en19(en19), .we19(we19), .data19(data19), .q19(mmu0_q19), .addr19(addr19), 
.en20(en20), .we20(we20), .data20(data20), .q20(mmu0_q20), .addr20(addr20), 
.en21(en21), .we21(we21), .data21(data21), .q21(mmu0_q21), .addr21(addr21), 
.en22(en22), .we22(we22), .data22(data22), .q22(mmu0_q22), .addr22(addr22), 
.en23(en23), .we23(we23), .data23(data23), .q23(mmu0_q23), .addr23(addr23), 
.en24(en24), .we24(we24), .data24(data24), .q24(mmu0_q24), .addr24(addr24),
.en25(en25), .we25(we25), .data25(data25), .q25(mmu0_q25), .addr25(addr25), 
.en26(en26), .we26(we26), .data26(data26), .q26(mmu0_q26), .addr26(addr26), 
.en27(en27), .we27(we27), .data27(data27), .q27(mmu0_q27), .addr27(addr27), 
.en28(en28), .we28(we28), .data28(data28), .q28(mmu0_q28), .addr28(addr28), 
.en29(en29), .we29(we29), .data29(data29), .q29(mmu0_q29), .addr29(addr29), 
.en30(en30), .we30(we30), .data30(data30), .q30(mmu0_q30), .addr30(addr30),
.en31(en31), .we31(we31), .data31(data31), .q31(mmu0_q31), .addr31(addr31), 
.en32(en32), .we32(we32), .data32(data32), .q32(mmu0_q32), .addr32(addr32), 
.mem_en(mem0_en), .mem_we(mem0_we), .mem_addr(mem0_addr), .mem_data(mem0_din), .mem_q(mem0_dout)
);

MMU_CH17_new #(.mem_data_width(mem_data_width), .mem_addr_width(15), .acc_in_width(acc_in_width), .acc_out_width(acc_out_width), .mmu_id(1)) mmu1
(
.rst(rst), .clk(clk),
.en0(en0), .we0(we0), .data0(data0), .q0(mmu1_q0), .addr0(addr0), 
.en1(en1), .we1(we1), .data1(data1), .q1(mmu1_q1), .addr1(addr1), 
.en2(en2), .we2(we2), .data2(data2), .q2(mmu1_q2), .addr2(addr2), 
.en3(en3), .we3(we3), .data3(data3), .q3(mmu1_q3), .addr3(addr3), 
.en4(en4), .we4(we4), .data4(data4), .q4(mmu1_q4), .addr4(addr4), 
.en5(en5), .we5(we5), .data5(data5), .q5(mmu1_q5), .addr5(addr5), 
.en6(en6), .we6(we6), .data6(data6), .q6(mmu1_q6), .addr6(addr6), 
.en7(en7), .we7(we7), .data7(data7), .q7(mmu1_q7), .addr7(addr7), 
.en8(en8), .we8(we8), .data8(data8), .q8(mmu1_q8), .addr8(addr8), 
.en9(en9), .we9(we9), .data9(data9), .q9(mmu1_q9), .addr9(addr9), 
.en10(en10), .we10(we10), .data10(data10), .q10(mmu1_q10), .addr10(addr10), 
.en11(en11), .we11(we11), .data11(data11), .q11(mmu1_q11), .addr11(addr11), 
.en12(en12), .we12(we12), .data12(data12), .q12(mmu1_q12), .addr12(addr12), 
.en13(en13), .we13(we13), .data13(data13), .q13(mmu1_q13), .addr13(addr13), 
.en14(en14), .we14(we14), .data14(data14), .q14(mmu1_q14), .addr14(addr14), 
.en15(en15), .we15(we15), .data15(data15), .q15(mmu1_q15), .addr15(addr15), 
.en16(en16), .we16(we16), .data16(data16), .q16(mmu1_q16), .addr16(addr16),
.en17(en17), .we17(we17), .data17(data17), .q17(mmu1_q17), .addr17(addr17), 
.en18(en18), .we18(we18), .data18(data18), .q18(mmu1_q18), .addr18(addr18), 
.en19(en19), .we19(we19), .data19(data19), .q19(mmu1_q19), .addr19(addr19), 
.en20(en20), .we20(we20), .data20(data20), .q20(mmu1_q20), .addr20(addr20), 
.en21(en21), .we21(we21), .data21(data21), .q21(mmu1_q21), .addr21(addr21), 
.en22(en22), .we22(we22), .data22(data22), .q22(mmu1_q22), .addr22(addr22), 
.en23(en23), .we23(we23), .data23(data23), .q23(mmu1_q23), .addr23(addr23), 
.en24(en24), .we24(we24), .data24(data24), .q24(mmu1_q24), .addr24(addr24),
.en25(en25), .we25(we25), .data25(data25), .q25(mmu1_q25), .addr25(addr25), 
.en26(en26), .we26(we26), .data26(data26), .q26(mmu1_q26), .addr26(addr26), 
.en27(en27), .we27(we27), .data27(data27), .q27(mmu1_q27), .addr27(addr27), 
.en28(en28), .we28(we28), .data28(data28), .q28(mmu1_q28), .addr28(addr28), 
.en29(en29), .we29(we29), .data29(data29), .q29(mmu1_q29), .addr29(addr29), 
.en30(en30), .we30(we30), .data30(data30), .q30(mmu1_q30), .addr30(addr30),
.en31(en31), .we31(we31), .data31(data31), .q31(mmu1_q31), .addr31(addr31), 
.en32(en32), .we32(we32), .data32(data32), .q32(mmu1_q32), .addr32(addr32),  
.mem_en(mem1_en), .mem_we(mem1_we), .mem_addr(mem1_addr), .mem_data(mem1_din), .mem_q(mem1_dout)
);

MMU_bram #(.mem_data_width(mem_data_width), .mem_addr_width(12), .acc_in_width(acc_in_width), .acc_out_width(acc_out_width), .mmu_id(2)) mmu2
(
.rst(rst), .clk(clk),
.en0(en0), .we0(we0), .data0(data0), .q0(mmu2_q0), .addr0(addr0), 
.en1(en1), .we1(we1), .data1(data1), .q1(mmu2_q1), .addr1(addr1), 
.en2(en2), .we2(we2), .data2(data2), .q2(mmu2_q2), .addr2(addr2), 
.en3(en3), .we3(we3), .data3(data3), .q3(mmu2_q3), .addr3(addr3), 
.en4(en4), .we4(we4), .data4(data4), .q4(mmu2_q4), .addr4(addr4), 
.en5(en5), .we5(we5), .data5(data5), .q5(mmu2_q5), .addr5(addr5), 
.en6(en6), .we6(we6), .data6(data6), .q6(mmu2_q6), .addr6(addr6), 
.en7(en7), .we7(we7), .data7(data7), .q7(mmu2_q7), .addr7(addr7), 
.en8(en8), .we8(we8), .data8(data8), .q8(mmu2_q8), .addr8(addr8), 
.en9(en9), .we9(we9), .data9(data9), .q9(mmu2_q9), .addr9(addr9), 
.en10(en10), .we10(we10), .data10(data10), .q10(mmu2_q10), .addr10(addr10), 
.en11(en11), .we11(we11), .data11(data11), .q11(mmu2_q11), .addr11(addr11), 
.en12(en12), .we12(we12), .data12(data12), .q12(mmu2_q12), .addr12(addr12), 
.en13(en13), .we13(we13), .data13(data13), .q13(mmu2_q13), .addr13(addr13), 
.en14(en14), .we14(we14), .data14(data14), .q14(mmu2_q14), .addr14(addr14), 
.en15(en15), .we15(we15), .data15(data15), .q15(mmu2_q15), .addr15(addr15), 
.en16(en16), .we16(we16), .data16(data16), .q16(mmu2_q16), .addr16(addr16),
.en17(en17), .we17(we17), .data17(data17), .q17(mmu2_q17), .addr17(addr17), 
.en18(en18), .we18(we18), .data18(data18), .q18(mmu2_q18), .addr18(addr18), 
.en19(en19), .we19(we19), .data19(data19), .q19(mmu2_q19), .addr19(addr19), 
.en20(en20), .we20(we20), .data20(data20), .q20(mmu2_q20), .addr20(addr20), 
.en21(en21), .we21(we21), .data21(data21), .q21(mmu2_q21), .addr21(addr21), 
.en22(en22), .we22(we22), .data22(data22), .q22(mmu2_q22), .addr22(addr22), 
.en23(en23), .we23(we23), .data23(data23), .q23(mmu2_q23), .addr23(addr23), 
.en24(en24), .we24(we24), .data24(data24), .q24(mmu2_q24), .addr24(addr24),
.en25(en25), .we25(we25), .data25(data25), .q25(mmu2_q25), .addr25(addr25),
.en26(en26), .we26(we26), .data26(data26), .q26(mmu2_q26), .addr26(addr26),
.en27(en27), .we27(we27), .data27(data27), .q27(mmu2_q27), .addr27(addr27),
.en28(en28), .we28(we28), .data28(data28), .q28(mmu2_q28), .addr28(addr28),
.en29(en29), .we29(we29), .data29(data29), .q29(mmu2_q29), .addr29(addr29),
.en30(en30), .we30(we30), .data30(data30), .q30(mmu2_q30), .addr30(addr30),
.en31(en31), .we31(we31), .data31(data31), .q31(mmu2_q31), .addr31(addr31), 
.en32(en32), .we32(we32), .data32(data32), .q32(mmu2_q32), .addr32(addr32),  
.mem_en(mem2_en), .mem_we(mem2_we), .mem_addr(mem2_addr), .mem_data(mem2_din), .mem_q(mem2_dout),
.mem_en2(mem2_en2), .mem_we2(mem2_we2), .mem_addr2(mem2_addr2), .mem_data2(mem2_din2), .mem_q2(mem2_dout2)
);

MMU_bram #(.mem_data_width(mem_data_width), .mem_addr_width(12), .acc_in_width(acc_in_width), .acc_out_width(acc_out_width), .mmu_id(3)) mmu3
(
.rst(rst), .clk(clk),
.en0(en0), .we0(we0), .data0(data0), .q0(mmu3_q0), .addr0(addr0), 
.en1(en1), .we1(we1), .data1(data1), .q1(mmu3_q1), .addr1(addr1), 
.en2(en2), .we2(we2), .data2(data2), .q2(mmu3_q2), .addr2(addr2), 
.en3(en3), .we3(we3), .data3(data3), .q3(mmu3_q3), .addr3(addr3), 
.en4(en4), .we4(we4), .data4(data4), .q4(mmu3_q4), .addr4(addr4), 
.en5(en5), .we5(we5), .data5(data5), .q5(mmu3_q5), .addr5(addr5), 
.en6(en6), .we6(we6), .data6(data6), .q6(mmu3_q6), .addr6(addr6), 
.en7(en7), .we7(we7), .data7(data7), .q7(mmu3_q7), .addr7(addr7), 
.en8(en8), .we8(we8), .data8(data8), .q8(mmu3_q8), .addr8(addr8), 
.en9(en9), .we9(we9), .data9(data9), .q9(mmu3_q9), .addr9(addr9), 
.en10(en10), .we10(we10), .data10(data10), .q10(mmu3_q10), .addr10(addr10), 
.en11(en11), .we11(we11), .data11(data11), .q11(mmu3_q11), .addr11(addr11), 
.en12(en12), .we12(we12), .data12(data12), .q12(mmu3_q12), .addr12(addr12), 
.en13(en13), .we13(we13), .data13(data13), .q13(mmu3_q13), .addr13(addr13), 
.en14(en14), .we14(we14), .data14(data14), .q14(mmu3_q14), .addr14(addr14), 
.en15(en15), .we15(we15), .data15(data15), .q15(mmu3_q15), .addr15(addr15), 
.en16(en16), .we16(we16), .data16(data16), .q16(mmu3_q16), .addr16(addr16),
.en17(en17), .we17(we17), .data17(data17), .q17(mmu3_q17), .addr17(addr17), 
.en18(en18), .we18(we18), .data18(data18), .q18(mmu3_q18), .addr18(addr18), 
.en19(en19), .we19(we19), .data19(data19), .q19(mmu3_q19), .addr19(addr19), 
.en20(en20), .we20(we20), .data20(data20), .q20(mmu3_q20), .addr20(addr20), 
.en21(en21), .we21(we21), .data21(data21), .q21(mmu3_q21), .addr21(addr21), 
.en22(en22), .we22(we22), .data22(data22), .q22(mmu3_q22), .addr22(addr22), 
.en23(en23), .we23(we23), .data23(data23), .q23(mmu3_q23), .addr23(addr23), 
.en24(en24), .we24(we24), .data24(data24), .q24(mmu3_q24), .addr24(addr24),
.en25(en25), .we25(we25), .data25(data25), .q25(mmu3_q25), .addr25(addr25),
.en26(en26), .we26(we26), .data26(data26), .q26(mmu3_q26), .addr26(addr26),
.en27(en27), .we27(we27), .data27(data27), .q27(mmu3_q27), .addr27(addr27),
.en28(en28), .we28(we28), .data28(data28), .q28(mmu3_q28), .addr28(addr28),
.en29(en29), .we29(we29), .data29(data29), .q29(mmu3_q29), .addr29(addr29),
.en30(en30), .we30(we30), .data30(data30), .q30(mmu3_q30), .addr30(addr30),
.en31(en31), .we31(we31), .data31(data31), .q31(mmu3_q31), .addr31(addr31), 
.en32(en32), .we32(we32), .data32(data32), .q32(mmu3_q32), .addr32(addr32), 
.mem_en(mem3_en), .mem_we(mem3_we), .mem_addr(mem3_addr), .mem_data(mem3_din), .mem_q(mem3_dout),
.mem_en2(mem3_en2), .mem_we2(mem3_we2), .mem_addr2(mem3_addr2), .mem_data2(mem3_din2), .mem_q2(mem3_dout2)
);

MMU_CH17_new #(.mem_data_width(mem_data_width), .mem_addr_width(16), .acc_in_width(acc_in_width), .acc_out_width(acc_out_width), .mmu_id(4)) mmu4
(
.rst(rst), .clk(clk),
.en0(en0), .we0(we0), .data0(data0), .q0(mmu4_q0), .addr0(addr0), 
.en1(en1), .we1(we1), .data1(data1), .q1(mmu4_q1), .addr1(addr1), 
.en2(en2), .we2(we2), .data2(data2), .q2(mmu4_q2), .addr2(addr2), 
.en3(en3), .we3(we3), .data3(data3), .q3(mmu4_q3), .addr3(addr3), 
.en4(en4), .we4(we4), .data4(data4), .q4(mmu4_q4), .addr4(addr4), 
.en5(en5), .we5(we5), .data5(data5), .q5(mmu4_q5), .addr5(addr5), 
.en6(en6), .we6(we6), .data6(data6), .q6(mmu4_q6), .addr6(addr6), 
.en7(en7), .we7(we7), .data7(data7), .q7(mmu4_q7), .addr7(addr7), 
.en8(en8), .we8(we8), .data8(data8), .q8(mmu4_q8), .addr8(addr8), 
.en9(en9), .we9(we9), .data9(data9), .q9(mmu4_q9), .addr9(addr9), 
.en10(en10), .we10(we10), .data10(data10), .q10(mmu4_q10), .addr10(addr10), 
.en11(en11), .we11(we11), .data11(data11), .q11(mmu4_q11), .addr11(addr11), 
.en12(en12), .we12(we12), .data12(data12), .q12(mmu4_q12), .addr12(addr12), 
.en13(en13), .we13(we13), .data13(data13), .q13(mmu4_q13), .addr13(addr13), 
.en14(en14), .we14(we14), .data14(data14), .q14(mmu4_q14), .addr14(addr14), 
.en15(en15), .we15(we15), .data15(data15), .q15(mmu4_q15), .addr15(addr15), 
.en16(en16), .we16(we16), .data16(data16), .q16(mmu4_q16), .addr16(addr16),
.en17(en17), .we17(we17), .data17(data17), .q17(mmu4_q17), .addr17(addr17), 
.en18(en18), .we18(we18), .data18(data18), .q18(mmu4_q18), .addr18(addr18), 
.en19(en19), .we19(we19), .data19(data19), .q19(mmu4_q19), .addr19(addr19), 
.en20(en20), .we20(we20), .data20(data20), .q20(mmu4_q20), .addr20(addr20), 
.en21(en21), .we21(we21), .data21(data21), .q21(mmu4_q21), .addr21(addr21), 
.en22(en22), .we22(we22), .data22(data22), .q22(mmu4_q22), .addr22(addr22), 
.en23(en23), .we23(we23), .data23(data23), .q23(mmu4_q23), .addr23(addr23), 
.en24(en24), .we24(we24), .data24(data24), .q24(mmu4_q24), .addr24(addr24),
.en25(en25), .we25(we25), .data25(data25), .q25(mmu4_q25), .addr25(addr25),
.en26(en26), .we26(we26), .data26(data26), .q26(mmu4_q26), .addr26(addr26),
.en27(en27), .we27(we27), .data27(data27), .q27(mmu4_q27), .addr27(addr27),
.en28(en28), .we28(we28), .data28(data28), .q28(mmu4_q28), .addr28(addr28),
.en29(en29), .we29(we29), .data29(data29), .q29(mmu4_q29), .addr29(addr29),
.en30(en30), .we30(we30), .data30(data30), .q30(mmu4_q30), .addr30(addr30),
.en31(en31), .we31(we31), .data31(data31), .q31(mmu4_q31), .addr31(addr31), 
.en32(en32), .we32(we32), .data32(data32), .q32(mmu4_q32), .addr32(addr32), 
.mem_en(mem4_en), .mem_we(mem4_we), .mem_addr(mem4_addr), .mem_data(mem4_din), .mem_q(mem4_dout)
);

MMU_CH17_new #(.mem_data_width(mem_data_width), .mem_addr_width(13), .acc_in_width(acc_in_width), .acc_out_width(acc_out_width), .mmu_id(5)) mmu5
(
.rst(rst), .clk(clk),
.en0(en0), .we0(we0), .data0(data0), .q0(mmu5_q0), .addr0(addr0), 
.en1(en1), .we1(we1), .data1(data1), .q1(mmu5_q1), .addr1(addr1), 
.en2(en2), .we2(we2), .data2(data2), .q2(mmu5_q2), .addr2(addr2), 
.en3(en3), .we3(we3), .data3(data3), .q3(mmu5_q3), .addr3(addr3), 
.en4(en4), .we4(we4), .data4(data4), .q4(mmu5_q4), .addr4(addr4), 
.en5(en5), .we5(we5), .data5(data5), .q5(mmu5_q5), .addr5(addr5), 
.en6(en6), .we6(we6), .data6(data6), .q6(mmu5_q6), .addr6(addr6), 
.en7(en7), .we7(we7), .data7(data7), .q7(mmu5_q7), .addr7(addr7), 
.en8(en8), .we8(we8), .data8(data8), .q8(mmu5_q8), .addr8(addr8), 
.en9(en9), .we9(we9), .data9(data9), .q9(mmu5_q9), .addr9(addr9), 
.en10(en10), .we10(we10), .data10(data10), .q10(mmu5_q10), .addr10(addr10), 
.en11(en11), .we11(we11), .data11(data11), .q11(mmu5_q11), .addr11(addr11), 
.en12(en12), .we12(we12), .data12(data12), .q12(mmu5_q12), .addr12(addr12), 
.en13(en13), .we13(we13), .data13(data13), .q13(mmu5_q13), .addr13(addr13), 
.en14(en14), .we14(we14), .data14(data14), .q14(mmu5_q14), .addr14(addr14), 
.en15(en15), .we15(we15), .data15(data15), .q15(mmu5_q15), .addr15(addr15), 
.en16(en16), .we16(we16), .data16(data16), .q16(mmu5_q16), .addr16(addr16),
.en17(en17), .we17(we17), .data17(data17), .q17(mmu5_q17), .addr17(addr17), 
.en18(en18), .we18(we18), .data18(data18), .q18(mmu5_q18), .addr18(addr18), 
.en19(en19), .we19(we19), .data19(data19), .q19(mmu5_q19), .addr19(addr19), 
.en20(en20), .we20(we20), .data20(data20), .q20(mmu5_q20), .addr20(addr20), 
.en21(en21), .we21(we21), .data21(data21), .q21(mmu5_q21), .addr21(addr21), 
.en22(en22), .we22(we22), .data22(data22), .q22(mmu5_q22), .addr22(addr22), 
.en23(en23), .we23(we23), .data23(data23), .q23(mmu5_q23), .addr23(addr23), 
.en24(en24), .we24(we24), .data24(data24), .q24(mmu5_q24), .addr24(addr24),
.en25(en25), .we25(we25), .data25(data25), .q25(mmu5_q25), .addr25(addr25),
.en26(en26), .we26(we26), .data26(data26), .q26(mmu5_q26), .addr26(addr26),
.en27(en27), .we27(we27), .data27(data27), .q27(mmu5_q27), .addr27(addr27),
.en28(en28), .we28(we28), .data28(data28), .q28(mmu5_q28), .addr28(addr28),
.en29(en29), .we29(we29), .data29(data29), .q29(mmu5_q29), .addr29(addr29),
.en30(en30), .we30(we30), .data30(data30), .q30(mmu5_q30), .addr30(addr30),
.en31(en31), .we31(we31), .data31(data31), .q31(mmu5_q31), .addr31(addr31), 
.en32(en32), .we32(we32), .data32(data32), .q32(mmu5_q32), .addr32(addr32), 
.mem_en(mem5_en), .mem_we(mem5_we), .mem_addr(mem5_addr), .mem_data(mem5_din), .mem_q(mem5_dout)
);

MMU_CH17_new #(.mem_data_width(mem_data_width), .mem_addr_width(15), .acc_in_width(acc_in_width), .acc_out_width(acc_out_width), .mmu_id(6)) mmu6
(
.rst(rst), .clk(clk),
.en0(en0), .we0(we0), .data0(data0), .q0(mmu6_q0), .addr0(addr0), 
.en1(en1), .we1(we1), .data1(data1), .q1(mmu6_q1), .addr1(addr1), 
.en2(en2), .we2(we2), .data2(data2), .q2(mmu6_q2), .addr2(addr2), 
.en3(en3), .we3(we3), .data3(data3), .q3(mmu6_q3), .addr3(addr3), 
.en4(en4), .we4(we4), .data4(data4), .q4(mmu6_q4), .addr4(addr4), 
.en5(en5), .we5(we5), .data5(data5), .q5(mmu6_q5), .addr5(addr5), 
.en6(en6), .we6(we6), .data6(data6), .q6(mmu6_q6), .addr6(addr6), 
.en7(en7), .we7(we7), .data7(data7), .q7(mmu6_q7), .addr7(addr7), 
.en8(en8), .we8(we8), .data8(data8), .q8(mmu6_q8), .addr8(addr8), 
.en9(en9), .we9(we9), .data9(data9), .q9(mmu6_q9), .addr9(addr9), 
.en10(en10), .we10(we10), .data10(data10), .q10(mmu6_q10), .addr10(addr10), 
.en11(en11), .we11(we11), .data11(data11), .q11(mmu6_q11), .addr11(addr11), 
.en12(en12), .we12(we12), .data12(data12), .q12(mmu6_q12), .addr12(addr12), 
.en13(en13), .we13(we13), .data13(data13), .q13(mmu6_q13), .addr13(addr13), 
.en14(en14), .we14(we14), .data14(data14), .q14(mmu6_q14), .addr14(addr14), 
.en15(en15), .we15(we15), .data15(data15), .q15(mmu6_q15), .addr15(addr15), 
.en16(en16), .we16(we16), .data16(data16), .q16(mmu6_q16), .addr16(addr16),
.en17(en17), .we17(we17), .data17(data17), .q17(mmu6_q17), .addr17(addr17), 
.en18(en18), .we18(we18), .data18(data18), .q18(mmu6_q18), .addr18(addr18), 
.en19(en19), .we19(we19), .data19(data19), .q19(mmu6_q19), .addr19(addr19), 
.en20(en20), .we20(we20), .data20(data20), .q20(mmu6_q20), .addr20(addr20), 
.en21(en21), .we21(we21), .data21(data21), .q21(mmu6_q21), .addr21(addr21), 
.en22(en22), .we22(we22), .data22(data22), .q22(mmu6_q22), .addr22(addr22), 
.en23(en23), .we23(we23), .data23(data23), .q23(mmu6_q23), .addr23(addr23), 
.en24(en24), .we24(we24), .data24(data24), .q24(mmu6_q24), .addr24(addr24),
.en25(en25), .we25(we25), .data25(data25), .q25(mmu6_q25), .addr25(addr25),
.en26(en26), .we26(we26), .data26(data26), .q26(mmu6_q26), .addr26(addr26),
.en27(en27), .we27(we27), .data27(data27), .q27(mmu6_q27), .addr27(addr27),
.en28(en28), .we28(we28), .data28(data28), .q28(mmu6_q28), .addr28(addr28),
.en29(en29), .we29(we29), .data29(data29), .q29(mmu6_q29), .addr29(addr29),
.en30(en30), .we30(we30), .data30(data30), .q30(mmu6_q30), .addr30(addr30),
.en31(en31), .we31(we31), .data31(data31), .q31(mmu6_q31), .addr31(addr31), 
.en32(en32), .we32(we32), .data32(data32), .q32(mmu6_q32), .addr32(addr32),  
.mem_en(mem6_en), .mem_we(mem6_we), .mem_addr(mem6_addr), .mem_data(mem6_din), .mem_q(mem6_dout)
);

MMU_CH17_new #(.mem_data_width(mem_data_width), .mem_addr_width(12), .acc_in_width(acc_in_width), .acc_out_width(acc_out_width), .mmu_id(7)) mmu7
(
.rst(rst), .clk(clk),
.en0(en0), .we0(we0), .data0(data0), .q0(mmu7_q0), .addr0(addr0), 
.en1(en1), .we1(we1), .data1(data1), .q1(mmu7_q1), .addr1(addr1), 
.en2(en2), .we2(we2), .data2(data2), .q2(mmu7_q2), .addr2(addr2), 
.en3(en3), .we3(we3), .data3(data3), .q3(mmu7_q3), .addr3(addr3), 
.en4(en4), .we4(we4), .data4(data4), .q4(mmu7_q4), .addr4(addr4), 
.en5(en5), .we5(we5), .data5(data5), .q5(mmu7_q5), .addr5(addr5), 
.en6(en6), .we6(we6), .data6(data6), .q6(mmu7_q6), .addr6(addr6), 
.en7(en7), .we7(we7), .data7(data7), .q7(mmu7_q7), .addr7(addr7), 
.en8(en8), .we8(we8), .data8(data8), .q8(mmu7_q8), .addr8(addr8), 
.en9(en9), .we9(we9), .data9(data9), .q9(mmu7_q9), .addr9(addr9), 
.en10(en10), .we10(we10), .data10(data10), .q10(mmu7_q10), .addr10(addr10), 
.en11(en11), .we11(we11), .data11(data11), .q11(mmu7_q11), .addr11(addr11), 
.en12(en12), .we12(we12), .data12(data12), .q12(mmu7_q12), .addr12(addr12), 
.en13(en13), .we13(we13), .data13(data13), .q13(mmu7_q13), .addr13(addr13), 
.en14(en14), .we14(we14), .data14(data14), .q14(mmu7_q14), .addr14(addr14), 
.en15(en15), .we15(we15), .data15(data15), .q15(mmu7_q15), .addr15(addr15), 
.en16(en16), .we16(we16), .data16(data16), .q16(mmu7_q16), .addr16(addr16),
.en17(en17), .we17(we17), .data17(data17), .q17(mmu7_q17), .addr17(addr17), 
.en18(en18), .we18(we18), .data18(data18), .q18(mmu7_q18), .addr18(addr18), 
.en19(en19), .we19(we19), .data19(data19), .q19(mmu7_q19), .addr19(addr19), 
.en20(en20), .we20(we20), .data20(data20), .q20(mmu7_q20), .addr20(addr20), 
.en21(en21), .we21(we21), .data21(data21), .q21(mmu7_q21), .addr21(addr21), 
.en22(en22), .we22(we22), .data22(data22), .q22(mmu7_q22), .addr22(addr22), 
.en23(en23), .we23(we23), .data23(data23), .q23(mmu7_q23), .addr23(addr23), 
.en24(en24), .we24(we24), .data24(data24), .q24(mmu7_q24), .addr24(addr24),
.en25(en25), .we25(we25), .data25(data25), .q25(mmu7_q25), .addr25(addr25),
.en26(en26), .we26(we26), .data26(data26), .q26(mmu7_q26), .addr26(addr26),
.en27(en27), .we27(we27), .data27(data27), .q27(mmu7_q27), .addr27(addr27),
.en28(en28), .we28(we28), .data28(data28), .q28(mmu7_q28), .addr28(addr28),
.en29(en29), .we29(we29), .data29(data29), .q29(mmu7_q29), .addr29(addr29),
.en30(en30), .we30(we30), .data30(data30), .q30(mmu7_q30), .addr30(addr30),
.en31(en31), .we31(we31), .data31(data31), .q31(mmu7_q31), .addr31(addr31), 
.en32(en32), .we32(we32), .data32(data32), .q32(mmu7_q32), .addr32(addr32), 
.mem_en(mem7_en), .mem_we(mem7_we), .mem_addr(mem7_addr), .mem_data(mem7_din), .mem_q(mem7_dout)
);

MMU_CH17_new #(.mem_data_width(mem_data_width), .mem_addr_width(12), .acc_in_width(acc_in_width), .acc_out_width(acc_out_width), .mmu_id(8)) mmu8
(
.rst(rst), .clk(clk),
.en0(en0), .we0(we0), .data0(data0), .q0(mmu8_q0), .addr0(addr0), 
.en1(en1), .we1(we1), .data1(data1), .q1(mmu8_q1), .addr1(addr1), 
.en2(en2), .we2(we2), .data2(data2), .q2(mmu8_q2), .addr2(addr2), 
.en3(en3), .we3(we3), .data3(data3), .q3(mmu8_q3), .addr3(addr3), 
.en4(en4), .we4(we4), .data4(data4), .q4(mmu8_q4), .addr4(addr4), 
.en5(en5), .we5(we5), .data5(data5), .q5(mmu8_q5), .addr5(addr5), 
.en6(en6), .we6(we6), .data6(data6), .q6(mmu8_q6), .addr6(addr6), 
.en7(en7), .we7(we7), .data7(data7), .q7(mmu8_q7), .addr7(addr7), 
.en8(en8), .we8(we8), .data8(data8), .q8(mmu8_q8), .addr8(addr8), 
.en9(en9), .we9(we9), .data9(data9), .q9(mmu8_q9), .addr9(addr9), 
.en10(en10), .we10(we10), .data10(data10), .q10(mmu8_q10), .addr10(addr10), 
.en11(en11), .we11(we11), .data11(data11), .q11(mmu8_q11), .addr11(addr11), 
.en12(en12), .we12(we12), .data12(data12), .q12(mmu8_q12), .addr12(addr12), 
.en13(en13), .we13(we13), .data13(data13), .q13(mmu8_q13), .addr13(addr13), 
.en14(en14), .we14(we14), .data14(data14), .q14(mmu8_q14), .addr14(addr14), 
.en15(en15), .we15(we15), .data15(data15), .q15(mmu8_q15), .addr15(addr15), 
.en16(en16), .we16(we16), .data16(data16), .q16(mmu8_q16), .addr16(addr16),
.en17(en17), .we17(we17), .data17(data17), .q17(mmu8_q17), .addr17(addr17), 
.en18(en18), .we18(we18), .data18(data18), .q18(mmu8_q18), .addr18(addr18), 
.en19(en19), .we19(we19), .data19(data19), .q19(mmu8_q19), .addr19(addr19), 
.en20(en20), .we20(we20), .data20(data20), .q20(mmu8_q20), .addr20(addr20), 
.en21(en21), .we21(we21), .data21(data21), .q21(mmu8_q21), .addr21(addr21), 
.en22(en22), .we22(we22), .data22(data22), .q22(mmu8_q22), .addr22(addr22), 
.en23(en23), .we23(we23), .data23(data23), .q23(mmu8_q23), .addr23(addr23), 
.en24(en24), .we24(we24), .data24(data24), .q24(mmu8_q24), .addr24(addr24),
.en25(en25), .we25(we25), .data25(data25), .q25(mmu8_q25), .addr25(addr25),
.en26(en26), .we26(we26), .data26(data26), .q26(mmu8_q26), .addr26(addr26),
.en27(en27), .we27(we27), .data27(data27), .q27(mmu8_q27), .addr27(addr27),
.en28(en28), .we28(we28), .data28(data28), .q28(mmu8_q28), .addr28(addr28),
.en29(en29), .we29(we29), .data29(data29), .q29(mmu8_q29), .addr29(addr29),
.en30(en30), .we30(we30), .data30(data30), .q30(mmu8_q30), .addr30(addr30),
.en31(en31), .we31(we31), .data31(data31), .q31(mmu8_q31), .addr31(addr31), 
.en32(en32), .we32(we32), .data32(data32), .q32(mmu8_q32), .addr32(addr32),  
.mem_en(mem8_en), .mem_we(mem8_we), .mem_addr(mem8_addr), .mem_data(mem8_din), .mem_q(mem8_dout)
);

/*eight URAM segments, each controlled by one MMU*/
big_memory #(.BLOCK_DEPTH(4096), .NUM_BLOCKS(8), .TOTAL_DEPTH(32768), .AWIDTH(15), .DWIDTH(mem_data_width)) mem0
( 
.clk(clk),.we(mem0_we),.mem_en(mem0_en),.addr(mem0_addr), .din(mem0_din), .dout(mem0_dout)
);
big_memory #(.BLOCK_DEPTH(4096), .NUM_BLOCKS(8), .TOTAL_DEPTH(32768), .AWIDTH(15), .DWIDTH(mem_data_width)) mem1
( 
.clk(clk),.we(mem1_we),.mem_en(mem1_en),.addr(mem1_addr), .din(mem1_din), .dout(mem1_dout)
);
bram1 #(.AWIDTH(12), .DWIDTH(mem_data_width)) mem2 
(
.clk(clk),.we_a(mem2_we),.en_a(mem2_en),.addr_a(mem2_addr), .din_a(mem2_din), .dout_a(mem2_dout),
.we_b(mem2_we2),.en_b(mem2_en2),.addr_b(mem2_addr2), .din_b(mem2_din2), .dout_b(mem2_dout2)
);
bram1 #(.AWIDTH(12), .DWIDTH(mem_data_width)) mem3 
(
.clk(clk),.we_a(mem3_we),.en_a(mem3_en),.addr_a(mem3_addr), .din_a(mem3_din), .dout_a(mem3_dout),
.we_b(mem3_we2),.en_b(mem3_en2),.addr_b(mem3_addr2), .din_b(mem3_din2), .dout_b(mem3_dout2)
);
big_memory #(.BLOCK_DEPTH(4096), .NUM_BLOCKS(16), .TOTAL_DEPTH(65536), .AWIDTH(16), .DWIDTH(mem_data_width)) mem4
( 
.clk(clk),.we(mem4_we),.mem_en(mem4_en),.addr(mem4_addr), .din(mem4_din), .dout(mem4_dout)
);
bram_sp #(.AWIDTH(13), .DWIDTH(mem_data_width)) mem5 
(
.clk(clk),.we(mem5_we),.en(mem5_en),.addr(mem5_addr), .din(mem5_din), .dout(mem5_dout)
);
big_memory #(.BLOCK_DEPTH(4096), .NUM_BLOCKS(5), .TOTAL_DEPTH(20480), .AWIDTH(15), .DWIDTH(mem_data_width)) mem6
( 
.clk(clk),.we(mem6_we),.mem_en(mem6_en),.addr(mem6_addr), .din(mem6_din), .dout(mem6_dout)
);
bram_sp #(.AWIDTH(12), .DWIDTH(mem_data_width)) mem7 
(
.clk(clk),.we(mem7_we),.en(mem7_en),.addr(mem7_addr), .din(mem7_din), .dout(mem7_dout)
);   
bram_sp #(.AWIDTH(12), .DWIDTH(mem_data_width)) mem8 
(
.clk(clk),.we(mem8_we),.en(mem8_en),.addr(mem8_addr), .din(mem8_din), .dout(mem8_dout)
);

/*33 q_mplex for 33 channels*/
q_mplex q_mplex0(.clk(clk), .we(we0), .en(en0), .addr(addr0), 
.r0(mmu0_q0), .r1(mmu1_q0), .r2(mmu2_q0), .r3(mmu3_q0), .r4(mmu4_q0), .r5(mmu5_q0), .r6(mmu6_q0), .r7(mmu7_q0), .r8(mmu8_q0), .q_out(q0));
q_mplex q_mplex1(.clk(clk), .we(we1), .en(en1), .addr(addr1), 
.r0(mmu0_q1), .r1(mmu1_q1), .r2(mmu2_q1), .r3(mmu3_q1), .r4(mmu4_q1), .r5(mmu5_q1), .r6(mmu6_q1), .r7(mmu7_q1), .r8(mmu8_q1), .q_out(q1));
q_mplex q_mplex2(.clk(clk), .we(we2), .en(en2), .addr(addr2), 
.r0(mmu0_q2), .r1(mmu1_q2), .r2(mmu2_q2), .r3(mmu3_q2), .r4(mmu4_q2), .r5(mmu5_q2), .r6(mmu6_q2), .r7(mmu7_q2), .r8(mmu8_q2), .q_out(q2));
q_mplex q_mplex3(.clk(clk), .we(we3), .en(en3), .addr(addr3), 
.r0(mmu0_q3), .r1(mmu1_q3), .r2(mmu2_q3), .r3(mmu3_q3), .r4(mmu4_q3), .r5(mmu5_q3), .r6(mmu6_q3), .r7(mmu7_q3), .r8(mmu8_q3), .q_out(q3));
q_mplex q_mplex4(.clk(clk), .we(we4), .en(en4), .addr(addr4), 
.r0(mmu0_q4), .r1(mmu1_q4), .r2(mmu2_q4), .r3(mmu3_q4), .r4(mmu4_q4), .r5(mmu5_q4), .r6(mmu6_q4), .r7(mmu7_q4), .r8(mmu8_q4), .q_out(q4));
q_mplex q_mplex5(.clk(clk), .we(we5), .en(en5), .addr(addr5), 
.r0(mmu0_q5), .r1(mmu1_q5), .r2(mmu2_q5), .r3(mmu3_q5), .r4(mmu4_q5), .r5(mmu5_q5), .r6(mmu6_q5), .r7(mmu7_q5), .r8(mmu8_q5), .q_out(q5));
q_mplex q_mplex6(.clk(clk), .we(we6), .en(en6), .addr(addr6), 
.r0(mmu0_q6), .r1(mmu1_q6), .r2(mmu2_q6), .r3(mmu3_q6), .r4(mmu4_q6), .r5(mmu5_q6), .r6(mmu6_q6), .r7(mmu7_q6), .r8(mmu8_q6), .q_out(q6));
q_mplex q_mplex7(.clk(clk), .we(we7), .en(en7), .addr(addr7), 
.r0(mmu0_q7), .r1(mmu1_q7), .r2(mmu2_q7), .r3(mmu3_q7), .r4(mmu4_q7), .r5(mmu5_q7), .r6(mmu6_q7), .r7(mmu7_q7), .r8(mmu8_q7), .q_out(q7));
q_mplex q_mplex8(.clk(clk), .we(we8), .en(en8), .addr(addr8), 
.r0(mmu0_q8), .r1(mmu1_q8), .r2(mmu2_q8), .r3(mmu3_q8), .r4(mmu4_q8), .r5(mmu5_q8), .r6(mmu6_q8), .r7(mmu7_q8), .r8(mmu8_q8), .q_out(q8));
q_mplex q_mplex9(.clk(clk), .we(we9), .en(en9), .addr(addr9), 
.r0(mmu0_q9), .r1(mmu1_q9), .r2(mmu2_q9), .r3(mmu3_q9), .r4(mmu4_q9), .r5(mmu5_q9), .r6(mmu6_q9), .r7(mmu7_q9), .r8(mmu8_q9), .q_out(q9));
q_mplex q_mplex10(.clk(clk), .we(we10), .en(en10), .addr(addr10), 
.r0(mmu0_q10), .r1(mmu1_q10), .r2(mmu2_q10), .r3(mmu3_q10), .r4(mmu4_q10), .r5(mmu5_q10), .r6(mmu6_q10), .r7(mmu7_q10), .r8(mmu8_q10), .q_out(q10));
q_mplex q_mplex11(.clk(clk), .we(we11), .en(en11), .addr(addr11), 
.r0(mmu0_q11), .r1(mmu1_q11), .r2(mmu2_q11), .r3(mmu3_q11), .r4(mmu4_q11), .r5(mmu5_q11), .r6(mmu6_q11), .r7(mmu7_q11), .r8(mmu8_q11), .q_out(q11));
q_mplex q_mplex12(.clk(clk), .we(we12), .en(en12), .addr(addr12), 
.r0(mmu0_q12), .r1(mmu1_q12), .r2(mmu2_q12), .r3(mmu3_q12), .r4(mmu4_q12), .r5(mmu5_q12), .r6(mmu6_q12), .r7(mmu7_q12), .r8(mmu8_q12), .q_out(q12));
q_mplex q_mplex13(.clk(clk), .we(we13), .en(en13), .addr(addr13), 
.r0(mmu0_q13), .r1(mmu1_q13), .r2(mmu2_q13), .r3(mmu3_q13), .r4(mmu4_q13), .r5(mmu5_q13), .r6(mmu6_q13), .r7(mmu7_q13), .r8(mmu8_q13), .q_out(q13));
q_mplex q_mplex14(.clk(clk), .we(we14), .en(en14), .addr(addr14), 
.r0(mmu0_q14), .r1(mmu1_q14), .r2(mmu2_q14), .r3(mmu3_q14), .r4(mmu4_q14), .r5(mmu5_q14), .r6(mmu6_q14), .r7(mmu7_q14), .r8(mmu8_q14), .q_out(q14));
q_mplex q_mplex15(.clk(clk), .we(we15), .en(en15), .addr(addr15), 
.r0(mmu0_q15), .r1(mmu1_q15), .r2(mmu2_q15), .r3(mmu3_q15), .r4(mmu4_q15), .r5(mmu5_q15), .r6(mmu6_q15), .r7(mmu7_q15), .r8(mmu8_q15), .q_out(q15));
q_mplex q_mplex16(.clk(clk), .we(we16), .en(en16), .addr(addr16), 
.r0(mmu0_q16), .r1(mmu1_q16), .r2(mmu2_q16), .r3(mmu3_q16), .r4(mmu4_q16), .r5(mmu5_q16), .r6(mmu6_q16), .r7(mmu7_q16), .r8(mmu8_q16), .q_out(q16));
q_mplex q_mplex17(.clk(clk), .we(we17), .en(en17), .addr(addr17), 
.r0(mmu0_q17), .r1(mmu1_q17), .r2(mmu2_q17), .r3(mmu3_q17), .r4(mmu4_q17), .r5(mmu5_q17), .r6(mmu6_q17), .r7(mmu7_q17), .r8(mmu8_q17), .q_out(q17));
q_mplex q_mplex18(.clk(clk), .we(we18), .en(en18), .addr(addr18), 
.r0(mmu0_q18), .r1(mmu1_q18), .r2(mmu2_q18), .r3(mmu3_q18), .r4(mmu4_q18), .r5(mmu5_q18), .r6(mmu6_q18), .r7(mmu7_q18), .r8(mmu8_q18), .q_out(q18));
q_mplex q_mplex19(.clk(clk), .we(we19), .en(en19), .addr(addr19), 
.r0(mmu0_q19), .r1(mmu1_q19), .r2(mmu2_q19), .r3(mmu3_q19), .r4(mmu4_q19), .r5(mmu5_q19), .r6(mmu6_q19), .r7(mmu7_q19), .r8(mmu8_q19), .q_out(q19));
q_mplex q_mplex20(.clk(clk), .we(we20), .en(en20), .addr(addr20), 
.r0(mmu0_q20), .r1(mmu1_q20), .r2(mmu2_q20), .r3(mmu3_q20), .r4(mmu4_q20), .r5(mmu5_q20), .r6(mmu6_q20), .r7(mmu7_q20), .r8(mmu8_q20), .q_out(q20));
q_mplex q_mplex21(.clk(clk), .we(we21), .en(en21), .addr(addr21), 
.r0(mmu0_q21), .r1(mmu1_q21), .r2(mmu2_q21), .r3(mmu3_q21), .r4(mmu4_q21), .r5(mmu5_q21), .r6(mmu6_q21), .r7(mmu7_q21), .r8(mmu8_q21), .q_out(q21));
q_mplex q_mplex22(.clk(clk), .we(we22), .en(en22), .addr(addr22), 
.r0(mmu0_q22), .r1(mmu1_q22), .r2(mmu2_q22), .r3(mmu3_q22), .r4(mmu4_q22), .r5(mmu5_q22), .r6(mmu6_q22), .r7(mmu7_q22), .r8(mmu8_q22), .q_out(q22));
q_mplex q_mplex23(.clk(clk), .we(we23), .en(en23), .addr(addr23), 
.r0(mmu0_q23), .r1(mmu1_q23), .r2(mmu2_q23), .r3(mmu3_q23), .r4(mmu4_q23), .r5(mmu5_q23), .r6(mmu6_q23), .r7(mmu7_q23), .r8(mmu8_q23), .q_out(q23));
q_mplex q_mplex24(.clk(clk), .we(we24), .en(en24), .addr(addr24), 
.r0(mmu0_q24), .r1(mmu1_q24), .r2(mmu2_q24), .r3(mmu3_q24), .r4(mmu4_q24), .r5(mmu5_q24), .r6(mmu6_q24), .r7(mmu7_q24), .r8(mmu8_q24), .q_out(q24));
q_mplex q_mplex25(.clk(clk), .we(we25), .en(en25), .addr(addr25), 
.r0(mmu0_q25), .r1(mmu1_q25), .r2(mmu2_q25), .r3(mmu3_q25), .r4(mmu4_q25), .r5(mmu5_q25), .r6(mmu6_q25), .r7(mmu7_q25), .r8(mmu8_q25), .q_out(q25));
q_mplex q_mplex26(.clk(clk), .we(we26), .en(en26), .addr(addr26), 
.r0(mmu0_q26), .r1(mmu1_q26), .r2(mmu2_q26), .r3(mmu3_q26), .r4(mmu4_q26), .r5(mmu5_q26), .r6(mmu6_q26), .r7(mmu7_q26), .r8(mmu8_q26), .q_out(q26));
q_mplex q_mplex27(.clk(clk), .we(we27), .en(en27), .addr(addr27), 
.r0(mmu0_q27), .r1(mmu1_q27), .r2(mmu2_q27), .r3(mmu3_q27), .r4(mmu4_q27), .r5(mmu5_q27), .r6(mmu6_q27), .r7(mmu7_q27), .r8(mmu8_q27), .q_out(q27));
q_mplex q_mplex28(.clk(clk), .we(we28), .en(en28), .addr(addr28), 
.r0(mmu0_q28), .r1(mmu1_q28), .r2(mmu2_q28), .r3(mmu3_q28), .r4(mmu4_q28), .r5(mmu5_q28), .r6(mmu6_q28), .r7(mmu7_q28), .r8(mmu8_q28), .q_out(q28));
q_mplex q_mplex29(.clk(clk), .we(we29), .en(en29), .addr(addr29), 
.r0(mmu0_q29), .r1(mmu1_q29), .r2(mmu2_q29), .r3(mmu3_q29), .r4(mmu4_q29), .r5(mmu5_q29), .r6(mmu6_q29), .r7(mmu7_q29), .r8(mmu8_q29), .q_out(q29));
q_mplex q_mplex30(.clk(clk), .we(we30), .en(en30), .addr(addr30), 
.r0(mmu0_q30), .r1(mmu1_q30), .r2(mmu2_q30), .r3(mmu3_q30), .r4(mmu4_q30), .r5(mmu5_q30), .r6(mmu6_q30), .r7(mmu7_q30), .r8(mmu8_q30), .q_out(q30));
q_mplex q_mplex31(.clk(clk), .we(we31), .en(en31), .addr(addr31), 
.r0(mmu0_q31), .r1(mmu1_q31), .r2(mmu2_q31), .r3(mmu3_q31), .r4(mmu4_q31), .r5(mmu5_q31), .r6(mmu6_q31), .r7(mmu7_q31), .r8(mmu8_q31), .q_out(q31));
q_mplex q_mplex32(.clk(clk), .we(we32), .en(en32), .addr(addr32), 
.r0(mmu0_q32), .r1(mmu1_q32), .r2(mmu2_q32), .r3(mmu3_q32), .r4(mmu4_q32), .r5(mmu5_q32), .r6(mmu6_q32), .r7(mmu7_q32), .r8(mmu8_q32), .q_out(q32));
endmodule
