`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/25/2026 05:41:30 PM
// Design Name: 
// Module Name: dma_tester22
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module master #(parameter n_workers = 4,
parameter seg0 = 0, //seg0~7 are the offset of each URAM segment in the full 2^18 64-bit-word URAM space
parameter seg0b = 32768,  
parameter seg1 = 65536,
parameter seg1b = 69632,
parameter seg2 = 73728,
parameter seg3 = 139264,
parameter seg4 = 147456,
parameter seg5 = 167936,
parameter seg6 = 172032,
parameter total_words = 176128)
(rst, clk,
tdata, tkeep, tlast, tready, tvalid, //s2mm signals
mtdata, mtkeep, mtlast, mtready, mtvalid, //mm2s signals
curr_state, next_state, writeCnt, //debugging signals
dma_go, //PS control signals (via AXI GPIO)
mmu_en, mmu_we, mmu_sel, mmu_data, mmu_q, //mmu signals
data_ready, worker_done, worker_zero //coordination signals
);
//global signals
input rst, clk;
//s2mm interface
input tready;
output reg [63:0] tdata;
output [7:0] tkeep;
output reg tlast, tvalid;
//mm2s interface
output reg mtready;
input [63:0] mtdata;
input [7:0] mtkeep;
input mtlast, mtvalid;
//debug inferace
output [7:0] curr_state, next_state;
output reg [18:0] writeCnt;
//ps control signals
input[1:0] dma_go;
//mmu interface
output reg mmu_en;
output reg [83:0] mmu_data;
input [64:0] mmu_q;
output reg mmu_we;
output reg [3:0] mmu_sel;
//coordination signals
output reg data_ready;
input [n_workers-1:0] worker_done;
output reg worker_zero;

assign tkeep = 8'd255;

localparam state_init = 0;
localparam state_prep = 1;
localparam state_check = 2;
localparam state_write = 3;
localparam state_update = 4;
localparam state_read_prep = 5;
localparam state_write_prep = 6;
localparam state_check2 = 7;
localparam state_update2 = 8;
localparam state_write_prep2 = 9;
localparam state_write_prep3 = 10;
localparam state_read_prep2 = 11;
localparam state_wait = 12;
localparam state_wait2 = 13;
localparam state_wait_workers = 14;
localparam state_reset_workers = 15;


reg[7:0] curr_state, next_state;

always @(negedge rst, posedge clk)
begin
    if(!rst) curr_state <= state_init;
    else curr_state <= next_state;
end

wire [17:0] ram_addr;
assign ram_addr = writeCnt[17:0];

reg[83:0] mmu_data_buffer;
always @(ram_addr)
begin
    if((ram_addr>=seg0)&&(ram_addr<seg0b)) mmu_data_buffer <= {2'b10, ram_addr-seg0[17:0], 64'b0};
    else if((ram_addr>=seg0b)&&(ram_addr<seg1)) mmu_data_buffer <= {2'b10, ram_addr-seg0b[17:0], 64'b0};
    else if((ram_addr>=seg1)&&(ram_addr<seg1b)) mmu_data_buffer <= {2'b10, ram_addr-seg1[17:0], 64'b0};
    else if((ram_addr>=seg1b)&&(ram_addr<seg2)) mmu_data_buffer <= {2'b10, ram_addr-seg1b[17:0], 64'b0};
    else if((ram_addr>=seg2)&&(ram_addr<seg3)) mmu_data_buffer <= {2'b10, ram_addr-seg2[17:0], 64'b0};  
    else if((ram_addr>=seg3)&&(ram_addr<seg4)) mmu_data_buffer <= {2'b10, ram_addr-seg3[17:0], 64'b0};
    else if((ram_addr>=seg4)&&(ram_addr<seg5)) mmu_data_buffer <= {2'b10, ram_addr-seg4[17:0], 64'b0};
    else if((ram_addr>=seg5)&&(ram_addr<seg6)) mmu_data_buffer <= {2'b10, ram_addr-seg5[17:0], 64'b0};
    else if((ram_addr>=seg6)&&(ram_addr<total_words)) mmu_data_buffer <= {2'b10, ram_addr-seg6[17:0], 64'b0};
    else mmu_data_buffer <= 0;
end

reg[3:0] mmu_sel_buffer;
always @(ram_addr)
begin
    if((ram_addr>=seg0)&&(ram_addr<seg0b)) mmu_sel_buffer <= 4'b0000;
    else if((ram_addr>=seg0b)&&(ram_addr<seg1)) mmu_sel_buffer <= 4'b0001;
    else if((ram_addr>=seg1)&&(ram_addr<seg1b)) mmu_sel_buffer <= 4'b0010;
    else if((ram_addr>=seg1b)&&(ram_addr<seg2)) mmu_sel_buffer <= 4'b0011;
    else if((ram_addr>=seg2)&&(ram_addr<seg3)) mmu_sel_buffer <= 4'b0100;
    else if((ram_addr>=seg3)&&(ram_addr<seg4)) mmu_sel_buffer <= 4'b0101;
    else if((ram_addr>=seg4)&&(ram_addr<seg5)) mmu_sel_buffer <= 4'b0110;
    else if((ram_addr>=seg5)&&(ram_addr<seg6)) mmu_sel_buffer <= 4'b0111;
    else if((ram_addr>=seg6)&&(ram_addr<total_words)) mmu_sel_buffer <= 4'b1000;
    else mmu_sel_buffer <= 4'b0000;
end

reg[83:0] mtdata_buffer;

always @(negedge rst, posedge clk)
begin
    if(!rst) mtdata_buffer <= 84'b0;
    else
    begin
        //if(mtvalid&mtready&(curr_state==state_write_prep)) mtdata_buffer <= {2'b11, 46'b0, writeCnt[17:0], 46'b0, 8'b0, writeCnt[17:8]};
        if(mtvalid&mtready&(curr_state==state_write_prep)) 
        begin
            if((ram_addr>=seg0)&&(ram_addr<seg0b)) mtdata_buffer <= {2'b11, ram_addr-seg0[17:0], mtdata};
            else if((ram_addr>=seg0b)&&(ram_addr<seg1)) mtdata_buffer <= {2'b11, ram_addr-seg0b[17:0], mtdata};
            else if((ram_addr>=seg1)&&(ram_addr<seg1b)) mtdata_buffer <= {2'b11, ram_addr-seg1[17:0], mtdata};
            else if((ram_addr>=seg1b)&&(ram_addr<seg2)) mtdata_buffer <= {2'b11, ram_addr-seg1b[17:0], mtdata};
            else if((ram_addr>=seg2)&&(ram_addr<seg3)) mtdata_buffer <= {2'b11, ram_addr-seg2[17:0], mtdata};
            else if((ram_addr>=seg3)&&(ram_addr<seg4)) mtdata_buffer <= {2'b11, ram_addr-seg3[17:0], mtdata};
            else if((ram_addr>=seg4)&&(ram_addr<seg5)) mtdata_buffer <= {2'b11, ram_addr-seg4[17:0], mtdata};
            else if((ram_addr>=seg5)&&(ram_addr<seg6)) mtdata_buffer <= {2'b11, ram_addr-seg5[17:0], mtdata};
            else if((ram_addr>=seg6)&&(ram_addr<total_words)) mtdata_buffer <= {2'b11, ram_addr-seg6[17:0], mtdata};
            else mtdata_buffer <= 0;
        end
        else mtdata_buffer <= mtdata_buffer;
    end
end



reg writeCtrl, writeClr;

always @(*)
begin
    case(curr_state)
    state_init:
    begin
        next_state <= state_prep;
        writeCtrl <= 0;
        writeClr <= 1;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= 4'b0000;
        data_ready <= 0; 
        mtready <= 0;
        worker_zero <= 0; 
    end
    state_prep:
    begin
        next_state <= (dma_go==2'b10)?state_write_prep:((dma_go==2'b01)?state_read_prep:state_prep);
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= 4'b0000;
        data_ready <= 0; 
        mtready <= 0;
        worker_zero <= 0; 
    end
    
    state_read_prep:
    begin
        next_state <= state_read_prep2;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 1;
        mmu_we <= 1;
        mmu_data <= mmu_data_buffer; //send a read command
        mmu_sel <= mmu_sel_buffer;
        data_ready <= 0;
        mtready <= 0;
        worker_zero <= 0;
    end
    state_read_prep2:
    begin
        next_state <= state_check;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 1;
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= mmu_sel_buffer;
        data_ready <= 0;
        mtready <= 0;
        worker_zero <= 0;
    end
    state_check:
    begin
        next_state <= mmu_q[64]?state_read_prep2:state_write;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0; //ram_q + base;
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= 4'b0000;
        data_ready <= 0; 
        mtready <= 0;
        worker_zero <= 0;       
    end
    state_write:
    begin
        next_state <= (tready)?state_update:state_write;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= (writeCnt==total_words-1)?1:0;
        tvalid <= 1;
        tdata <= mmu_q[63:0];
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= 4'b0000;
        data_ready <= 0;
        mtready <= 0;
        worker_zero <= 0; 
    end
    state_update:
    begin    
        next_state <= (writeCnt<total_words-1)?state_read_prep:state_init;
        writeCtrl <= 1; //(writeCnt<total_words-1)?1:0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= 4'b0000;
        data_ready <= 0;
        mtready <= 0;
        worker_zero <= 0;        
    end
    
    state_write_prep:
    begin
        next_state <= (mtvalid)?state_write_prep2:state_write_prep;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= 4'b0000;
        data_ready <= 0;
        mtready <= 1;
        worker_zero <= 0;    
    end
    state_write_prep2:
    begin
        next_state <= state_write_prep3;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 1;
        mmu_we <= 1;
        mmu_data <= mtdata_buffer;//request to write data
        mmu_sel <= mmu_sel_buffer;
        data_ready <= 0;
        mtready <= 0;
        worker_zero <= 0;    
    end
    state_write_prep3:
    begin
        next_state <= state_check2;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 1; //read to make sure write request is granted
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= mmu_sel_buffer;
        data_ready <= 0;
        mtready <= 0;
        worker_zero <= 0;    
    end
    state_check2:
    begin
        next_state <= mmu_q[64]?state_write_prep3:state_update2;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= 4'b0000;
        data_ready <= 0;
        mtready <= 0;
        worker_zero <= 0;    
    end   
    state_update2:
    begin
        next_state <= (writeCnt<total_words-1)?state_write_prep:state_wait_workers;
        writeCtrl <= 1; //(writeCnt<total_words-1)?1:0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= 4'b0000;
        data_ready <= (writeCnt==total_words-1)?1:0;//one cycle should be enough to trigger the workers to start
        mtready <= 0;
        worker_zero <= 0;    
    end
    state_wait_workers:
    begin
        //next_state <= (worker_done=={n_workers{1'b1}})?state_reset_workers:state_wait_workers;
        next_state <= (worker_done==32'hFFFFFFFF)?state_reset_workers:state_wait_workers; //watch out! if 32 workers, this might be wrong!
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0; //send a read command
        mmu_sel <= 4'b0000;
        data_ready <= 0;
        mtready <= 0;
        worker_zero <= 0;
    end
    state_reset_workers:
    begin
        next_state <= (dma_go==2'b11)?state_init:state_reset_workers;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0; //send a read command
        mmu_sel <= 4'b0000;
        data_ready <= 0;
        mtready <= 0;
        worker_zero <= 1;    
    end    
          
    default:
    begin
        next_state <= state_init;
        writeCtrl <= 0;
        writeClr <= 1;
        tlast <= 0;
        tvalid <= 0;
        tdata <= 64'b0;
        mmu_en <= 0;
        mmu_we <= 0;
        mmu_data <= 0;
        mmu_sel <= 4'b0000;
        data_ready <= 0;
        mtready <= 0;
        worker_zero <= 0;             
    end
    endcase
end



localparam maxCnt = 263000;
always @(negedge rst, posedge clk)
begin
    if(!rst) writeCnt <= 0;
    else if(writeClr) writeCnt <= 0;
    else if(writeCtrl)
    begin
        if(writeCnt<maxCnt) writeCnt <= writeCnt + 1;
        else writeCnt <= writeCnt;
    end
    else writeCnt <= writeCnt;
end 

endmodule

