`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 06/15/2026 10:27:01 PM
// Design Name: 
// Module Name: grant_checker
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module grant_checker(rst, clk, grant_in, value);
input rst, clk;
input[15:0] grant_in;
output reg [16:0] value;

always @(negedge rst, posedge clk)
begin
    if(!rst) value <= 0;
    else
    begin
        if((grant_in&(grant_in-16'b1))!=16'b0) value <= {grant_in, 1'b1};
    end
end

endmodule
