`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/25/2026 05:41:30 PM
// Design Name: 
// Module Name: dma_tester22
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module dma_tester22(rst, clk, tdata, tkeep, tlast, tready, tvalid,
mtdata, mtkeep, mtlast, mtready, mtvalid,
curr_state, next_state, writeCnt, base, dma_go,
mem_en, mem_we, mem_addr, mem_data, mem_q);

input rst, clk;
//s2mm interface
input tready;
output reg [63:0] tdata;
output [7:0] tkeep;
output reg tlast, tvalid;
//mm2s interface
output reg mtready;
input [63:0] mtdata;
input [7:0] mtkeep;
input mtlast, mtvalid;
//debug inferace
output [4:0] curr_state, next_state;
output reg [18:0] writeCnt;
output [31:0] base;
//gpio control
input[1:0] dma_go;
//ram port
output mem_en;
output [63:0] mem_data;
input [63:0] mem_q;
output [17:0] mem_addr;
output mem_we;




assign tkeep = 8'd255;

localparam state_init = 0;
localparam state_prep = 1;
localparam state_check = 2;
localparam state_write = 3;
localparam state_update = 4;
localparam state_read_prep = 5;
localparam state_write_prep = 6;
localparam state_check2 = 7;
localparam state_update2 = 8;
localparam state_write_prep2 = 9;
localparam state_write_prep3 = 10;
localparam state_check22 = 11;
localparam state_check11 = 12;

reg ram_en;
reg [129:0] ram_data; //interface with the multiplexer myMMU4_inst. Bit129: request bit, Bit128: 0(R)/1(W), Bit127-64: address, Bit63-0: data 
wire [64:0] ram_q; //interface with multiplexer myMMU4_inst. Bit64: busy bit, Bit63-0: data (for Read operation)
wire [17:0] ram_addr;
reg ram_wr;

myMMU4 myMMU4_inst(
.rst(rst), .clk(clk), 
.en1(ram_en), .we1(ram_wr), .data1(ram_data), .q1(ram_q), 
.en2(0), .we2(0),
.en3(0), .we3(0),
.en4(0), .we4(0),
.en5(0), .we5(0),
.mem_en(mem_en), .mem_we(mem_we), .mem_addr(mem_addr), .mem_data(mem_data), .mem_q(mem_q));

reg[4:0] curr_state, next_state;

always @(negedge rst, posedge clk)
begin
    if(!rst) curr_state <= state_init;
    else curr_state <= next_state;
end

reg[64:0] ram_q_buffer;
always @(negedge rst, posedge clk)
begin
    if(!rst) ram_q_buffer <= 65'b0;
    else
    begin
        if((curr_state==state_check)||(curr_state==state_check11)||(curr_state==state_check2)||(curr_state==state_check22))
        ram_q_buffer <= ram_q;
        else ram_q_buffer <= ram_q_buffer;
    end
end

reg[63:0] mtdata_buffer;
always @(negedge rst, posedge clk)
begin
    if(!rst) mtdata_buffer <= 64'b0;
    else
    begin
        if(mtvalid&mtready&curr_state==state_write_prep) mtdata_buffer <= mtdata;
        else mtdata_buffer <= mtdata_buffer;
    end
end

reg writeCtrl, writeClr;
reg bclk;
always @(*)
begin
    case(curr_state)
    state_init:
    begin
        next_state <= state_prep;
        writeCtrl <= 0;
        writeClr <= 1;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 1;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0; 
        mtready <= 0; 
    end
    state_prep:
    begin
        next_state <= (dma_go==2'b10)?state_write_prep:((dma_go==2'b01)?state_read_prep:state_prep);
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0; //every round should have a different base
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0; 
        mtready <= 0; 
    end
    
    state_read_prep:
    begin
        next_state <= state_check;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 1; //request the multiplexer to read from the URAM
        ram_wr <= 1; //a command is written
        ram_data <= {2'b10, 46'b0, ram_addr, 64'b0};
        mtready <= 0;
    end
    state_check:
    begin
        next_state <= state_check11;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 1;
        ram_wr <= 0;
        ram_data <= 130'b0; 
        mtready <= 0;       
    end
    state_check11:
    begin
        next_state <= (ram_q[64])?state_check:state_write; //keep reading until multiplexer is not busy
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0; 
        mtready <= 0;       
    end
    state_write:
    begin
        next_state <= (tready)?state_update:state_write;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= (writeCnt==262143)?1:0;
        tvalid <= 1;
        bclk <= 0;
        tdata <= ram_q[63:0]; //now ram_q_buffer lower 64 bits contain the data read from URAM
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        mtready <= 0; 
    end
    state_update:
    begin    
        next_state <= (writeCnt<262143)?state_read_prep:state_init;
        writeCtrl <= 1;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        mtready <= 0;        
    end
    
    state_write_prep:
    begin
        next_state <= (mtvalid)?state_write_prep2:state_write_prep;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        mtready <= 1;    
    end
    state_write_prep2:
    begin
        next_state <= state_check2;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 1;
        ram_wr <= 1;
        ram_data <= {2'b11, 46'b0, ram_addr, mtdata}; //request to write into URAM
        mtready <= 0;    
    end
    state_write_prep3:
    begin
        next_state <= state_check2;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= {2'b11, 46'b0, ram_addr, mtdata_buffer}; //request to write into URAM
        mtready <= 0;    
    end
    state_check2:
    begin
        next_state <= state_check22;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 1;
        ram_wr <= 0; //now switch to reading the multiplexer's status
        ram_data <= 130'b0;
        mtready <= 0;    
    end
    state_check22:
    begin
        next_state <= (ram_q[64])?state_check2:state_update2; //keep reading until multiplexer is not busy
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        mtready <= 0;    
    end   
    state_update2:
    begin
        next_state <= (writeCnt<262143)?state_write_prep:state_init;
        writeCtrl <= 1;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        mtready <= 0;    
    end    
    default:
    begin
        next_state <= state_init;
        writeCtrl <= 0;
        writeClr <= 1;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        mtready <= 0;             
    end
    endcase
end

localparam maxCnt = 263000;
reg[18:0] writeCnt;
always @(negedge rst, posedge clk)
begin
    if(!rst) writeCnt <= 0;
    else if(writeClr) writeCnt <= 0;
    else if(writeCtrl)
    begin
        if(writeCnt<maxCnt) writeCnt <= writeCnt + 1;
        else writeCnt <= writeCnt;
    end
    else writeCnt <= writeCnt;
end

assign ram_addr = writeCnt[17:0];

reg[31:0] base;
always @(negedge rst, posedge clk)
begin
    if(!rst) base <= 0;
    else
    begin 
        if(bclk) base <= base + 1;
        else base <= base;
    end
end

endmodule

