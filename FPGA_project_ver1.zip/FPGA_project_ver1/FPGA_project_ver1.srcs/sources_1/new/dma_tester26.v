`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/25/2026 05:41:30 PM
// Design Name: 
// Module Name: dma_tester22
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module dma_tester26(rst, clk, tdata, tkeep, tlast, tready, tvalid,
mtdata, mtkeep, mtlast, mtready, mtvalid,
curr_state, next_state, writeCnt, base, dma_go,
ram_en, ram_wr, ram_data, ram_q, ram_sel, mtdata_buffer_monitor);

input rst, clk;
//s2mm interface
input tready;
output reg [63:0] tdata;
output [7:0] tkeep;
output reg tlast, tvalid;
//mm2s interface
output reg mtready;
input [63:0] mtdata;
input [7:0] mtkeep;
input mtlast, mtvalid;
//debug inferace
output [4:0] curr_state, next_state;
output reg [18:0] writeCnt;
output [31:0] base;
//gpio control
input[1:0] dma_go;
//ram port
output reg ram_en;
output reg [129:0] ram_data;
input [64:0] ram_q;
output reg ram_wr;
output reg [2:0] ram_sel;
output [31:0] mtdata_buffer_monitor;

assign tkeep = 8'd255;

localparam state_init = 0;
localparam state_prep = 1;
localparam state_check = 2;
localparam state_write = 3;
localparam state_update = 4;
localparam state_read_prep = 5;
localparam state_write_prep = 6;
localparam state_check2 = 7;
localparam state_update2 = 8;
localparam state_write_prep2 = 9;
localparam state_write_prep3 = 10;
localparam state_read_prep2 = 11;
localparam state_wait = 12;
localparam state_wait2 = 13;
localparam state_done = 14;


reg[4:0] curr_state, next_state;

always @(negedge rst, posedge clk)
begin
    if(!rst) curr_state <= state_init;
    else curr_state <= next_state;
end

reg[31:0] timer;
always @(negedge rst, posedge clk)
begin
    if(!rst) timer <= 0;
    else
    begin
        if(timer<32'd2700000000) timer <= timer + 1;
        else timer <= timer;
    end
end

reg[64:0] ram_q_buffer;
always @(negedge rst, posedge clk)
begin
    if(!rst) ram_q_buffer <= 65'b0;
    else
    begin
        if(curr_state==state_check) ram_q_buffer <= ram_q;
        else ram_q_buffer <= ram_q_buffer;
    end
end

/*reg[63:0] mtdata_buffer;
always @(negedge rst, posedge clk)
begin
    if(!rst) mtdata_buffer <= 64'b0;
    else
    begin
        if(mtvalid&mtready&curr_state==state_write_prep) mtdata_buffer <= mtdata;
        else mtdata_buffer <= mtdata_buffer;
    end
end*/

wire [17:0] ram_addr;
assign ram_addr = writeCnt[17:0];

reg[129:0] mtdata_buffer;
wire [31:0] mtdata_buffer_monitor;
assign mtdata_buffer_monitor = mtdata_buffer[31:0];
always @(negedge rst, posedge clk)
begin
    if(!rst) mtdata_buffer <= 130'b0;
    else
    begin
        //if(mtvalid&mtready&(curr_state==state_write_prep)) mtdata_buffer <= {2'b11, 46'b0, writeCnt[17:0], 46'b0, 8'b0, writeCnt[17:8]};
        if(mtvalid&mtready&(curr_state==state_write_prep)) mtdata_buffer <= {2'b11, 46'b0, writeCnt[17:0], mtdata};
        else mtdata_buffer <= mtdata_buffer;
    end
end

/*always @(negedge rst, posedge clk)
begin
    if(!rst) mtdata_buffer <= 64'b0;
    else
    begin
        if(mtvalid&(curr_state==state_write_prep)) mtdata_buffer <= mtdata;
        else mtdata_buffer <= mtdata_buffer;
    end
end*/



reg writeCtrl, writeClr;
reg bclk;

always @(*)
begin
    case(curr_state)
    state_init:
    begin
        next_state <= state_prep;
        writeCtrl <= 0;
        writeClr <= 1;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 1;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b000; 
        mtready <= 0; 
    end
    state_prep:
    begin
        next_state <= (dma_go==2'b10)?state_write_prep:((dma_go==2'b01)?state_read_prep:state_prep);
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0; //every round should have a different base
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b000; 
        mtready <= 0; 
    end
    
    state_read_prep:
    begin
        next_state <= state_read_prep2;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 1;
        ram_wr <= 1;
        ram_data <= {2'b10, 46'b0, writeCnt[17:0], 64'b0}; //send a read command
        ram_sel <= 3'b001;
        mtready <= 0;
    end
    /*state_wait2:
    begin
        next_state <= state_read_prep2;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= {2'b10, 46'b0, writeCnt[17:0], 64'b0}; //send a read command
        mtready <= 0;
    end*/
    state_read_prep2:
    begin
        next_state <= state_check;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 1;
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b001;
        mtready <= 0;
    end
    state_check:
    begin
        next_state <= ram_q[64]?state_read_prep2:state_write;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0; //ram_q + base;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b000; 
        mtready <= 0;       
    end
    state_write:
    begin
        next_state <= (tready)?state_update:state_write;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= (writeCnt==262143)?1:0;
        tvalid <= 1;
        bclk <= 0;
        tdata <= ram_q[63:0]; //ram_q_buffer+base; //ram_q + base;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b000;
        mtready <= 0; 
    end
    state_update:
    begin    
        next_state <= (writeCnt<262143)?state_read_prep:state_init;
        writeCtrl <= 1; //(writeCnt<262143)?1:0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b000;
        mtready <= 0;        
    end
    
    state_write_prep:
    begin
        next_state <= (mtvalid)?state_write_prep2:state_write_prep;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b000;
        mtready <= 1;    
    end
    state_write_prep2:
    begin
        next_state <= state_write_prep3;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 1;
        ram_wr <= 1;
        ram_data <= mtdata_buffer;//request to write data
        ram_sel <= 3'b001;
        mtready <= 0;    
    end
    /*state_wait:
    begin
        next_state <= state_write_prep3;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= mtdata_buffer;//request to write data
        mtready <= 0;    
    end*/
    state_write_prep3:
    begin
        next_state <= state_check2;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 1; //read to make sure write request is granted
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b001;
        mtready <= 0;    
    end
    state_check2:
    begin
        next_state <= ram_q[64]?state_write_prep3:state_update2;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b000;
        mtready <= 0;    
    end   
    state_update2:
    begin
        next_state <= (writeCnt<262143)?state_write_prep:state_init;
        writeCtrl <= 1; //(writeCnt<262143)?1:0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b000;
        mtready <= 0;    
    end
    
    /*state_done:
    begin
        next_state <= state_done;
        writeCtrl <= 0;
        writeClr <= 0;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        mtready <= 0;    
    end*/         
    default:
    begin
        next_state <= state_init;
        writeCtrl <= 0;
        writeClr <= 1;
        tlast <= 0;
        tvalid <= 0;
        bclk <= 0;
        tdata <= 64'b0;
        ram_en <= 0;
        ram_wr <= 0;
        ram_data <= 130'b0;
        ram_sel <= 3'b000;
        mtready <= 0;             
    end
    endcase
end

localparam maxCnt = 263000;
reg[18:0] writeCnt;
always @(negedge rst, posedge clk)
begin
    if(!rst) writeCnt <= 0;
    else if(writeClr) writeCnt <= 0;
    else if(writeCtrl)
    begin
        if(writeCnt<maxCnt) writeCnt <= writeCnt + 1;
        else writeCnt <= writeCnt;
    end
    else writeCnt <= writeCnt;
end

reg[31:0] base;
always @(negedge rst, posedge clk)
begin
    if(!rst) base <= 0;
    else
    begin 
        if(bclk) base <= base + 1;
        else base <= base;
    end
end

endmodule

