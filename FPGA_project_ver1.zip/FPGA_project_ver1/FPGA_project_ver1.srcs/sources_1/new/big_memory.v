`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/26/2026 09:59:58 AM
// Design Name: 
// Module Name: big_memory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// Big Memory using 64 URAM blocks in parallel
// Total capacity: 4096 depth per block * 64 blocks = 262,144 depth
// Address width: log2(262144) = 18 bits
// Data width: 64 bits (unchanged)
module big_memory #(
    parameter BLOCK_DEPTH = 4096,           // Each URAM has 4K depth
    parameter NUM_BLOCKS = 64,              // Number of URAM blocks
    parameter TOTAL_DEPTH = BLOCK_DEPTH * NUM_BLOCKS,  // 262144
    parameter AWIDTH = $clog2(TOTAL_DEPTH), // 18 bits
    parameter DWIDTH = 64                   // Data width
)(
    input wire clk,
    input wire we,                          // Write enable
    input wire mem_en,                      // Memory enable
    input wire [AWIDTH-1:0] addr,           // 18-bit address
    input wire [DWIDTH-1:0] din,            // Input data
    output reg [DWIDTH-1:0] dout            // Output data
);

// Calculate block selection and internal address
localparam BLOCK_SEL_BITS = $clog2(NUM_BLOCKS);  // 6 bits (2^6 = 64)
localparam BLOCK_ADDR_BITS = $clog2(BLOCK_DEPTH); // 12 bits

// Split the incoming address
wire [BLOCK_SEL_BITS-1:0] block_sel;
wire [BLOCK_ADDR_BITS-1:0] block_addr;

assign block_sel = addr[AWIDTH-1:BLOCK_ADDR_BITS];  // Upper bits select block
assign block_addr = addr[BLOCK_ADDR_BITS-1:0];       // Lower bits address inside block

// Outputs from all 64 URAM blocks
wire [DWIDTH-1:0] block_dout [NUM_BLOCKS-1:0];

// Generate 64 instances of your uram1 module
genvar i;
generate
    for(i = 0; i < NUM_BLOCKS; i = i + 1) begin : uram_array
        uram1 #(
            .AWIDTH(BLOCK_ADDR_BITS),
            .DWIDTH(DWIDTH)
        ) uram_inst (
            .clk(clk),
            .we(we && (block_sel == i)),  // Write only to selected block
            .mem_en(mem_en),               // All blocks read when mem_en is high
            .din(din),
            .addr(block_addr),
            .dout(block_dout[i])
        );
    end
endgenerate

reg [BLOCK_SEL_BITS-1:0] block_sel_buffer;
always @(posedge clk)
begin
    if(mem_en&~we) block_sel_buffer <= block_sel;
end

// Multiplexer: Select output from the appropriate block
// This runs combinatorially (no extra register)
always @(*) begin
    //dout = block_dout[block_sel];
    dout = block_dout[block_sel_buffer];
end

endmodule