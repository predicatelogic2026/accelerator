# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "sel_active" -parent ${Page_0}
  ipgui::add_param $IPINST -name "sel_facts" -parent ${Page_0}
  ipgui::add_param $IPINST -name "sel_facts_b" -parent ${Page_0}
  ipgui::add_param $IPINST -name "sel_new_facts" -parent ${Page_0}
  ipgui::add_param $IPINST -name "sel_new_used" -parent ${Page_0}
  ipgui::add_param $IPINST -name "sel_rule_nargs" -parent ${Page_0}
  ipgui::add_param $IPINST -name "sel_rules" -parent ${Page_0}
  ipgui::add_param $IPINST -name "sel_used" -parent ${Page_0}
  ipgui::add_param $IPINST -name "sel_used_b" -parent ${Page_0}
  ipgui::add_param $IPINST -name "total_workers" -parent ${Page_0}
  ipgui::add_param $IPINST -name "vb" -parent ${Page_0}
  ipgui::add_param $IPINST -name "worker_id" -parent ${Page_0}


}

proc update_PARAM_VALUE.sel_active { PARAM_VALUE.sel_active } {
	# Procedure called to update sel_active when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.sel_active { PARAM_VALUE.sel_active } {
	# Procedure called to validate sel_active
	return true
}

proc update_PARAM_VALUE.sel_facts { PARAM_VALUE.sel_facts } {
	# Procedure called to update sel_facts when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.sel_facts { PARAM_VALUE.sel_facts } {
	# Procedure called to validate sel_facts
	return true
}

proc update_PARAM_VALUE.sel_facts_b { PARAM_VALUE.sel_facts_b } {
	# Procedure called to update sel_facts_b when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.sel_facts_b { PARAM_VALUE.sel_facts_b } {
	# Procedure called to validate sel_facts_b
	return true
}

proc update_PARAM_VALUE.sel_new_facts { PARAM_VALUE.sel_new_facts } {
	# Procedure called to update sel_new_facts when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.sel_new_facts { PARAM_VALUE.sel_new_facts } {
	# Procedure called to validate sel_new_facts
	return true
}

proc update_PARAM_VALUE.sel_new_used { PARAM_VALUE.sel_new_used } {
	# Procedure called to update sel_new_used when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.sel_new_used { PARAM_VALUE.sel_new_used } {
	# Procedure called to validate sel_new_used
	return true
}

proc update_PARAM_VALUE.sel_rule_nargs { PARAM_VALUE.sel_rule_nargs } {
	# Procedure called to update sel_rule_nargs when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.sel_rule_nargs { PARAM_VALUE.sel_rule_nargs } {
	# Procedure called to validate sel_rule_nargs
	return true
}

proc update_PARAM_VALUE.sel_rules { PARAM_VALUE.sel_rules } {
	# Procedure called to update sel_rules when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.sel_rules { PARAM_VALUE.sel_rules } {
	# Procedure called to validate sel_rules
	return true
}

proc update_PARAM_VALUE.sel_used { PARAM_VALUE.sel_used } {
	# Procedure called to update sel_used when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.sel_used { PARAM_VALUE.sel_used } {
	# Procedure called to validate sel_used
	return true
}

proc update_PARAM_VALUE.sel_used_b { PARAM_VALUE.sel_used_b } {
	# Procedure called to update sel_used_b when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.sel_used_b { PARAM_VALUE.sel_used_b } {
	# Procedure called to validate sel_used_b
	return true
}

proc update_PARAM_VALUE.total_workers { PARAM_VALUE.total_workers } {
	# Procedure called to update total_workers when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.total_workers { PARAM_VALUE.total_workers } {
	# Procedure called to validate total_workers
	return true
}

proc update_PARAM_VALUE.vb { PARAM_VALUE.vb } {
	# Procedure called to update vb when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.vb { PARAM_VALUE.vb } {
	# Procedure called to validate vb
	return true
}

proc update_PARAM_VALUE.worker_id { PARAM_VALUE.worker_id } {
	# Procedure called to update worker_id when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.worker_id { PARAM_VALUE.worker_id } {
	# Procedure called to validate worker_id
	return true
}


proc update_MODELPARAM_VALUE.sel_facts { MODELPARAM_VALUE.sel_facts PARAM_VALUE.sel_facts } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.sel_facts}] ${MODELPARAM_VALUE.sel_facts}
}

proc update_MODELPARAM_VALUE.sel_facts_b { MODELPARAM_VALUE.sel_facts_b PARAM_VALUE.sel_facts_b } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.sel_facts_b}] ${MODELPARAM_VALUE.sel_facts_b}
}

proc update_MODELPARAM_VALUE.sel_used { MODELPARAM_VALUE.sel_used PARAM_VALUE.sel_used } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.sel_used}] ${MODELPARAM_VALUE.sel_used}
}

proc update_MODELPARAM_VALUE.sel_used_b { MODELPARAM_VALUE.sel_used_b PARAM_VALUE.sel_used_b } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.sel_used_b}] ${MODELPARAM_VALUE.sel_used_b}
}

proc update_MODELPARAM_VALUE.sel_new_facts { MODELPARAM_VALUE.sel_new_facts PARAM_VALUE.sel_new_facts } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.sel_new_facts}] ${MODELPARAM_VALUE.sel_new_facts}
}

proc update_MODELPARAM_VALUE.sel_new_used { MODELPARAM_VALUE.sel_new_used PARAM_VALUE.sel_new_used } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.sel_new_used}] ${MODELPARAM_VALUE.sel_new_used}
}

proc update_MODELPARAM_VALUE.sel_rules { MODELPARAM_VALUE.sel_rules PARAM_VALUE.sel_rules } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.sel_rules}] ${MODELPARAM_VALUE.sel_rules}
}

proc update_MODELPARAM_VALUE.sel_rule_nargs { MODELPARAM_VALUE.sel_rule_nargs PARAM_VALUE.sel_rule_nargs } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.sel_rule_nargs}] ${MODELPARAM_VALUE.sel_rule_nargs}
}

proc update_MODELPARAM_VALUE.sel_active { MODELPARAM_VALUE.sel_active PARAM_VALUE.sel_active } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.sel_active}] ${MODELPARAM_VALUE.sel_active}
}

proc update_MODELPARAM_VALUE.vb { MODELPARAM_VALUE.vb PARAM_VALUE.vb } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.vb}] ${MODELPARAM_VALUE.vb}
}

proc update_MODELPARAM_VALUE.worker_id { MODELPARAM_VALUE.worker_id PARAM_VALUE.worker_id } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.worker_id}] ${MODELPARAM_VALUE.worker_id}
}

proc update_MODELPARAM_VALUE.total_workers { MODELPARAM_VALUE.total_workers PARAM_VALUE.total_workers } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.total_workers}] ${MODELPARAM_VALUE.total_workers}
}

