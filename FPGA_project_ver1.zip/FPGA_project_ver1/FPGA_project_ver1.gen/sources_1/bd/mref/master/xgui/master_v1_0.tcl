# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "n_workers" -parent ${Page_0}
  ipgui::add_param $IPINST -name "seg0" -parent ${Page_0}
  ipgui::add_param $IPINST -name "seg0b" -parent ${Page_0}
  ipgui::add_param $IPINST -name "seg1" -parent ${Page_0}
  ipgui::add_param $IPINST -name "seg1b" -parent ${Page_0}
  ipgui::add_param $IPINST -name "seg2" -parent ${Page_0}
  ipgui::add_param $IPINST -name "seg3" -parent ${Page_0}
  ipgui::add_param $IPINST -name "seg4" -parent ${Page_0}
  ipgui::add_param $IPINST -name "seg5" -parent ${Page_0}
  ipgui::add_param $IPINST -name "seg6" -parent ${Page_0}
  ipgui::add_param $IPINST -name "total_words" -parent ${Page_0}


}

proc update_PARAM_VALUE.n_workers { PARAM_VALUE.n_workers } {
	# Procedure called to update n_workers when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.n_workers { PARAM_VALUE.n_workers } {
	# Procedure called to validate n_workers
	return true
}

proc update_PARAM_VALUE.seg0 { PARAM_VALUE.seg0 } {
	# Procedure called to update seg0 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.seg0 { PARAM_VALUE.seg0 } {
	# Procedure called to validate seg0
	return true
}

proc update_PARAM_VALUE.seg0b { PARAM_VALUE.seg0b } {
	# Procedure called to update seg0b when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.seg0b { PARAM_VALUE.seg0b } {
	# Procedure called to validate seg0b
	return true
}

proc update_PARAM_VALUE.seg1 { PARAM_VALUE.seg1 } {
	# Procedure called to update seg1 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.seg1 { PARAM_VALUE.seg1 } {
	# Procedure called to validate seg1
	return true
}

proc update_PARAM_VALUE.seg1b { PARAM_VALUE.seg1b } {
	# Procedure called to update seg1b when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.seg1b { PARAM_VALUE.seg1b } {
	# Procedure called to validate seg1b
	return true
}

proc update_PARAM_VALUE.seg2 { PARAM_VALUE.seg2 } {
	# Procedure called to update seg2 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.seg2 { PARAM_VALUE.seg2 } {
	# Procedure called to validate seg2
	return true
}

proc update_PARAM_VALUE.seg3 { PARAM_VALUE.seg3 } {
	# Procedure called to update seg3 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.seg3 { PARAM_VALUE.seg3 } {
	# Procedure called to validate seg3
	return true
}

proc update_PARAM_VALUE.seg4 { PARAM_VALUE.seg4 } {
	# Procedure called to update seg4 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.seg4 { PARAM_VALUE.seg4 } {
	# Procedure called to validate seg4
	return true
}

proc update_PARAM_VALUE.seg5 { PARAM_VALUE.seg5 } {
	# Procedure called to update seg5 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.seg5 { PARAM_VALUE.seg5 } {
	# Procedure called to validate seg5
	return true
}

proc update_PARAM_VALUE.seg6 { PARAM_VALUE.seg6 } {
	# Procedure called to update seg6 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.seg6 { PARAM_VALUE.seg6 } {
	# Procedure called to validate seg6
	return true
}

proc update_PARAM_VALUE.total_words { PARAM_VALUE.total_words } {
	# Procedure called to update total_words when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.total_words { PARAM_VALUE.total_words } {
	# Procedure called to validate total_words
	return true
}


proc update_MODELPARAM_VALUE.n_workers { MODELPARAM_VALUE.n_workers PARAM_VALUE.n_workers } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.n_workers}] ${MODELPARAM_VALUE.n_workers}
}

proc update_MODELPARAM_VALUE.seg0 { MODELPARAM_VALUE.seg0 PARAM_VALUE.seg0 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.seg0}] ${MODELPARAM_VALUE.seg0}
}

proc update_MODELPARAM_VALUE.seg0b { MODELPARAM_VALUE.seg0b PARAM_VALUE.seg0b } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.seg0b}] ${MODELPARAM_VALUE.seg0b}
}

proc update_MODELPARAM_VALUE.seg1 { MODELPARAM_VALUE.seg1 PARAM_VALUE.seg1 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.seg1}] ${MODELPARAM_VALUE.seg1}
}

proc update_MODELPARAM_VALUE.seg1b { MODELPARAM_VALUE.seg1b PARAM_VALUE.seg1b } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.seg1b}] ${MODELPARAM_VALUE.seg1b}
}

proc update_MODELPARAM_VALUE.seg2 { MODELPARAM_VALUE.seg2 PARAM_VALUE.seg2 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.seg2}] ${MODELPARAM_VALUE.seg2}
}

proc update_MODELPARAM_VALUE.seg3 { MODELPARAM_VALUE.seg3 PARAM_VALUE.seg3 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.seg3}] ${MODELPARAM_VALUE.seg3}
}

proc update_MODELPARAM_VALUE.seg4 { MODELPARAM_VALUE.seg4 PARAM_VALUE.seg4 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.seg4}] ${MODELPARAM_VALUE.seg4}
}

proc update_MODELPARAM_VALUE.seg5 { MODELPARAM_VALUE.seg5 PARAM_VALUE.seg5 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.seg5}] ${MODELPARAM_VALUE.seg5}
}

proc update_MODELPARAM_VALUE.seg6 { MODELPARAM_VALUE.seg6 PARAM_VALUE.seg6 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.seg6}] ${MODELPARAM_VALUE.seg6}
}

proc update_MODELPARAM_VALUE.total_words { MODELPARAM_VALUE.total_words PARAM_VALUE.total_words } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.total_words}] ${MODELPARAM_VALUE.total_words}
}

