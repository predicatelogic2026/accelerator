# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "acc_in_width" -parent ${Page_0}
  ipgui::add_param $IPINST -name "acc_out_width" -parent ${Page_0}
  ipgui::add_param $IPINST -name "mem_data_width" -parent ${Page_0}


}

proc update_PARAM_VALUE.acc_in_width { PARAM_VALUE.acc_in_width } {
	# Procedure called to update acc_in_width when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.acc_in_width { PARAM_VALUE.acc_in_width } {
	# Procedure called to validate acc_in_width
	return true
}

proc update_PARAM_VALUE.acc_out_width { PARAM_VALUE.acc_out_width } {
	# Procedure called to update acc_out_width when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.acc_out_width { PARAM_VALUE.acc_out_width } {
	# Procedure called to validate acc_out_width
	return true
}

proc update_PARAM_VALUE.mem_data_width { PARAM_VALUE.mem_data_width } {
	# Procedure called to update mem_data_width when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.mem_data_width { PARAM_VALUE.mem_data_width } {
	# Procedure called to validate mem_data_width
	return true
}


proc update_MODELPARAM_VALUE.mem_data_width { MODELPARAM_VALUE.mem_data_width PARAM_VALUE.mem_data_width } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.mem_data_width}] ${MODELPARAM_VALUE.mem_data_width}
}

proc update_MODELPARAM_VALUE.acc_in_width { MODELPARAM_VALUE.acc_in_width PARAM_VALUE.acc_in_width } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.acc_in_width}] ${MODELPARAM_VALUE.acc_in_width}
}

proc update_MODELPARAM_VALUE.acc_out_width { MODELPARAM_VALUE.acc_out_width PARAM_VALUE.acc_out_width } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.acc_out_width}] ${MODELPARAM_VALUE.acc_out_width}
}

